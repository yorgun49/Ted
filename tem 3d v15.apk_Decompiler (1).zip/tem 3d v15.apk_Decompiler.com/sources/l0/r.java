package l0;

import android.view.View;
import android.widget.EditText;
import com.te.tem3d.MainActivity;

public final /* synthetic */ class r implements View.OnClickListener {

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ EditText f3284b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ MainActivity f3285c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ EditText f3286d;

    /* renamed from: e  reason: collision with root package name */
    public final /* synthetic */ EditText f3287e;

    public /* synthetic */ r(EditText editText, MainActivity mainActivity, EditText editText2, EditText editText3) {
        this.f3284b = editText;
        this.f3285c = mainActivity;
        this.f3286d = editText2;
        this.f3287e = editText3;
    }

    public final void onClick(View view) {
        MainActivity.r2(this.f3284b, this.f3285c, this.f3286d, this.f3287e, view);
    }
}
