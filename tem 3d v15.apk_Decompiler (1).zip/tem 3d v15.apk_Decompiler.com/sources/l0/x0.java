package l0;

import android.content.DialogInterface;
import com.te.tem3d.MainActivity;

public final /* synthetic */ class x0 implements DialogInterface.OnClickListener {

    /* renamed from: b  reason: collision with root package name */
    public static final /* synthetic */ x0 f3349b = new x0();

    private /* synthetic */ x0() {
    }

    public final void onClick(DialogInterface dialogInterface, int i2) {
        MainActivity.z0(dialogInterface, i2);
    }
}
