package l0;

import android.widget.NumberPicker;
import com.te.tem3d.MainActivity;

public final /* synthetic */ class u0 implements NumberPicker.Formatter {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ u0 f3309a = new u0();

    private /* synthetic */ u0() {
    }

    public final String format(int i2) {
        return MainActivity.p0(i2);
    }
}
