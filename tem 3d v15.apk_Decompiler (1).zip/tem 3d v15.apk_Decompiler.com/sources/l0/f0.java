package l0;

import android.view.View;
import com.te.tem3d.MainActivity;

public final /* synthetic */ class f0 implements View.OnClickListener {

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ MainActivity f3186b;

    public /* synthetic */ f0(MainActivity mainActivity) {
        this.f3186b = mainActivity;
    }

    public final void onClick(View view) {
        MainActivity.e1(this.f3186b, view);
    }
}
