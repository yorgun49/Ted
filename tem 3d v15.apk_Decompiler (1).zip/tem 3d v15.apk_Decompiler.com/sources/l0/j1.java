package l0;

import com.te.tem3d.MainActivity;

public final /* synthetic */ class j1 implements Runnable {

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ MainActivity f3201b;

    public /* synthetic */ j1(MainActivity mainActivity) {
        this.f3201b = mainActivity;
    }

    public final void run() {
        MainActivity.e.e(this.f3201b);
    }
}
