package l0;

import android.content.DialogInterface;
import android.widget.NumberPicker;
import com.te.tem3d.MainActivity;
import l0.v1;

public final /* synthetic */ class b0 implements DialogInterface.OnClickListener {

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ NumberPicker f3169b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ v1.a f3170c;

    public /* synthetic */ b0(NumberPicker numberPicker, v1.a aVar) {
        this.f3169b = numberPicker;
        this.f3170c = aVar;
    }

    public final void onClick(DialogInterface dialogInterface, int i2) {
        MainActivity.x0(this.f3169b, this.f3170c, dialogInterface, i2);
    }
}
