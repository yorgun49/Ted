package l0;

import android.view.View;
import com.te.tem3d.MainActivity;

public final /* synthetic */ class y implements View.OnClickListener {

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ MainActivity f3357b;

    public /* synthetic */ y(MainActivity mainActivity) {
        this.f3357b = mainActivity;
    }

    public final void onClick(View view) {
        MainActivity.w2(this.f3357b, view);
    }
}
