package l0;

public interface i {

    public enum a {
        BUFFER_CREATION_ERROR
    }

    void a(a aVar, String str);
}
