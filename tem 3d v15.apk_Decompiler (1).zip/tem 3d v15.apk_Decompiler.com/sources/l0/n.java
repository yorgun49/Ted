package l0;

import android.content.Context;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import com.te.tem3d.R;
import w0.k;

public final class n {

    /* renamed from: a  reason: collision with root package name */
    public static final n f3232a = new n();

    private n() {
    }

    public final void a(Context context, View view) {
        k.d(context, "ctx");
        Animation loadAnimation = AnimationUtils.loadAnimation(context, R.anim.slide_down);
        if (loadAnimation != null) {
            loadAnimation.reset();
            if (view != null) {
                view.clearAnimation();
                view.startAnimation(loadAnimation);
            }
        }
    }

    public final void b(Context context, View view) {
        k.d(context, "ctx");
        Animation loadAnimation = AnimationUtils.loadAnimation(context, R.anim.slide_up);
        if (loadAnimation != null) {
            loadAnimation.reset();
            if (view != null) {
                view.clearAnimation();
                view.startAnimation(loadAnimation);
            }
        }
    }
}
