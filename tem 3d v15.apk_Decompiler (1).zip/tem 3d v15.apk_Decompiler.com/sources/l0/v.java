package l0;

import android.view.View;
import android.widget.EditText;
import com.te.tem3d.MainActivity;

public final /* synthetic */ class v implements View.OnClickListener {

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ EditText f3311b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ MainActivity f3312c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ EditText f3313d;

    /* renamed from: e  reason: collision with root package name */
    public final /* synthetic */ EditText f3314e;

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ EditText f3315f;

    /* renamed from: g  reason: collision with root package name */
    public final /* synthetic */ EditText f3316g;

    public /* synthetic */ v(EditText editText, MainActivity mainActivity, EditText editText2, EditText editText3, EditText editText4, EditText editText5) {
        this.f3311b = editText;
        this.f3312c = mainActivity;
        this.f3313d = editText2;
        this.f3314e = editText3;
        this.f3315f = editText4;
        this.f3316g = editText5;
    }

    public final void onClick(View view) {
        MainActivity.s2(this.f3311b, this.f3312c, this.f3313d, this.f3314e, this.f3315f, this.f3316g, view);
    }
}
