package l0;

import android.graphics.Bitmap;
import android.opengl.GLES20;
import android.opengl.GLUtils;
import w0.k;

public final class o1 {

    /* renamed from: a  reason: collision with root package name */
    public static final o1 f3272a = new o1();

    private o1() {
    }

    public final int a(Bitmap bitmap, int i2) {
        k.d(bitmap, "bitmap");
        if (bitmap.isRecycled()) {
            return -1;
        }
        int[] iArr = new int[1];
        GLES20.glGenTextures(1, iArr, 0);
        if (iArr[0] != 0) {
            GLES20.glBindTexture(3553, iArr[0]);
            GLES20.glTexParameteri(3553, 10241, 9729);
            GLES20.glTexParameteri(3553, 10240, 9729);
            GLUtils.texImage2D(3553, 0, bitmap, 0);
            bitmap.recycle();
            GLES20.glBindTexture(3553, 0);
        }
        if (iArr[0] != 0) {
            return iArr[0];
        }
        throw new RuntimeException("Error loading texture.");
    }
}
