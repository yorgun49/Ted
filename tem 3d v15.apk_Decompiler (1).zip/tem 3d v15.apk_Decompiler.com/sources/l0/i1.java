package l0;

import com.te.tem3d.MainActivity;

public final /* synthetic */ class i1 implements Runnable {

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ MainActivity f3198b;

    public /* synthetic */ i1(MainActivity mainActivity) {
        this.f3198b = mainActivity;
    }

    public final void run() {
        MainActivity.b.f(this.f3198b);
    }
}
