package l0;

import android.graphics.Color;

public final class g {
    public final r1 a() {
        int[] iArr = new int[4];
        int[] iArr2 = new int[2];
        int i2 = 0;
        for (int i3 = 4; i2 < i3; i3 = 4) {
            double d2 = (double) ((((((((float) i2) / 3.0f) * 0.6f) - 5.6f) * 5.0f) * 1.0f) / 3.0f);
            Double.isNaN(d2);
            Double.isNaN(d2);
            int[] iArr3 = iArr;
            Double.isNaN(d2);
            iArr3[i2] = Color.argb(200, (int) (((Math.sin(d2 - 2.9d) * 0.4961000084877014d) + 0.5d) * 256.0d), (int) (((Math.sin(d2 - 0.9d) * 0.4961000084877014d) + 0.5d) * 256.0d), (int) (((Math.sin(d2 + 1.1d) * 0.4961000084877014d) + 0.5d) * 256.0d));
            i2++;
            iArr = iArr3;
        }
        int[] iArr4 = iArr;
        iArr2[1] = iArr4[3];
        iArr2[0] = iArr4[0];
        return new r1(iArr4, iArr2, (int[]) null);
    }
}
