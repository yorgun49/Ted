package l0;

import android.opengl.GLES20;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;
import w0.g;
import w0.k;

public final class w1 {

    /* renamed from: l  reason: collision with root package name */
    public static final a f3327l = new a((g) null);

    /* renamed from: m  reason: collision with root package name */
    private static final int f3328m = 2;

    /* renamed from: n  reason: collision with root package name */
    private static final int f3329n = 3;

    /* renamed from: o  reason: collision with root package name */
    private static final int f3330o = 4;

    /* renamed from: p  reason: collision with root package name */
    private static final int f3331p = 2;

    /* renamed from: q  reason: collision with root package name */
    private static final int f3332q = 3;

    /* renamed from: r  reason: collision with root package name */
    private static final int f3333r = 1;

    /* renamed from: s  reason: collision with root package name */
    private static final int f3334s = 3;

    /* renamed from: t  reason: collision with root package name */
    private static final int f3335t = 2;

    /* renamed from: u  reason: collision with root package name */
    private static final String f3336u = "Vertices";

    /* renamed from: a  reason: collision with root package name */
    private int f3337a;

    /* renamed from: b  reason: collision with root package name */
    private final int f3338b;

    /* renamed from: c  reason: collision with root package name */
    private final int f3339c;

    /* renamed from: d  reason: collision with root package name */
    private final int f3340d;

    /* renamed from: e  reason: collision with root package name */
    private FloatBuffer f3341e;

    /* renamed from: f  reason: collision with root package name */
    private ShortBuffer f3342f;

    /* renamed from: g  reason: collision with root package name */
    private int f3343g = 0;

    /* renamed from: h  reason: collision with root package name */
    private int f3344h = 0;

    /* renamed from: i  reason: collision with root package name */
    private final int f3345i = x1.a_texture.b();

    /* renamed from: j  reason: collision with root package name */
    private final int f3346j = x1.A_Position.b();

    /* renamed from: k  reason: collision with root package name */
    private final int f3347k = x1.A_PositionWorld.b();

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(g gVar) {
            this();
        }
    }

    public w1(int i2, int i3) {
        int i4 = f3328m;
        this.f3338b = i4;
        int i5 = i4 + f3331p + f3334s;
        this.f3339c = i5;
        int i6 = i5 * 4;
        this.f3340d = i6;
        FloatBuffer asFloatBuffer = ByteBuffer.allocateDirect(i2 * i6).order(ByteOrder.nativeOrder()).asFloatBuffer();
        k.c(asFloatBuffer, "allocateDirect(maxVertic…         .asFloatBuffer()");
        this.f3341e = asFloatBuffer;
        ShortBuffer asShortBuffer = ByteBuffer.allocateDirect(i3 * f3335t).order(ByteOrder.nativeOrder()).asShortBuffer();
        k.c(asShortBuffer, "allocateDirect(maxIndice…         .asShortBuffer()");
        this.f3342f = asShortBuffer;
    }

    public final void a() {
        this.f3341e.position(0);
        GLES20.glVertexAttribPointer(this.f3346j, this.f3338b, 5126, false, this.f3340d, this.f3341e);
        v1 v1Var = v1.f3318a;
        String str = f3336u;
        v1Var.c(str, "position handle error");
        GLES20.glEnableVertexAttribArray(this.f3346j);
        v1Var.c(str, "position handle enable error");
        this.f3341e.position(this.f3338b);
        int i2 = this.f3345i;
        int i3 = f3331p;
        GLES20.glVertexAttribPointer(i2, i3, 5126, false, this.f3340d, this.f3341e);
        v1Var.c(str, "texture handle error");
        GLES20.glEnableVertexAttribArray(this.f3345i);
        v1Var.c(str, "enable texture handle error");
        this.f3341e.position(this.f3338b + i3);
        GLES20.glVertexAttribPointer(this.f3347k, f3334s, 5126, false, this.f3340d, this.f3341e);
        v1Var.c(str, "mPosition handle error");
        GLES20.glEnableVertexAttribArray(this.f3347k);
        v1Var.c(str, "enable mPosition handle error");
    }

    public final void b(int i2, int i3, int i4) {
        ShortBuffer shortBuffer = this.f3342f;
        if (shortBuffer != null) {
            shortBuffer.position(i3);
            try {
                GLES20.glDrawElements(i2, i4, 5123, this.f3342f);
                v1.f3318a.c(f3336u, "Draw error");
            } catch (Exception e2) {
                System.out.println(e2.toString());
            }
        } else {
            GLES20.glDrawArrays(4, i3, i4);
        }
    }

    public final void c(short[] sArr, int i2, int i3) {
        k.d(sArr, "indis");
        this.f3342f.clear();
        this.f3342f.put(sArr, i2, i3);
        this.f3342f.flip();
        this.f3344h = i3;
    }

    public final void d(int i2) {
        this.f3337a = i2;
    }

    public final void e(float[] fArr, int i2, int i3) {
        k.d(fArr, "vertz");
        this.f3341e.clear();
        this.f3341e.position(i2);
        this.f3341e.put(fArr, i2, i3);
        this.f3341e.flip();
        this.f3343g = i3 / this.f3339c;
    }

    public final void f() {
        GLES20.glDisableVertexAttribArray(this.f3345i);
        GLES20.glDisableVertexAttribArray(this.f3346j);
        GLES20.glDisableVertexAttribArray(this.f3347k);
        GLES20.glDisableVertexAttribArray(this.f3337a);
        v1.f3318a.c(f3336u, "Disable mTextureCoordinate error");
    }
}
