package l0;

import android.content.DialogInterface;
import android.widget.EditText;
import l0.v1;

public final /* synthetic */ class t1 implements DialogInterface.OnClickListener {

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ v1.a f3303b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ EditText f3304c;

    public /* synthetic */ t1(v1.a aVar, EditText editText) {
        this.f3303b = aVar;
        this.f3304c = editText;
    }

    public final void onClick(DialogInterface dialogInterface, int i2) {
        v1.h(this.f3303b, this.f3304c, dialogInterface, i2);
    }
}
