package l0;

import android.view.View;
import com.te.tem3d.MainActivity;

public final /* synthetic */ class n0 implements View.OnClickListener {

    /* renamed from: b  reason: collision with root package name */
    public static final /* synthetic */ n0 f3233b = new n0();

    private /* synthetic */ n0() {
    }

    public final void onClick(View view) {
        MainActivity.a1(view);
    }
}
