package l0;

import android.content.DialogInterface;

public final /* synthetic */ class u1 implements DialogInterface.OnClickListener {

    /* renamed from: b  reason: collision with root package name */
    public static final /* synthetic */ u1 f3310b = new u1();

    private /* synthetic */ u1() {
    }

    public final void onClick(DialogInterface dialogInterface, int i2) {
        v1.i(dialogInterface, i2);
    }
}
