package l0;

import android.widget.CompoundButton;
import com.te.tem3d.MainActivity;

public final /* synthetic */ class p0 implements CompoundButton.OnCheckedChangeListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ MainActivity f3275a;

    public /* synthetic */ p0(MainActivity mainActivity) {
        this.f3275a = mainActivity;
    }

    public final void onCheckedChanged(CompoundButton compoundButton, boolean z2) {
        MainActivity.n1(this.f3275a, compoundButton, z2);
    }
}
