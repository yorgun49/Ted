package l0;

import android.view.View;
import android.widget.EditText;
import com.te.tem3d.MainActivity;

public final /* synthetic */ class s implements View.OnClickListener {

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ EditText f3290b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ MainActivity f3291c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ EditText f3292d;

    /* renamed from: e  reason: collision with root package name */
    public final /* synthetic */ EditText f3293e;

    public /* synthetic */ s(EditText editText, MainActivity mainActivity, EditText editText2, EditText editText3) {
        this.f3290b = editText;
        this.f3291c = mainActivity;
        this.f3292d = editText2;
        this.f3293e = editText3;
    }

    public final void onClick(View view) {
        MainActivity.l2(this.f3290b, this.f3291c, this.f3292d, this.f3293e, view);
    }
}
