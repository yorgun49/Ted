package l0;

import com.te.tem3d.MainActivity;

public final /* synthetic */ class k1 implements Runnable {

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ MainActivity f3205b;

    public /* synthetic */ k1(MainActivity mainActivity) {
        this.f3205b = mainActivity;
    }

    public final void run() {
        MainActivity.e.d(this.f3205b);
    }
}
