package l0;

import android.widget.CompoundButton;
import android.widget.ToggleButton;
import com.te.tem3d.MainActivity;

public final /* synthetic */ class t0 implements CompoundButton.OnCheckedChangeListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ MainActivity f3301a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ ToggleButton f3302b;

    public /* synthetic */ t0(MainActivity mainActivity, ToggleButton toggleButton) {
        this.f3301a = mainActivity;
        this.f3302b = toggleButton;
    }

    public final void onCheckedChanged(CompoundButton compoundButton, boolean z2) {
        MainActivity.o1(this.f3301a, this.f3302b, compoundButton, z2);
    }
}
