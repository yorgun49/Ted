package l0;

public final class p1 {

    /* renamed from: a  reason: collision with root package name */
    private float f3276a;

    /* renamed from: b  reason: collision with root package name */
    private float f3277b;

    /* renamed from: c  reason: collision with root package name */
    private float f3278c;

    /* renamed from: d  reason: collision with root package name */
    private float f3279d;

    public p1(float f2, float f3, float f4, float f5, float f6, float f7) {
        float f8 = f4 / f2;
        this.f3276a = f8;
        float f9 = f5 / f3;
        this.f3277b = f9;
        this.f3278c = f8 + (f6 / f2);
        this.f3279d = f9 + (f7 / f3);
    }

    public final float a() {
        return this.f3276a;
    }

    public final float b() {
        return this.f3278c;
    }

    public final float c() {
        return this.f3277b;
    }

    public final float d() {
        return this.f3279d;
    }
}
