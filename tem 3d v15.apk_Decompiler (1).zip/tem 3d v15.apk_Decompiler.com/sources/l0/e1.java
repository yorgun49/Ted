package l0;

import android.view.View;
import android.widget.EditText;
import com.te.tem3d.MainActivity;

public final /* synthetic */ class e1 implements View.OnClickListener {

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ EditText f3182b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ MainActivity f3183c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ EditText f3184d;

    /* renamed from: e  reason: collision with root package name */
    public final /* synthetic */ EditText f3185e;

    public /* synthetic */ e1(EditText editText, MainActivity mainActivity, EditText editText2, EditText editText3) {
        this.f3182b = editText;
        this.f3183c = mainActivity;
        this.f3184d = editText2;
        this.f3185e = editText3;
    }

    public final void onClick(View view) {
        MainActivity.m2(this.f3182b, this.f3183c, this.f3184d, this.f3185e, view);
    }
}
