package l0;

import android.view.View;
import android.widget.EditText;
import com.te.tem3d.MainActivity;

public final /* synthetic */ class u implements View.OnClickListener {

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ EditText f3305b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ MainActivity f3306c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ EditText f3307d;

    /* renamed from: e  reason: collision with root package name */
    public final /* synthetic */ EditText f3308e;

    public /* synthetic */ u(EditText editText, MainActivity mainActivity, EditText editText2, EditText editText3) {
        this.f3305b = editText;
        this.f3306c = mainActivity;
        this.f3307d = editText2;
        this.f3308e = editText3;
    }

    public final void onClick(View view) {
        MainActivity.p2(this.f3305b, this.f3306c, this.f3307d, this.f3308e, view);
    }
}
