package l0;

import android.view.View;
import com.te.tem3d.MainActivity;

public final /* synthetic */ class c0 implements View.OnClickListener {

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ MainActivity f3173b;

    public /* synthetic */ c0(MainActivity mainActivity) {
        this.f3173b = mainActivity;
    }

    public final void onClick(View view) {
        MainActivity.u1(this.f3173b, view);
    }
}
