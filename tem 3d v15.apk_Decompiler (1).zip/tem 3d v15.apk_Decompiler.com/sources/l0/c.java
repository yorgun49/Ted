package l0;

import android.graphics.Color;

public final class c {
    public final r1 a() {
        return new r1(new int[]{Color.argb(255, 0, 0, 0), Color.argb(255, 255, 255, 255), Color.argb(255, 192, 192, 192), Color.argb(255, 128, 128, 128), Color.argb(255, 0, 0, 0), Color.argb(255, 0, 0, 0), Color.argb(255, 128, 128, 128), Color.argb(255, 192, 192, 192), Color.argb(255, 255, 255, 255), Color.argb(255, 0, 0, 0)}, new int[]{Color.argb(200, 8, 215, 175), Color.argb(200, 122, 211, 63)}, (int[]) null);
    }
}
