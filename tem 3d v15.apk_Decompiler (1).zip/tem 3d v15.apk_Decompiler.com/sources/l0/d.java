package l0;

import android.graphics.Color;

public final class d {
    public final r1 a() {
        return new r1(new int[]{Color.argb(255, 0, 0, 255), Color.argb(255, 0, 128, 255), Color.argb(255, 0, 64, 128), Color.argb(255, 0, 255, 255), Color.argb(255, 0, 64, 0), Color.argb(255, 0, 255, 64), Color.argb(255, 255, 128, 0), Color.argb(255, 255, 255, 0), Color.argb(255, 128, 0, 0), Color.argb(255, 255, 0, 0)}, new int[]{Color.argb(200, 97, 28, 240), Color.argb(200, 39, 152, 194)}, (int[]) null);
    }
}
