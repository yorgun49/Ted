package l0;

import android.widget.CompoundButton;
import com.te.tem3d.MainActivity;

public final /* synthetic */ class q0 implements CompoundButton.OnCheckedChangeListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ MainActivity f3282a;

    public /* synthetic */ q0(MainActivity mainActivity) {
        this.f3282a = mainActivity;
    }

    public final void onCheckedChanged(CompoundButton compoundButton, boolean z2) {
        MainActivity.r1(this.f3282a, compoundButton, z2);
    }
}
