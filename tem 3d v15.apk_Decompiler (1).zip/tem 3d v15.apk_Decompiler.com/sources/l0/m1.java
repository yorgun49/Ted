package l0;

import android.opengl.GLES20;
import android.util.Log;
import w0.k;

public final class m1 {

    /* renamed from: a  reason: collision with root package name */
    public static final m1 f3230a = new m1();

    /* renamed from: b  reason: collision with root package name */
    private static final String f3231b = "ShaderHelper";

    private m1() {
    }

    public final int a(int i2, String str) {
        k.d(str, "shaderSource");
        int glCreateShader = GLES20.glCreateShader(i2);
        if (glCreateShader != 0) {
            GLES20.glShaderSource(glCreateShader, str);
            GLES20.glCompileShader(glCreateShader);
            int[] iArr = new int[1];
            GLES20.glGetShaderiv(glCreateShader, 35713, iArr, 0);
            if (iArr[0] == 0) {
                String str2 = f3231b;
                Log.e(str2, "Error compiling shader: " + GLES20.glGetShaderInfoLog(glCreateShader));
                GLES20.glDeleteShader(glCreateShader);
                glCreateShader = 0;
            }
        }
        if (glCreateShader != 0) {
            return glCreateShader;
        }
        throw new RuntimeException("Error creating shader.");
    }

    public final int b(int i2, int i3, String[] strArr) {
        int glCreateProgram = GLES20.glCreateProgram();
        if (glCreateProgram != 0) {
            GLES20.glAttachShader(glCreateProgram, i2);
            GLES20.glAttachShader(glCreateProgram, i3);
            if (strArr != null) {
                int length = strArr.length;
                for (int i4 = 0; i4 < length; i4++) {
                    GLES20.glBindAttribLocation(glCreateProgram, i4, strArr[i4]);
                }
            }
            GLES20.glLinkProgram(glCreateProgram);
            int[] iArr = new int[1];
            GLES20.glGetProgramiv(glCreateProgram, 35714, iArr, 0);
            if (iArr[0] == 0) {
                String str = f3231b;
                Log.e(str, "Error compiling program: " + GLES20.glGetProgramInfoLog(glCreateProgram));
                GLES20.glDeleteProgram(glCreateProgram);
                glCreateProgram = 0;
            }
        }
        if (glCreateProgram != 0) {
            return glCreateProgram;
        }
        throw new RuntimeException("Error creating program.");
    }
}
