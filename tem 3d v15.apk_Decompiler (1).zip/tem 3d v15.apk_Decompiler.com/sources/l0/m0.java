package l0;

import android.content.DialogInterface;
import com.te.tem3d.MainActivity;

public final /* synthetic */ class m0 implements DialogInterface.OnClickListener {

    /* renamed from: b  reason: collision with root package name */
    public static final /* synthetic */ m0 f3229b = new m0();

    private /* synthetic */ m0() {
    }

    public final void onClick(DialogInterface dialogInterface, int i2) {
        MainActivity.s0(dialogInterface, i2);
    }
}
