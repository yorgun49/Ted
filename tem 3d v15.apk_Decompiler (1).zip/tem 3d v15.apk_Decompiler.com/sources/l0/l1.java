package l0;

import android.content.Context;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import w0.k;

public final class l1 {

    /* renamed from: a  reason: collision with root package name */
    public static final l1 f3220a = new l1();

    private l1() {
    }

    public final String a(Context context, int i2) {
        k.d(context, "context");
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(context.getResources().openRawResource(i2)));
        StringBuilder sb = new StringBuilder();
        while (true) {
            try {
                String readLine = bufferedReader.readLine();
                if (readLine == null) {
                    return sb.toString();
                }
                sb.append(readLine);
                sb.append(10);
            } catch (IOException unused) {
                return null;
            }
        }
    }
}
