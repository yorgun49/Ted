package l0;

import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.opengl.GLES20;
import android.opengl.Matrix;
import com.te.tem3d.MainActivity;
import java.util.ArrayList;
import java.util.List;
import w0.g;
import w0.k;
import z.b;

public final class o {
    private static List<b> A = new ArrayList();

    /* renamed from: y  reason: collision with root package name */
    public static final a f3245y = new a((g) null);

    /* renamed from: z  reason: collision with root package name */
    private static List<String> f3246z = new ArrayList();

    /* renamed from: a  reason: collision with root package name */
    private AssetManager f3247a;

    /* renamed from: b  reason: collision with root package name */
    private n1 f3248b;

    /* renamed from: c  reason: collision with root package name */
    private int f3249c;

    /* renamed from: d  reason: collision with root package name */
    private int f3250d;

    /* renamed from: e  reason: collision with root package name */
    private float f3251e;

    /* renamed from: f  reason: collision with root package name */
    private float f3252f;

    /* renamed from: g  reason: collision with root package name */
    private float f3253g;

    /* renamed from: h  reason: collision with root package name */
    private int f3254h;

    /* renamed from: i  reason: collision with root package name */
    private int f3255i;

    /* renamed from: j  reason: collision with root package name */
    private p1 f3256j;

    /* renamed from: k  reason: collision with root package name */
    private float f3257k;

    /* renamed from: l  reason: collision with root package name */
    private float f3258l;

    /* renamed from: m  reason: collision with root package name */
    private final float[] f3259m;

    /* renamed from: n  reason: collision with root package name */
    private p1[] f3260n;

    /* renamed from: o  reason: collision with root package name */
    private int f3261o;

    /* renamed from: p  reason: collision with root package name */
    private int f3262p;

    /* renamed from: q  reason: collision with root package name */
    private int f3263q;

    /* renamed from: r  reason: collision with root package name */
    private int f3264r;

    /* renamed from: s  reason: collision with root package name */
    private float f3265s;

    /* renamed from: t  reason: collision with root package name */
    private float f3266t;

    /* renamed from: u  reason: collision with root package name */
    private float f3267u;

    /* renamed from: v  reason: collision with root package name */
    private m0.b f3268v;

    /* renamed from: w  reason: collision with root package name */
    private int f3269w;

    /* renamed from: x  reason: collision with root package name */
    private int f3270x;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(g gVar) {
            this();
        }
    }

    public o(AssetManager assetManager) {
        k.d(assetManager, "assets");
        this.f3247a = assetManager;
        this.f3259m = new float[96];
        this.f3260n = new p1[96];
        this.f3249c = 0;
        this.f3250d = 0;
        this.f3251e = 0.0f;
        this.f3252f = 0.0f;
        this.f3253g = 0.0f;
        this.f3254h = -1;
        this.f3255i = 0;
        this.f3257k = 0.0f;
        this.f3258l = 0.0f;
        this.f3261o = 0;
        this.f3262p = 0;
        this.f3263q = 0;
        this.f3264r = 0;
        this.f3265s = 1.0f;
        this.f3266t = 1.0f;
        this.f3267u = 0.0f;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public o(MainActivity mainActivity, AssetManager assetManager) {
        this(assetManager);
        k.d(mainActivity, "mainActivity");
        k.d(assetManager, "assets");
    }

    private final void m(float f2, float f3, float f4, float f5) {
        m0.b bVar = this.f3268v;
        if (bVar == null) {
            k.m("mProgram");
            bVar = null;
        }
        GLES20.glUseProgram(bVar.a());
        v1 v1Var = v1.f3318a;
        v1Var.c("GLTEXT", "Useprogram error");
        float[] fArr = {f2, f3, f4, f5};
        GLES20.glUniform4f(this.f3269w, fArr[0], fArr[1], fArr[2], fArr[3]);
        v1Var.c("GLTEXT", "mColorHandle error");
        GLES20.glActiveTexture(33984);
        v1Var.c("GLTEXT", "Active texture0 error");
        GLES20.glBindTexture(3553, this.f3254h);
        v1Var.c("GLTEXT", "Bind textureId error");
        GLES20.glUniform1i(this.f3270x, 0);
        v1Var.c("GLTEXT", "mTextureUniformHandle error");
        GLES20.glDisable(2929);
        v1Var.c("GLTEXT", "Deptest disable error");
    }

    public final void a(String str, float f2, float f3, float f4, float f5) {
        k.d(str, "text");
        f3246z.add(str);
        A.add(new b((double) f2, (double) f3, (double) f4));
    }

    public final void b(float f2, float f3, float f4, float f5, float[] fArr) {
        k.d(fArr, "vpMatrix");
        m(f2, f3, f4, f5);
        n1 n1Var = this.f3248b;
        if (n1Var == null) {
            k.m("batch");
            n1Var = null;
        }
        n1Var.a(fArr);
    }

    public final void c() {
        A.clear();
        f3246z.clear();
    }

    public final void d(String str, float f2, float f3, float f4, float f5) {
        k.d(str, "text");
        e(str, f2, f3, f4, 0.0f, 0.0f, f5);
    }

    public final void e(String str, float f2, float f3, float f4, float f5, float f6, float f7) {
        String str2 = str;
        k.d(str2, "text");
        float f8 = ((float) this.f3262p) * this.f3266t;
        float f9 = ((float) this.f3261o) * this.f3265s;
        int length = str.length();
        float[] fArr = new float[16];
        Matrix.setIdentityM(fArr, 0);
        Matrix.translateM(fArr, 0, f2 + ((f9 / 2.0f) - (((float) this.f3249c) * this.f3265s)), f3 + ((f8 / 2.0f) - (((float) this.f3250d) * this.f3266t)), f4);
        if (!((f5 + f6) + f7 == 0.0f)) {
            float[] fArr2 = fArr;
            Matrix.rotateM(fArr2, 0, f7, 0.0f, 0.0f, 1.0f);
            Matrix.rotateM(fArr2, 0, f5, 1.0f, 0.0f, 0.0f);
            Matrix.rotateM(fArr2, 0, f6, 0.0f, 1.0f, 0.0f);
        }
        n1 n1Var = this.f3248b;
        n1 n1Var2 = null;
        if (n1Var == null) {
            k.m("batch");
            n1Var = null;
        }
        n1Var.f(fArr);
        float f10 = 0.0f;
        for (int i2 = 0; i2 < length; i2++) {
            int charAt = str2.charAt(i2) - ' ';
            int i3 = (charAt < 0 || charAt >= 96) ? 95 : charAt;
            n1 n1Var3 = this.f3248b;
            if (n1Var3 == null) {
                k.m("batch");
                n1Var3 = null;
            }
            p1 p1Var = this.f3260n[i3];
            k.b(p1Var);
            float[] fArr3 = fArr;
            n1Var3.c(f10, 0.0f, f9, f8, p1Var, fArr);
            f10 += (this.f3259m[i3] + this.f3267u) * this.f3265s;
        }
        n1 n1Var4 = this.f3248b;
        if (n1Var4 == null) {
            k.m("batch");
        } else {
            n1Var2 = n1Var4;
        }
        n1Var2.e();
    }

    public final float f(String str, float f2, float f3, float f4, float f5) {
        k.d(str, "text");
        return g(str, f2, f3, f4, 0.0f, 0.0f, f5);
    }

    public final float g(String str, float f2, float f3, float f4, float f5, float f6, float f7) {
        k.d(str, "text");
        float l2 = l(str);
        e(str, f2 - (l2 / 2.0f), f3 - (k() / 2.0f), f4, f5, f6, f7);
        return l2;
    }

    public final void h(String str, float f2, float f3, float f4) {
        String str2 = str;
        k.d(str2, "text");
        float f5 = ((float) this.f3262p) * this.f3266t;
        float f6 = ((float) this.f3261o) * this.f3265s;
        int length = str.length();
        float f7 = f2 + ((f6 / 2.0f) - (((float) this.f3249c) * this.f3265s));
        float f8 = f3 + ((f5 / 2.0f) - (((float) this.f3250d) * this.f3266t));
        float f9 = 0.0f;
        for (int i2 = 0; i2 < length; i2++) {
            int charAt = str2.charAt(i2) - ' ';
            int i3 = (charAt < 0 || charAt >= 96) ? 95 : charAt;
            n1 n1Var = this.f3248b;
            if (n1Var == null) {
                k.m("batch");
                n1Var = null;
            }
            p1 p1Var = this.f3260n[i3];
            k.b(p1Var);
            n1Var.b(f9, 0.0f, f6, f5, p1Var, f7, f8, f4);
            f9 += (this.f3259m[i3] + this.f3267u) * this.f3265s;
        }
    }

    public final void i() {
        n1 n1Var = this.f3248b;
        n1 n1Var2 = null;
        if (n1Var == null) {
            k.m("batch");
            n1Var = null;
        }
        n1Var.g();
        int size = f3246z.size();
        for (int i2 = 0; i2 < size; i2++) {
            b bVar = A.get(i2);
            h(f3246z.get(i2), (float) bVar.a(), (float) bVar.b(), (float) bVar.c());
        }
        n1 n1Var3 = this.f3248b;
        if (n1Var3 == null) {
            k.m("batch");
        } else {
            n1Var2 = n1Var3;
        }
        n1Var2.e();
    }

    public final void j() {
        n1 n1Var = this.f3248b;
        if (n1Var == null) {
            k.m("batch");
            n1Var = null;
        }
        n1Var.d();
    }

    public final float k() {
        return this.f3258l * this.f3266t;
    }

    public final float l(String str) {
        k.d(str, "text");
        int length = str.length();
        float f2 = 0.0f;
        float f3 = 0.0f;
        for (int i2 = 0; i2 < length; i2++) {
            f3 += this.f3259m[str.charAt(i2) - ' '] * this.f3265s;
        }
        if (length > 1) {
            f2 = ((float) (length - 1)) * this.f3267u * this.f3265s;
        }
        return f3 + f2;
    }

    public final void n(MainActivity mainActivity) {
        k.d(mainActivity, "mainActivity");
        this.f3268v = new m0.a(mainActivity);
        m0.b bVar = this.f3268v;
        m0.b bVar2 = null;
        if (bVar == null) {
            k.m("mProgram");
            bVar = null;
        }
        this.f3248b = new n1(800, bVar);
        m0.b bVar3 = this.f3268v;
        if (bVar3 == null) {
            k.m("mProgram");
            bVar3 = null;
        }
        this.f3269w = GLES20.glGetUniformLocation(bVar3.a(), "u_Color");
        v1 v1Var = v1.f3318a;
        v1Var.c("GLTEXT", "u_Color handle");
        m0.b bVar4 = this.f3268v;
        if (bVar4 == null) {
            k.m("mProgram");
        } else {
            bVar2 = bVar4;
        }
        this.f3270x = GLES20.glGetUniformLocation(bVar2.a(), "u_Texture");
        v1Var.c("GLTEXT", "u_Texture handle");
    }

    public final boolean o(String str, int i2, int i3, int i4) {
        String str2 = str;
        k.d(str2, "file");
        this.f3249c = i3;
        this.f3250d = i4;
        Typeface createFromAsset = Typeface.createFromAsset(this.f3247a, str2);
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setTextSize((float) i2);
        paint.setColor(-1);
        paint.setTypeface(createFromAsset);
        Paint.FontMetrics fontMetrics = paint.getFontMetrics();
        this.f3251e = (float) Math.ceil((double) (Math.abs(fontMetrics.bottom) + Math.abs(fontMetrics.top)));
        this.f3252f = (float) Math.ceil((double) Math.abs(fontMetrics.ascent));
        this.f3253g = (float) Math.ceil((double) Math.abs(fontMetrics.descent));
        char[] cArr = new char[2];
        this.f3258l = 0.0f;
        this.f3257k = 0.0f;
        float[] fArr = new float[2];
        int i5 = 0;
        for (int i6 = 32; i6 < 127; i6++) {
            cArr[0] = (char) i6;
            paint.getTextWidths(cArr, 0, 1, fArr);
            float[] fArr2 = this.f3259m;
            fArr2[i5] = fArr[0];
            if (fArr2[i5] > this.f3257k) {
                this.f3257k = fArr2[i5];
            }
            i5++;
        }
        cArr[0] = ' ';
        paint.getTextWidths(cArr, 0, 1, fArr);
        float[] fArr3 = this.f3259m;
        fArr3[i5] = fArr[0];
        if (fArr3[i5] > this.f3257k) {
            this.f3257k = fArr3[i5];
        }
        float f2 = this.f3251e;
        this.f3258l = f2;
        int i7 = ((int) this.f3257k) + (this.f3249c * 2);
        this.f3261o = i7;
        int i8 = ((int) f2) + (this.f3250d * 2);
        this.f3262p = i8;
        if (i7 <= i8) {
            i7 = i8;
        }
        if (i7 < 6 || i7 > 180) {
            return false;
        }
        this.f3255i = i7 <= 24 ? 256 : i7 <= 40 ? 512 : i7 <= 80 ? 1024 : 2048;
        int i9 = this.f3255i;
        Bitmap createBitmap = Bitmap.createBitmap(i9, i9, Bitmap.Config.ALPHA_8);
        Canvas canvas = new Canvas(createBitmap);
        createBitmap.eraseColor(0);
        int i10 = this.f3255i / this.f3261o;
        this.f3264r = i10;
        this.f3263q = (int) Math.ceil((double) (96.0f / ((float) i10)));
        float f3 = (float) this.f3249c;
        float f4 = (((float) (this.f3262p - 1)) - this.f3253g) - ((float) this.f3250d);
        int i11 = 32;
        while (i11 < 127) {
            cArr[0] = (char) i11;
            int i12 = i11;
            Canvas canvas2 = canvas;
            canvas.drawText(cArr, 0, 1, f3, f4, paint);
            int i13 = this.f3261o;
            f3 += (float) i13;
            int i14 = this.f3249c;
            if ((f3 + ((float) i13)) - ((float) i14) > ((float) this.f3255i)) {
                f4 += (float) this.f3262p;
                f3 = (float) i14;
            }
            i11 = i12 + 1;
            canvas = canvas2;
        }
        Canvas canvas3 = canvas;
        cArr[0] = ' ';
        canvas3.drawText(cArr, 0, 1, f3, f4, paint);
        canvas3.save();
        o1 o1Var = o1.f3272a;
        Bitmap copy = createBitmap.copy(Bitmap.Config.ALPHA_8, false);
        k.c(copy, "bitmap.copy(Bitmap.Config.ALPHA_8,false)");
        this.f3254h = o1Var.a(copy, 33987);
        createBitmap.recycle();
        float f5 = 0.0f;
        float f6 = 0.0f;
        for (int i15 = 0; i15 < 96; i15++) {
            p1[] p1VarArr = this.f3260n;
            int i16 = this.f3255i;
            p1VarArr[i15] = new p1((float) i16, (float) i16, f5, f6, (float) (this.f3261o - 1), (float) (this.f3262p - 1));
            int i17 = this.f3261o;
            f5 += (float) i17;
            if (((float) i17) + f5 > ((float) this.f3255i)) {
                f6 += (float) this.f3262p;
                f5 = 0.0f;
            }
        }
        int i18 = this.f3255i;
        this.f3256j = new p1((float) i18, (float) i18, 0.0f, 0.0f, (float) i18, (float) i18);
        return true;
    }

    public final void p(float f2) {
        this.f3266t = f2;
        this.f3265s = f2;
    }

    public final boolean q() {
        return !f3246z.isEmpty();
    }
}
