package l0;

import android.content.DialogInterface;
import com.te.tem3d.MainActivity;

public final /* synthetic */ class a1 implements DialogInterface.OnDismissListener {

    /* renamed from: b  reason: collision with root package name */
    public static final /* synthetic */ a1 f3165b = new a1();

    private /* synthetic */ a1() {
    }

    public final void onDismiss(DialogInterface dialogInterface) {
        MainActivity.w1(dialogInterface);
    }
}
