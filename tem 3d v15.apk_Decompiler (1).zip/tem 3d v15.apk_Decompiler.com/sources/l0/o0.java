package l0;

import android.widget.CompoundButton;
import com.te.tem3d.MainActivity;

public final /* synthetic */ class o0 implements CompoundButton.OnCheckedChangeListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ MainActivity f3271a;

    public /* synthetic */ o0(MainActivity mainActivity) {
        this.f3271a = mainActivity;
    }

    public final void onCheckedChanged(CompoundButton compoundButton, boolean z2) {
        MainActivity.p1(this.f3271a, compoundButton, z2);
    }
}
