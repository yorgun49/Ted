package l0;

import android.widget.CompoundButton;
import com.te.tem3d.MainActivity;

public final /* synthetic */ class r0 implements CompoundButton.OnCheckedChangeListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ MainActivity f3288a;

    public /* synthetic */ r0(MainActivity mainActivity) {
        this.f3288a = mainActivity;
    }

    public final void onCheckedChanged(CompoundButton compoundButton, boolean z2) {
        MainActivity.q1(this.f3288a, compoundButton, z2);
    }
}
