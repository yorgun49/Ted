package l0;

import android.view.View;
import android.widget.EditText;
import com.te.tem3d.MainActivity;

public final /* synthetic */ class t implements View.OnClickListener {

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ EditText f3297b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ MainActivity f3298c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ EditText f3299d;

    /* renamed from: e  reason: collision with root package name */
    public final /* synthetic */ EditText f3300e;

    public /* synthetic */ t(EditText editText, MainActivity mainActivity, EditText editText2, EditText editText3) {
        this.f3297b = editText;
        this.f3298c = mainActivity;
        this.f3299d = editText2;
        this.f3300e = editText3;
    }

    public final void onClick(View view) {
        MainActivity.j2(this.f3297b, this.f3298c, this.f3299d, this.f3300e, view);
    }
}
