package l0;

import android.view.View;
import com.te.tem3d.MainActivity;

public final /* synthetic */ class h0 implements View.OnClickListener {

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ MainActivity f3193b;

    public /* synthetic */ h0(MainActivity mainActivity) {
        this.f3193b = mainActivity;
    }

    public final void onClick(View view) {
        MainActivity.h1(this.f3193b, view);
    }
}
