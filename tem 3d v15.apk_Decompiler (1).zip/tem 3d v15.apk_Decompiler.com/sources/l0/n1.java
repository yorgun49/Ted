package l0;

import android.opengl.GLES20;
import android.opengl.Matrix;
import m0.b;
import w0.g;
import w0.k;

public final class n1 {

    /* renamed from: k  reason: collision with root package name */
    public static final a f3234k = new a((g) null);

    /* renamed from: a  reason: collision with root package name */
    private final int f3235a;

    /* renamed from: b  reason: collision with root package name */
    private w1 f3236b;

    /* renamed from: c  reason: collision with root package name */
    private float[] f3237c;

    /* renamed from: d  reason: collision with root package name */
    private int f3238d;

    /* renamed from: e  reason: collision with root package name */
    private int f3239e;

    /* renamed from: f  reason: collision with root package name */
    private float[] f3240f;

    /* renamed from: g  reason: collision with root package name */
    private final float[] f3241g = new float[16];

    /* renamed from: h  reason: collision with root package name */
    private final int f3242h;

    /* renamed from: i  reason: collision with root package name */
    private final float[] f3243i = new float[16];

    /* renamed from: j  reason: collision with root package name */
    private short[] f3244j;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(g gVar) {
            this();
        }
    }

    public n1(int i2, b bVar) {
        k.d(bVar, "program");
        int i3 = i2 * 4;
        this.f3237c = new float[(i3 * 7)];
        int i4 = i2 * 6;
        this.f3236b = new w1(i3, i4);
        this.f3238d = 0;
        this.f3239e = 0;
        short[] sArr = new short[i4];
        this.f3244j = sArr;
        int length = sArr.length;
        int i5 = 0;
        int i6 = 0;
        while (i5 < length) {
            short[] sArr2 = this.f3244j;
            short s2 = (short) (i6 + 0);
            sArr2[i5 + 0] = s2;
            sArr2[i5 + 1] = (short) (i6 + 1);
            short s3 = (short) (i6 + 2);
            sArr2[i5 + 2] = s3;
            sArr2[i5 + 3] = s3;
            sArr2[i5 + 4] = (short) (i6 + 3);
            sArr2[i5 + 5] = s2;
            i5 += 6;
            i6 += 4;
        }
        this.f3236b.c(this.f3244j, 0, length);
        int glGetUniformLocation = GLES20.glGetUniformLocation(bVar.a(), "u_MVPMatrix");
        this.f3242h = glGetUniformLocation;
        this.f3236b.d(glGetUniformLocation);
        v1 v1Var = v1.f3318a;
        v1Var.c("SpriteBatch", "u_MVPMatrix error");
        this.f3235a = GLES20.glGetUniformLocation(bVar.a(), "u_batchmode");
        v1Var.c("SpriteBatch", "u_batchmode error");
    }

    public final void a(float[] fArr) {
        k.d(fArr, "vpMatrix");
        this.f3239e = 0;
        this.f3238d = 0;
        this.f3240f = fArr;
    }

    public final void b(float f2, float f3, float f4, float f5, p1 p1Var, float f6, float f7, float f8) {
        k.d(p1Var, "region");
        if (this.f3239e == 700) {
            d();
            this.f3239e = 0;
            this.f3238d = 0;
        }
        float f9 = f4 / 2.0f;
        float f10 = f5 / 2.0f;
        float f11 = f2 - f9;
        float f12 = f3 - f10;
        float f13 = f2 + f9;
        float f14 = f3 + f10;
        float[] fArr = this.f3237c;
        int i2 = this.f3238d;
        int i3 = i2 + 1;
        this.f3238d = i3;
        fArr[i2] = f11;
        int i4 = i3 + 1;
        this.f3238d = i4;
        fArr[i3] = f12;
        this.f3238d = i4 + 1;
        fArr[i4] = p1Var.a();
        float[] fArr2 = this.f3237c;
        int i5 = this.f3238d;
        this.f3238d = i5 + 1;
        fArr2[i5] = p1Var.d();
        float[] fArr3 = this.f3237c;
        int i6 = this.f3238d;
        int i7 = i6 + 1;
        this.f3238d = i7;
        fArr3[i6] = f6;
        int i8 = i7 + 1;
        this.f3238d = i8;
        fArr3[i7] = f7;
        int i9 = i8 + 1;
        this.f3238d = i9;
        fArr3[i8] = f8;
        int i10 = i9 + 1;
        this.f3238d = i10;
        fArr3[i9] = f13;
        int i11 = i10 + 1;
        this.f3238d = i11;
        fArr3[i10] = f12;
        this.f3238d = i11 + 1;
        fArr3[i11] = p1Var.b();
        float[] fArr4 = this.f3237c;
        int i12 = this.f3238d;
        this.f3238d = i12 + 1;
        fArr4[i12] = p1Var.d();
        float[] fArr5 = this.f3237c;
        int i13 = this.f3238d;
        int i14 = i13 + 1;
        this.f3238d = i14;
        fArr5[i13] = f6;
        int i15 = i14 + 1;
        this.f3238d = i15;
        fArr5[i14] = f7;
        int i16 = i15 + 1;
        this.f3238d = i16;
        fArr5[i15] = f8;
        int i17 = i16 + 1;
        this.f3238d = i17;
        fArr5[i16] = f13;
        int i18 = i17 + 1;
        this.f3238d = i18;
        fArr5[i17] = f14;
        this.f3238d = i18 + 1;
        fArr5[i18] = p1Var.b();
        float[] fArr6 = this.f3237c;
        int i19 = this.f3238d;
        this.f3238d = i19 + 1;
        fArr6[i19] = p1Var.c();
        float[] fArr7 = this.f3237c;
        int i20 = this.f3238d;
        int i21 = i20 + 1;
        this.f3238d = i21;
        fArr7[i20] = f6;
        int i22 = i21 + 1;
        this.f3238d = i22;
        fArr7[i21] = f7;
        int i23 = i22 + 1;
        this.f3238d = i23;
        fArr7[i22] = f8;
        int i24 = i23 + 1;
        this.f3238d = i24;
        fArr7[i23] = f11;
        int i25 = i24 + 1;
        this.f3238d = i25;
        fArr7[i24] = f14;
        this.f3238d = i25 + 1;
        fArr7[i25] = p1Var.a();
        float[] fArr8 = this.f3237c;
        int i26 = this.f3238d;
        this.f3238d = i26 + 1;
        fArr8[i26] = p1Var.c();
        float[] fArr9 = this.f3237c;
        int i27 = this.f3238d;
        int i28 = i27 + 1;
        this.f3238d = i28;
        fArr9[i27] = f6;
        int i29 = i28 + 1;
        this.f3238d = i29;
        fArr9[i28] = f7;
        this.f3238d = i29 + 1;
        fArr9[i29] = f8;
        this.f3239e++;
    }

    public final void c(float f2, float f3, float f4, float f5, p1 p1Var, float[] fArr) {
        k.d(p1Var, "region");
        k.d(fArr, "modelMatrix");
        if (this.f3239e == 500) {
            d();
            this.f3239e = 0;
            this.f3238d = 0;
        }
        float f6 = f4 / 2.0f;
        float f7 = f5 / 2.0f;
        float f8 = f2 - f6;
        float f9 = f3 - f7;
        float f10 = f2 + f6;
        float f11 = f3 + f7;
        float[] fArr2 = this.f3237c;
        int i2 = this.f3238d;
        int i3 = i2 + 1;
        this.f3238d = i3;
        fArr2[i2] = f8;
        int i4 = i3 + 1;
        this.f3238d = i4;
        fArr2[i3] = f9;
        this.f3238d = i4 + 1;
        fArr2[i4] = p1Var.a();
        float[] fArr3 = this.f3237c;
        int i5 = this.f3238d;
        this.f3238d = i5 + 1;
        fArr3[i5] = p1Var.d();
        float[] fArr4 = this.f3237c;
        int i6 = this.f3238d;
        int i7 = i6 + 1;
        this.f3238d = i7;
        fArr4[i6] = 0.0f;
        int i8 = i7 + 1;
        this.f3238d = i8;
        fArr4[i7] = 0.0f;
        int i9 = i8 + 1;
        this.f3238d = i9;
        fArr4[i8] = 0.0f;
        int i10 = i9 + 1;
        this.f3238d = i10;
        fArr4[i9] = f10;
        int i11 = i10 + 1;
        this.f3238d = i11;
        fArr4[i10] = f9;
        this.f3238d = i11 + 1;
        fArr4[i11] = p1Var.b();
        float[] fArr5 = this.f3237c;
        int i12 = this.f3238d;
        this.f3238d = i12 + 1;
        fArr5[i12] = p1Var.d();
        float[] fArr6 = this.f3237c;
        int i13 = this.f3238d;
        int i14 = i13 + 1;
        this.f3238d = i14;
        fArr6[i13] = 0.0f;
        int i15 = i14 + 1;
        this.f3238d = i15;
        fArr6[i14] = 0.0f;
        int i16 = i15 + 1;
        this.f3238d = i16;
        fArr6[i15] = 0.0f;
        int i17 = i16 + 1;
        this.f3238d = i17;
        fArr6[i16] = f10;
        int i18 = i17 + 1;
        this.f3238d = i18;
        fArr6[i17] = f11;
        this.f3238d = i18 + 1;
        fArr6[i18] = p1Var.b();
        float[] fArr7 = this.f3237c;
        int i19 = this.f3238d;
        this.f3238d = i19 + 1;
        fArr7[i19] = p1Var.c();
        float[] fArr8 = this.f3237c;
        int i20 = this.f3238d;
        int i21 = i20 + 1;
        this.f3238d = i21;
        fArr8[i20] = 0.0f;
        int i22 = i21 + 1;
        this.f3238d = i22;
        fArr8[i21] = 0.0f;
        int i23 = i22 + 1;
        this.f3238d = i23;
        fArr8[i22] = 0.0f;
        int i24 = i23 + 1;
        this.f3238d = i24;
        fArr8[i23] = f8;
        int i25 = i24 + 1;
        this.f3238d = i25;
        fArr8[i24] = f11;
        this.f3238d = i25 + 1;
        fArr8[i25] = p1Var.a();
        float[] fArr9 = this.f3237c;
        int i26 = this.f3238d;
        this.f3238d = i26 + 1;
        fArr9[i26] = p1Var.c();
        float[] fArr10 = this.f3237c;
        int i27 = this.f3238d;
        int i28 = i27 + 1;
        this.f3238d = i28;
        fArr10[i27] = 0.0f;
        int i29 = i28 + 1;
        this.f3238d = i29;
        fArr10[i28] = 0.0f;
        this.f3238d = i29 + 1;
        fArr10[i29] = 0.0f;
        this.f3239e++;
    }

    public final void d() {
        if (this.f3239e > 0) {
            this.f3236b.e(this.f3237c, 0, this.f3238d);
            this.f3236b.c(this.f3244j, 0, this.f3239e * 6);
            this.f3236b.a();
            this.f3236b.b(4, 0, this.f3239e * 6);
            this.f3236b.f();
        }
    }

    public final void e() {
        d();
        this.f3239e = 0;
        this.f3238d = 0;
    }

    public final void f(float[] fArr) {
        k.d(fArr, "modelMatrix");
        GLES20.glUniform1f(this.f3235a, 0.0f);
        Matrix.multiplyMM(this.f3243i, 0, this.f3240f, 0, fArr, 0);
        GLES20.glUniformMatrix4fv(this.f3242h, 1, false, this.f3243i, 0);
        GLES20.glEnableVertexAttribArray(this.f3242h);
        v1.f3318a.c("SpriteBatch", "mMVPMatricesHandle enable error");
    }

    public final void g() {
        GLES20.glUniform1f(this.f3235a, 1.0f);
        GLES20.glUniformMatrix4fv(this.f3242h, 1, false, this.f3240f, 0);
        GLES20.glEnableVertexAttribArray(this.f3242h);
        v1.f3318a.c("SpriteBatch", "mMVPMatricesHandle enable error");
    }
}
