package l0;

import android.graphics.drawable.PaintDrawable;
import android.graphics.drawable.shapes.RectShape;
import w0.k;

public final class q1 extends PaintDrawable {

    /* renamed from: a  reason: collision with root package name */
    private s1 f3283a;

    public q1(int[] iArr) {
        k.d(iArr, "colors");
        this.f3283a = new s1(iArr);
        setShape(new RectShape());
        setCornerRadius(5.0f);
        setShaderFactory(this.f3283a);
        setDither(true);
    }

    public final s1 a() {
        return this.f3283a;
    }
}
