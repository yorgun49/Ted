package l0;

import android.view.View;
import android.widget.EditText;
import com.te.tem3d.MainActivity;

public final /* synthetic */ class w implements View.OnClickListener {

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ EditText f3320b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ MainActivity f3321c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ EditText f3322d;

    /* renamed from: e  reason: collision with root package name */
    public final /* synthetic */ EditText f3323e;

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ EditText f3324f;

    /* renamed from: g  reason: collision with root package name */
    public final /* synthetic */ EditText f3325g;

    public /* synthetic */ w(EditText editText, MainActivity mainActivity, EditText editText2, EditText editText3, EditText editText4, EditText editText5) {
        this.f3320b = editText;
        this.f3321c = mainActivity;
        this.f3322d = editText2;
        this.f3323e = editText3;
        this.f3324f = editText4;
        this.f3325g = editText5;
    }

    public final void onClick(View view) {
        MainActivity.k2(this.f3320b, this.f3321c, this.f3322d, this.f3323e, this.f3324f, this.f3325g, view);
    }
}
