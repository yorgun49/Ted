package l0;

import android.widget.CompoundButton;
import com.te.tem3d.MainActivity;

public final /* synthetic */ class s0 implements CompoundButton.OnCheckedChangeListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ MainActivity f3294a;

    public /* synthetic */ s0(MainActivity mainActivity) {
        this.f3294a = mainActivity;
    }

    public final void onCheckedChanged(CompoundButton compoundButton, boolean z2) {
        MainActivity.s1(this.f3294a, compoundButton, z2);
    }
}
