package l0;

import android.widget.NumberPicker;
import com.te.tem3d.MainActivity;
import l0.v1;

public final /* synthetic */ class w0 implements NumberPicker.OnValueChangeListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ v1.a f3326a;

    public /* synthetic */ w0(v1.a aVar) {
        this.f3326a = aVar;
    }

    public final void onValueChange(NumberPicker numberPicker, int i2, int i3) {
        MainActivity.r0(this.f3326a, numberPicker, i2, i3);
    }
}
