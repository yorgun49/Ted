package l0;

import android.view.View;
import android.widget.AdapterView;

public final /* synthetic */ class j implements AdapterView.OnItemClickListener {

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ m f3199b;

    public /* synthetic */ j(m mVar) {
        this.f3199b = mVar;
    }

    public final void onItemClick(AdapterView adapterView, View view, int i2, long j2) {
        m.d(this.f3199b, adapterView, view, i2, j2);
    }
}
