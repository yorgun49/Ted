package l0;

import android.view.View;
import android.widget.EditText;
import com.te.tem3d.MainActivity;

public final /* synthetic */ class l0 implements View.OnClickListener {

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ MainActivity f3207b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ EditText f3208c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ EditText f3209d;

    /* renamed from: e  reason: collision with root package name */
    public final /* synthetic */ EditText f3210e;

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ EditText f3211f;

    /* renamed from: g  reason: collision with root package name */
    public final /* synthetic */ EditText f3212g;

    /* renamed from: h  reason: collision with root package name */
    public final /* synthetic */ EditText f3213h;

    /* renamed from: i  reason: collision with root package name */
    public final /* synthetic */ EditText f3214i;

    /* renamed from: j  reason: collision with root package name */
    public final /* synthetic */ EditText f3215j;

    /* renamed from: k  reason: collision with root package name */
    public final /* synthetic */ EditText f3216k;

    /* renamed from: l  reason: collision with root package name */
    public final /* synthetic */ EditText f3217l;

    /* renamed from: m  reason: collision with root package name */
    public final /* synthetic */ EditText f3218m;

    /* renamed from: n  reason: collision with root package name */
    public final /* synthetic */ EditText f3219n;

    public /* synthetic */ l0(MainActivity mainActivity, EditText editText, EditText editText2, EditText editText3, EditText editText4, EditText editText5, EditText editText6, EditText editText7, EditText editText8, EditText editText9, EditText editText10, EditText editText11, EditText editText12) {
        this.f3207b = mainActivity;
        this.f3208c = editText;
        this.f3209d = editText2;
        this.f3210e = editText3;
        this.f3211f = editText4;
        this.f3212g = editText5;
        this.f3213h = editText6;
        this.f3214i = editText7;
        this.f3215j = editText8;
        this.f3216k = editText9;
        this.f3217l = editText10;
        this.f3218m = editText11;
        this.f3219n = editText12;
    }

    public final void onClick(View view) {
        MainActivity.v2(this.f3207b, this.f3208c, this.f3209d, this.f3210e, this.f3211f, this.f3212g, this.f3213h, this.f3214i, this.f3215j, this.f3216k, this.f3217l, this.f3218m, this.f3219n, view);
    }
}
