package l0;

import com.te.tem3d.MainActivity;

public final /* synthetic */ class h1 implements Runnable {

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ MainActivity f3194b;

    public /* synthetic */ h1(MainActivity mainActivity) {
        this.f3194b = mainActivity;
    }

    public final void run() {
        MainActivity.b.e(this.f3194b);
    }
}
