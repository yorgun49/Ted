package l0;

import w0.k;

public final class h extends Exception {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public h(String str) {
        super(str);
        k.d(str, "message");
    }
}
