package l0;

import android.view.View;
import android.widget.FrameLayout;
import android.widget.RadioGroup;
import com.te.tem3d.MainActivity;

public final /* synthetic */ class y0 implements RadioGroup.OnCheckedChangeListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ FrameLayout f3358a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ View f3359b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ MainActivity f3360c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ View f3361d;

    public /* synthetic */ y0(FrameLayout frameLayout, View view, MainActivity mainActivity, View view2) {
        this.f3358a = frameLayout;
        this.f3359b = view;
        this.f3360c = mainActivity;
        this.f3361d = view2;
    }

    public final void onCheckedChanged(RadioGroup radioGroup, int i2) {
        MainActivity.u2(this.f3358a, this.f3359b, this.f3360c, this.f3361d, radioGroup, i2);
    }
}
