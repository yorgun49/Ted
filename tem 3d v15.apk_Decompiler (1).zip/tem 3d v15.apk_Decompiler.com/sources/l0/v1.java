package l0;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.opengl.GLES20;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import com.te.tem3d.R;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import w0.k;

public final class v1 {

    /* renamed from: a  reason: collision with root package name */
    public static final v1 f3318a = new v1();

    /* renamed from: b  reason: collision with root package name */
    private static final String f3319b = "Utilities";

    public interface a {
        void a(String str);
    }

    private v1() {
    }

    /* access modifiers changed from: private */
    public static final void h(a aVar, EditText editText, DialogInterface dialogInterface, int i2) {
        k.d(aVar, "$listener");
        aVar.a(editText.getText().toString());
    }

    /* access modifiers changed from: private */
    public static final void i(DialogInterface dialogInterface, int i2) {
    }

    public final void c(String str, String str2) {
        k.d(str, "dbgDomain");
        k.d(str2, "dbgText");
    }

    public final File d() {
        return new File(Environment.getExternalStorageDirectory().toString() + "/Pictures/Screenshots/Surface3D_" + new SimpleDateFormat("yyyyMMddHHmmss'.png'").format(new Date()));
    }

    public final File e(String str) {
        k.d(str, "path");
        if (!q.A(str, ".png", false, 2, (Object) null)) {
            str = str + ".png";
        }
        return new File(Environment.getExternalStorageDirectory().toString() + "/Pictures/Screenshots/" + str);
    }

    public final int f(int i2, int i3, x1[] x1VarArr) {
        k.d(x1VarArr, "variables");
        int glCreateProgram = GLES20.glCreateProgram();
        if (glCreateProgram != 0) {
            GLES20.glAttachShader(glCreateProgram, i2);
            GLES20.glAttachShader(glCreateProgram, i3);
            for (x1 x1Var : x1VarArr) {
                GLES20.glBindAttribLocation(glCreateProgram, x1Var.b(), x1Var.c());
            }
            GLES20.glLinkProgram(glCreateProgram);
            int[] iArr = new int[1];
            GLES20.glGetProgramiv(glCreateProgram, 35714, iArr, 0);
            if (iArr[0] == 0) {
                GLES20.glDeleteProgram(glCreateProgram);
                glCreateProgram = 0;
            }
        }
        if (glCreateProgram != 0) {
            return glCreateProgram;
        }
        throw new RuntimeException("Error creating program.");
    }

    public final Dialog g(Activity activity, String str, String str2, String str3, a aVar) {
        k.d(activity, "context");
        k.d(str, "title");
        k.d(str2, "msg");
        k.d(str3, "texval");
        k.d(aVar, "listener");
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle(str);
        View inflate = activity.getLayoutInflater().inflate(R.layout.pref_edit_note, (ViewGroup) null);
        EditText editText = (EditText) inflate.findViewById(R.id.noteEt);
        editText.setText(str3);
        builder.setView(inflate);
        builder.setPositiveButton(17039370, new t1(aVar, editText));
        builder.setNegativeButton(17039360, u1.f3310b);
        AlertDialog create = builder.create();
        k.c(create, "builder.create()");
        return create;
    }

    public final int j(int i2, String str) {
        k.d(str, "shaderCode");
        int glCreateShader = GLES20.glCreateShader(i2);
        if (glCreateShader != 0) {
            GLES20.glShaderSource(glCreateShader, str);
            GLES20.glCompileShader(glCreateShader);
            int[] iArr = new int[1];
            GLES20.glGetShaderiv(glCreateShader, 35713, iArr, 0);
            if (iArr[0] == 0) {
                String str2 = f3319b;
                Log.v(str2, "Shader fail info: " + GLES20.glGetShaderInfoLog(glCreateShader));
                GLES20.glDeleteShader(glCreateShader);
                glCreateShader = 0;
            }
        }
        if (glCreateShader != 0) {
            return glCreateShader;
        }
        throw new RuntimeException("Error creating shader " + i2);
    }
}
