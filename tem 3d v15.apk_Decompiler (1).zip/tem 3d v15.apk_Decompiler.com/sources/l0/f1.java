package l0;

import android.view.View;
import android.widget.EditText;
import com.te.tem3d.MainActivity;

public final /* synthetic */ class f1 implements View.OnClickListener {

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ EditText f3187b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ MainActivity f3188c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ EditText f3189d;

    /* renamed from: e  reason: collision with root package name */
    public final /* synthetic */ EditText f3190e;

    public /* synthetic */ f1(EditText editText, MainActivity mainActivity, EditText editText2, EditText editText3) {
        this.f3187b = editText;
        this.f3188c = mainActivity;
        this.f3189d = editText2;
        this.f3190e = editText3;
    }

    public final void onClick(View view) {
        MainActivity.n2(this.f3187b, this.f3188c, this.f3189d, this.f3190e, view);
    }
}
