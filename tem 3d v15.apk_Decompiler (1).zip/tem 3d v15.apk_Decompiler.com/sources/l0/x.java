package l0;

import android.view.View;
import com.te.tem3d.MainActivity;

public final /* synthetic */ class x implements View.OnClickListener {

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ MainActivity f3348b;

    public /* synthetic */ x(MainActivity mainActivity) {
        this.f3348b = mainActivity;
    }

    public final void onClick(View view) {
        MainActivity.v1(this.f3348b, view);
    }
}
