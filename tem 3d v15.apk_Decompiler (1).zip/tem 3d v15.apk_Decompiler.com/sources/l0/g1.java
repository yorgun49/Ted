package l0;

import com.te.tem3d.MainActivity;

public final /* synthetic */ class g1 implements Runnable {

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ MainActivity f3192b;

    public /* synthetic */ g1(MainActivity mainActivity) {
        this.f3192b = mainActivity;
    }

    public final void run() {
        MainActivity.b.g(this.f3192b);
    }
}
