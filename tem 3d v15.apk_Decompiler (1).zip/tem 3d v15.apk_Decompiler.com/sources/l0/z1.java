package l0;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.media.MediaScannerConnection;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.os.Environment;
import android.util.Log;
import com.te.tem3d.MainActivity;
import com.te.tem3d.R;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;
import w0.g;
import w0.k;
import w0.s;
import z.h;
import z.j;

public final class z1 implements GLSurfaceView.Renderer {
    private static final String A0 = "u_Texturemap";
    private static final String B0 = "a_Normal";
    private static final String C0 = "a_MVPMatrixIndex";
    private static final String D0 = "a_TexCoordinate";
    /* access modifiers changed from: private */
    public static final int E0 = 3;
    private static final String F0 = "a_Position";
    /* access modifiers changed from: private */
    public static final int G0 = 3;
    /* access modifiers changed from: private */
    public static final int H0 = 1;
    private static final String I0 = "u_renderMode";
    private static final String J0 = "u_isTextRender";
    /* access modifiers changed from: private */
    public static final int K0;
    /* access modifiers changed from: private */
    public static final int L0;
    /* access modifiers changed from: private */
    public static final String M0 = "Renderer";
    private static final String N0 = "u_transpMode";
    /* access modifiers changed from: private */
    public static int O0;
    private static boolean P0;
    private static float Q0 = 1.0f;
    private static float R0 = -1.0f;
    private static Bitmap S0;
    /* access modifiers changed from: private */
    public static float T0;
    /* access modifiers changed from: private */
    public static float U0;
    /* access modifiers changed from: private */
    public static float V0 = 1.0f;
    /* access modifiers changed from: private */
    public static boolean W0 = true;

    /* renamed from: q0  reason: collision with root package name */
    public static final a f3379q0 = new a((g) null);
    /* access modifiers changed from: private */

    /* renamed from: r0  reason: collision with root package name */
    public static final int f3380r0 = 4;
    /* access modifiers changed from: private */

    /* renamed from: s0  reason: collision with root package name */
    public static final int f3381s0 = 2;

    /* renamed from: t0  reason: collision with root package name */
    private static final String f3382t0 = "a_Color";

    /* renamed from: u0  reason: collision with root package name */
    private static final String f3383u0 = "a_Uv";
    /* access modifiers changed from: private */

    /* renamed from: v0  reason: collision with root package name */
    public static final int f3384v0 = 4;

    /* renamed from: w0  reason: collision with root package name */
    private static final String f3385w0 = "u_colorMode";

    /* renamed from: x0  reason: collision with root package name */
    private static final String f3386x0 = "u_LightPos";

    /* renamed from: y0  reason: collision with root package name */
    private static final String f3387y0 = "u_MVPMatrix";

    /* renamed from: z0  reason: collision with root package name */
    private static final String f3388z0 = "u_MVMatrix";
    private d A;
    private final float[] B = new float[16];
    private final float C = 3.142f;
    /* access modifiers changed from: private */
    public float D = 3.142f;
    private int E;
    private final float[] F = new float[16];
    private int G;
    private final float[] H = new float[16];
    private int I;
    private int J;
    /* access modifiers changed from: private */
    public int K;
    /* access modifiers changed from: private */
    public int L;
    /* access modifiers changed from: private */
    public int M;
    private int N;
    private final float[] O = new float[16];
    private final float[] P = new float[16];
    private int Q;
    private boolean R = true;
    private boolean S;
    /* access modifiers changed from: private */
    public float T = 1.0f;
    private final float[] U = new float[16];
    private float V;
    private float W;
    private float X;
    private float Y;
    private float Z;

    /* renamed from: a  reason: collision with root package name */
    private final MainActivity f3389a;

    /* renamed from: a0  reason: collision with root package name */
    private int f3390a0;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public final i f3391b;
    /* access modifiers changed from: private */

    /* renamed from: b0  reason: collision with root package name */
    public float f3392b0;

    /* renamed from: c  reason: collision with root package name */
    private final Context f3393c;
    /* access modifiers changed from: private */

    /* renamed from: c0  reason: collision with root package name */
    public float[][] f3394c0;

    /* renamed from: d  reason: collision with root package name */
    private float f3395d;

    /* renamed from: d0  reason: collision with root package name */
    private float f3396d0;

    /* renamed from: e  reason: collision with root package name */
    private float f3397e;

    /* renamed from: e0  reason: collision with root package name */
    private float f3398e0;
    /* access modifiers changed from: private */

    /* renamed from: f  reason: collision with root package name */
    public boolean f3399f;

    /* renamed from: f0  reason: collision with root package name */
    private float[][] f3400f0;

    /* renamed from: g  reason: collision with root package name */
    private int f3401g;

    /* renamed from: g0  reason: collision with root package name */
    private float[][] f3402g0;
    /* access modifiers changed from: private */

    /* renamed from: h  reason: collision with root package name */
    public int f3403h = 46;
    /* access modifiers changed from: private */

    /* renamed from: h0  reason: collision with root package name */
    public int f3404h0 = 5;
    /* access modifiers changed from: private */

    /* renamed from: i  reason: collision with root package name */
    public int f3405i = 46;
    /* access modifiers changed from: private */

    /* renamed from: i0  reason: collision with root package name */
    public int f3406i0 = 5;

    /* renamed from: j  reason: collision with root package name */
    private int f3407j;

    /* renamed from: j0  reason: collision with root package name */
    private float f3408j0;

    /* renamed from: k  reason: collision with root package name */
    private final float[] f3409k = new float[16];

    /* renamed from: k0  reason: collision with root package name */
    private final float[] f3410k0 = new float[16];
    /* access modifiers changed from: private */

    /* renamed from: l  reason: collision with root package name */
    public int f3411l;
    /* access modifiers changed from: private */

    /* renamed from: l0  reason: collision with root package name */
    public boolean f3412l0;

    /* renamed from: m  reason: collision with root package name */
    private int f3413m;
    /* access modifiers changed from: private */

    /* renamed from: m0  reason: collision with root package name */
    public o f3414m0;
    /* access modifiers changed from: private */

    /* renamed from: n  reason: collision with root package name */
    public float f3415n = 1.0f;
    /* access modifiers changed from: private */

    /* renamed from: n0  reason: collision with root package name */
    public float f3416n0;
    /* access modifiers changed from: private */

    /* renamed from: o  reason: collision with root package name */
    public int f3417o = 3;
    /* access modifiers changed from: private */

    /* renamed from: o0  reason: collision with root package name */
    public float f3418o0;

    /* renamed from: p  reason: collision with root package name */
    private final float[] f3419p = new float[16];

    /* renamed from: p0  reason: collision with root package name */
    private boolean f3420p0;

    /* renamed from: q  reason: collision with root package name */
    private int f3421q;

    /* renamed from: r  reason: collision with root package name */
    private c f3422r;

    /* renamed from: s  reason: collision with root package name */
    private b f3423s;

    /* renamed from: t  reason: collision with root package name */
    private boolean f3424t;

    /* renamed from: u  reason: collision with root package name */
    private File f3425u;

    /* renamed from: v  reason: collision with root package name */
    private final float[] f3426v = new float[16];

    /* renamed from: w  reason: collision with root package name */
    private final float[] f3427w = new float[4];

    /* renamed from: x  reason: collision with root package name */
    private final float[] f3428x = {0.0f, 0.0f, 0.0f, 1.0f};

    /* renamed from: y  reason: collision with root package name */
    private final float[] f3429y = new float[4];

    /* renamed from: z  reason: collision with root package name */
    private int f3430z;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(g gVar) {
            this();
        }

        public final void a(boolean z2) {
            z1.W0 = z2;
        }

        public final void b(float f2) {
            z1.U0 = f2;
        }

        public final void c(float f2) {
            z1.T0 = f2;
        }

        public final void d(float f2) {
            z1.V0 = f2;
        }
    }

    public final class b {

        /* renamed from: a  reason: collision with root package name */
        private int f3431a = 5;

        /* renamed from: b  reason: collision with root package name */
        private int f3432b = 5;

        /* renamed from: c  reason: collision with root package name */
        private float f3433c = 0.05f;

        /* renamed from: d  reason: collision with root package name */
        private float f3434d = 2.0f;

        /* renamed from: e  reason: collision with root package name */
        private float[] f3435e = {1.0f, 1.0f, 1.0f, 1.0f};

        /* renamed from: f  reason: collision with root package name */
        private float[] f3436f = new float[16];

        public b() {
        }

        public final void a(float[] fArr, o oVar, boolean z2) {
            String str;
            float f2;
            float f3;
            float f4;
            float f5;
            String str2;
            boolean z3;
            int i2;
            ArrayList<ArrayList<Double>> arrayList;
            int i3;
            float f6;
            float f7;
            int i4;
            float[] fArr2 = fArr;
            k.d(fArr2, "mvPmatrix");
            this.f3436f = fArr2;
            this.f3431a = z1.this.f3404h0;
            this.f3432b = z1.this.f3406i0;
            e eVar = new e();
            float w2 = ((float) (z1.this.f3403h - 1)) / ((float) this.f3431a);
            float x2 = ((float) (z1.this.f3405i - 1)) / ((float) this.f3432b);
            float[] fArr3 = new float[(z1.this.f3405i * 3)];
            float f8 = 0.0f;
            float f9 = 0.0f;
            while (true) {
                str = "val_matrix";
                if (f9 >= ((float) z1.this.f3405i)) {
                    break;
                }
                int i5 = (int) f9;
                int w3 = z1.this.f3403h;
                int i6 = 0;
                int i7 = 0;
                while (i6 < w3) {
                    int i8 = i7 + 1;
                    float[][] V = z1.this.V();
                    k.b(V);
                    fArr3[i7] = V[i6][i5];
                    int i9 = i8 + 1;
                    float[][] W = z1.this.W();
                    k.b(W);
                    fArr3[i8] = W[i6][i5];
                    if (z1.this.f3412l0) {
                        i7 = i9 + 1;
                        fArr3[i9] = this.f3433c + f8;
                    } else {
                        int i10 = i9 + 1;
                        float[][] F = z1.this.f3394c0;
                        if (F == null) {
                            k.m(str);
                            F = null;
                        }
                        fArr3[i9] = F[i6][i5] + this.f3433c;
                        i7 = i10;
                    }
                    i6++;
                    f8 = 0.0f;
                }
                eVar.b(fArr3);
                eVar.c(this.f3434d);
                eVar.a();
                float[][] W2 = z1.this.W();
                k.b(W2);
                float f10 = W2[0][i5];
                f9 += x2;
                f8 = 0.0f;
            }
            float[] fArr4 = new float[(z1.this.f3405i * 3)];
            for (float f11 = 0.0f; f11 < ((float) z1.this.f3403h); f11 += w2) {
                int i11 = (int) f11;
                int i12 = 0;
                for (int i13 = 0; i13 < z1.this.f3405i; i13++) {
                    int i14 = i12 + 1;
                    float[][] V2 = z1.this.V();
                    k.b(V2);
                    fArr4[i12] = V2[i11][i13];
                    int i15 = i14 + 1;
                    float[][] W3 = z1.this.W();
                    k.b(W3);
                    fArr4[i14] = W3[i11][i13];
                    if (z1.this.f3412l0) {
                        i4 = i15 + 1;
                        fArr4[i15] = this.f3433c + 0.0f;
                    } else {
                        i4 = i15 + 1;
                        float[][] F2 = z1.this.f3394c0;
                        if (F2 == null) {
                            k.m(str);
                            F2 = null;
                        }
                        fArr4[i15] = F2[i11][i13] + this.f3433c;
                    }
                    i12 = i4;
                }
                eVar.b(fArr4);
                eVar.c(this.f3434d);
                eVar.a();
            }
            boolean z4 = j.f4399n.a().j() == j.d.emf;
            ArrayList<ArrayList<Double>> l2 = h.f4378j.a().l();
            float[][] V3 = z1.this.V();
            k.b(V3);
            int length = V3.length;
            if (z4) {
                float a2 = z1.this.N();
                k.b(l2);
                f2 = a2;
                f3 = (float) l2.size();
                f4 = (float) l2.get(0).size();
            } else {
                f4 = 0.0f;
                f3 = 0.0f;
                f2 = 0.0f;
            }
            float[][] W4 = z1.this.W();
            k.b(W4);
            k.b(W4);
            int length2 = W4[0].length;
            boolean z5 = z1.this.T() - z1.this.U() < 1.5f;
            k.b(oVar);
            int i16 = length2;
            float f12 = f4;
            float f13 = f3;
            oVar.b(1.0f, 1.0f, 0.0f, 1.0f, fArr);
            o m2 = z1.this.f3414m0;
            k.b(m2);
            m2.p(0.05f);
            if (!oVar.q()) {
                float f14 = 0.0f;
                int i17 = 0;
                while (f14 < ((float) z1.this.f3405i) - x2) {
                    float f15 = 0.0f;
                    int i18 = 0;
                    while (f15 < ((float) z1.this.f3403h) - w2) {
                        int i19 = (int) f15;
                        int i20 = (int) f14;
                        if (i19 >= length || i18 >= length || i20 >= i16 || i17 >= i16) {
                            z3 = z4;
                            arrayList = l2;
                            i3 = length;
                            str2 = str;
                            f5 = f12;
                            i2 = i16;
                        } else {
                            i3 = length;
                            float[][] V4 = z1.this.V();
                            k.b(V4);
                            float f16 = V4[i19][i20];
                            float[][] W5 = z1.this.W();
                            k.b(W5);
                            float f17 = W5[i19][i20];
                            k.b(l2);
                            Object obj = l2.get(i18).get(i17);
                            arrayList = l2;
                            k.c(obj, "tmplist!![counti][countj]");
                            double doubleValue = ((Number) obj).doubleValue();
                            i2 = i16;
                            if (z1.this.f3412l0) {
                                f6 = 0.0f;
                            } else {
                                float[][] F3 = z1.this.f3394c0;
                                if (F3 == null) {
                                    k.m(str);
                                    F3 = null;
                                }
                                f6 = F3[i19][i20];
                            }
                            float f18 = (float) doubleValue;
                            float c2 = z1.this.Q(f18);
                            if (z4) {
                                z3 = z4;
                                f7 = f13;
                                c2 = z1.this.P(f18, f7, f12, f2);
                            } else {
                                z3 = z4;
                                f7 = f13;
                            }
                            if (z5) {
                                c2 = 0.0f;
                            }
                            f13 = f7;
                            str2 = str;
                            if (!z1.this.f3399f) {
                                o m3 = z1.this.f3414m0;
                                k.b(m3);
                                s sVar = s.f4287a;
                                f5 = f12;
                                String format = String.format(Locale.ENGLISH, "%.2f", Arrays.copyOf(new Object[]{Double.valueOf(doubleValue)}, 1));
                                k.c(format, "format(locale, format, *args)");
                                m3.a(format, f16, f17, f6 + this.f3433c, 0.0f);
                            } else {
                                f5 = f12;
                                o m4 = z1.this.f3414m0;
                                k.b(m4);
                                s sVar2 = s.f4287a;
                                String format2 = String.format(Locale.ENGLISH, "%.2f", Arrays.copyOf(new Object[]{Float.valueOf(c2)}, 1));
                                k.c(format2, "format(locale, format, *args)");
                                m4.a(format2, f16, f17, f6 + this.f3433c, 0.0f);
                            }
                            i18++;
                        }
                        f15 += w2;
                        length = i3;
                        l2 = arrayList;
                        i16 = i2;
                        z4 = z3;
                        str = str2;
                        f12 = f5;
                    }
                    boolean z6 = z4;
                    ArrayList<ArrayList<Double>> arrayList2 = l2;
                    String str3 = str;
                    float f19 = f12;
                    i17++;
                    f14 += x2;
                    length = length;
                    i16 = i16;
                }
            }
            o m5 = z1.this.f3414m0;
            k.b(m5);
            m5.i();
            oVar.j();
        }
    }

    private final class c {

        /* renamed from: a  reason: collision with root package name */
        private final int[] f3438a;

        /* renamed from: b  reason: collision with root package name */
        private int f3439b;

        /* renamed from: c  reason: collision with root package name */
        private final int[] f3440c;

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ z1 f3441d;

        /* JADX WARNING: type inference failed for: r1v5 */
        /* JADX WARNING: type inference failed for: r1v17 */
        /* JADX WARNING: type inference failed for: r1v20 */
        /* JADX WARNING: type inference failed for: r1v21 */
        /* JADX WARNING: Multi-variable type inference failed */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public c(l0.z1 r23) {
            /*
                r22 = this;
                r1 = r22
                r0 = r23
                r1.f3441d = r0
                r22.<init>()
                r2 = 1
                int[] r3 = new int[r2]
                r1.f3438a = r3
                int[] r3 = new int[r2]
                r1.f3440c = r3
                int r3 = r23.f3403h     // Catch:{ all -> 0x0436 }
                int r4 = r23.f3405i     // Catch:{ all -> 0x0436 }
                int r5 = r3 * r4
                int r6 = l0.z1.K0     // Catch:{ all -> 0x0436 }
                int r5 = r5 * r6
                float[] r6 = new float[r5]     // Catch:{ all -> 0x0436 }
                r23.T()     // Catch:{ all -> 0x0436 }
                r23.U()     // Catch:{ all -> 0x0436 }
                float r7 = r23.T()     // Catch:{ all -> 0x0436 }
                float r8 = r23.U()     // Catch:{ all -> 0x0436 }
                int r7 = (r7 > r8 ? 1 : (r7 == r8 ? 0 : -1))
                if (r7 <= 0) goto L_0x003c
                r23.T()     // Catch:{ all -> 0x0436 }
                r23.U()     // Catch:{ all -> 0x0436 }
            L_0x003c:
                float[][] r7 = r23.V()     // Catch:{ all -> 0x0436 }
                if (r7 == 0) goto L_0x0452
                l0.y1 r7 = l0.y1.f3362a     // Catch:{ all -> 0x0436 }
                r7.h()     // Catch:{ all -> 0x0436 }
                r23.Z()     // Catch:{ all -> 0x0436 }
                r7 = 0
                r0.D = r7     // Catch:{ all -> 0x0436 }
                r0 = 0
                r8 = 0
                r14 = 0
            L_0x0051:
                if (r14 >= r4) goto L_0x034f
                r13 = 0
            L_0x0054:
                if (r13 >= r3) goto L_0x0346
                int r9 = r8 + 1
                l0.z1 r10 = r1.f3441d     // Catch:{ all -> 0x0436 }
                float[][] r10 = r10.V()     // Catch:{ all -> 0x0436 }
                w0.k.b(r10)     // Catch:{ all -> 0x0436 }
                r10 = r10[r13]     // Catch:{ all -> 0x0436 }
                r10 = r10[r14]     // Catch:{ all -> 0x0436 }
                r6[r8] = r10     // Catch:{ all -> 0x0436 }
                int r8 = r9 + 1
                l0.z1 r10 = r1.f3441d     // Catch:{ all -> 0x0436 }
                float[][] r10 = r10.W()     // Catch:{ all -> 0x0436 }
                w0.k.b(r10)     // Catch:{ all -> 0x0436 }
                r10 = r10[r13]     // Catch:{ all -> 0x0436 }
                r10 = r10[r14]     // Catch:{ all -> 0x0436 }
                r6[r9] = r10     // Catch:{ all -> 0x0436 }
                l0.z1 r9 = r1.f3441d     // Catch:{ all -> 0x0436 }
                float[][] r9 = r9.f3394c0     // Catch:{ all -> 0x0436 }
                java.lang.String r11 = "val_matrix"
                if (r9 != 0) goto L_0x0086
                w0.k.m(r11)     // Catch:{ all -> 0x0436 }
                r9 = 0
            L_0x0086:
                r9 = r9[r13]     // Catch:{ all -> 0x0436 }
                r16 = r9[r14]     // Catch:{ all -> 0x0436 }
                l0.z1 r9 = r1.f3441d     // Catch:{ all -> 0x0436 }
                boolean r9 = r9.f3412l0     // Catch:{ all -> 0x0436 }
                r17 = 1065353216(0x3f800000, float:1.0)
                if (r9 == 0) goto L_0x0099
                int r9 = r8 + 1
                r6[r8] = r7     // Catch:{ all -> 0x0436 }
                goto L_0x009f
            L_0x0099:
                int r9 = r8 + 1
                float r12 = r16 / r17
                r6[r8] = r12     // Catch:{ all -> 0x0436 }
            L_0x009f:
                l0.z1 r8 = r1.f3441d     // Catch:{ all -> 0x0436 }
                float[][] r8 = r8.f3394c0     // Catch:{ all -> 0x0436 }
                if (r8 != 0) goto L_0x00ab
                w0.k.m(r11)     // Catch:{ all -> 0x0436 }
                r8 = 0
            L_0x00ab:
                r8 = r8[r13]     // Catch:{ all -> 0x0436 }
                r8 = r8[r14]     // Catch:{ all -> 0x0436 }
                l0.z1 r12 = r1.f3441d     // Catch:{ all -> 0x0436 }
                float r12 = r12.U()     // Catch:{ all -> 0x0436 }
                float r8 = r8 - r12
                if (r13 != 0) goto L_0x00dc
                l0.z1 r12 = r1.f3441d     // Catch:{ all -> 0x0436 }
                float[][] r12 = r12.f3394c0     // Catch:{ all -> 0x0436 }
                if (r12 != 0) goto L_0x00c4
                w0.k.m(r11)     // Catch:{ all -> 0x0436 }
                r12 = 0
            L_0x00c4:
                int r18 = r13 + 1
                r12 = r12[r18]     // Catch:{ all -> 0x0436 }
                r12 = r12[r14]     // Catch:{ all -> 0x0436 }
                l0.z1 r10 = r1.f3441d     // Catch:{ all -> 0x0436 }
                float[][] r10 = r10.f3394c0     // Catch:{ all -> 0x0436 }
                if (r10 != 0) goto L_0x00d6
                w0.k.m(r11)     // Catch:{ all -> 0x0436 }
                r10 = 0
            L_0x00d6:
                r10 = r10[r13]     // Catch:{ all -> 0x0436 }
                r10 = r10[r14]     // Catch:{ all -> 0x0436 }
                float r12 = r12 - r10
                goto L_0x0100
            L_0x00dc:
                l0.z1 r10 = r1.f3441d     // Catch:{ all -> 0x0436 }
                float[][] r10 = r10.f3394c0     // Catch:{ all -> 0x0436 }
                if (r10 != 0) goto L_0x00e8
                w0.k.m(r11)     // Catch:{ all -> 0x0436 }
                r10 = 0
            L_0x00e8:
                r10 = r10[r13]     // Catch:{ all -> 0x0436 }
                r10 = r10[r14]     // Catch:{ all -> 0x0436 }
                l0.z1 r12 = r1.f3441d     // Catch:{ all -> 0x0436 }
                float[][] r12 = r12.f3394c0     // Catch:{ all -> 0x0436 }
                if (r12 != 0) goto L_0x00f8
                w0.k.m(r11)     // Catch:{ all -> 0x0436 }
                r12 = 0
            L_0x00f8:
                int r18 = r13 + -1
                r12 = r12[r18]     // Catch:{ all -> 0x0436 }
                r12 = r12[r14]     // Catch:{ all -> 0x0436 }
                float r12 = r10 - r12
            L_0x0100:
                if (r14 != 0) goto L_0x0125
                l0.z1 r10 = r1.f3441d     // Catch:{ all -> 0x0436 }
                float[][] r10 = r10.f3394c0     // Catch:{ all -> 0x0436 }
                if (r10 != 0) goto L_0x010e
                w0.k.m(r11)     // Catch:{ all -> 0x0436 }
                r10 = 0
            L_0x010e:
                r10 = r10[r13]     // Catch:{ all -> 0x0436 }
                int r18 = r14 + 1
                r10 = r10[r18]     // Catch:{ all -> 0x0436 }
                l0.z1 r15 = r1.f3441d     // Catch:{ all -> 0x0436 }
                float[][] r15 = r15.f3394c0     // Catch:{ all -> 0x0436 }
                if (r15 != 0) goto L_0x0120
                w0.k.m(r11)     // Catch:{ all -> 0x0436 }
                r15 = 0
            L_0x0120:
                r11 = r15[r13]     // Catch:{ all -> 0x0436 }
                r11 = r11[r14]     // Catch:{ all -> 0x0436 }
                goto L_0x0147
            L_0x0125:
                l0.z1 r10 = r1.f3441d     // Catch:{ all -> 0x0436 }
                float[][] r10 = r10.f3394c0     // Catch:{ all -> 0x0436 }
                if (r10 != 0) goto L_0x0131
                w0.k.m(r11)     // Catch:{ all -> 0x0436 }
                r10 = 0
            L_0x0131:
                r10 = r10[r13]     // Catch:{ all -> 0x0436 }
                r10 = r10[r14]     // Catch:{ all -> 0x0436 }
                l0.z1 r15 = r1.f3441d     // Catch:{ all -> 0x0436 }
                float[][] r15 = r15.f3394c0     // Catch:{ all -> 0x0436 }
                if (r15 != 0) goto L_0x0141
                w0.k.m(r11)     // Catch:{ all -> 0x0436 }
                r15 = 0
            L_0x0141:
                r11 = r15[r13]     // Catch:{ all -> 0x0436 }
                int r15 = r14 + -1
                r11 = r11[r15]     // Catch:{ all -> 0x0436 }
            L_0x0147:
                float r10 = r10 - r11
                if (r13 != 0) goto L_0x0167
                l0.z1 r11 = r1.f3441d     // Catch:{ all -> 0x0436 }
                float[][] r11 = r11.V()     // Catch:{ all -> 0x0436 }
                w0.k.b(r11)     // Catch:{ all -> 0x0436 }
                int r15 = r13 + 1
                r11 = r11[r15]     // Catch:{ all -> 0x0436 }
                r11 = r11[r14]     // Catch:{ all -> 0x0436 }
                l0.z1 r15 = r1.f3441d     // Catch:{ all -> 0x0436 }
                float[][] r15 = r15.V()     // Catch:{ all -> 0x0436 }
                w0.k.b(r15)     // Catch:{ all -> 0x0436 }
                r15 = r15[r13]     // Catch:{ all -> 0x0436 }
                r15 = r15[r14]     // Catch:{ all -> 0x0436 }
                goto L_0x0183
            L_0x0167:
                l0.z1 r11 = r1.f3441d     // Catch:{ all -> 0x0436 }
                float[][] r11 = r11.V()     // Catch:{ all -> 0x0436 }
                w0.k.b(r11)     // Catch:{ all -> 0x0436 }
                r11 = r11[r13]     // Catch:{ all -> 0x0436 }
                r11 = r11[r14]     // Catch:{ all -> 0x0436 }
                l0.z1 r15 = r1.f3441d     // Catch:{ all -> 0x0436 }
                float[][] r15 = r15.V()     // Catch:{ all -> 0x0436 }
                w0.k.b(r15)     // Catch:{ all -> 0x0436 }
                int r19 = r13 + -1
                r15 = r15[r19]     // Catch:{ all -> 0x0436 }
                r15 = r15[r14]     // Catch:{ all -> 0x0436 }
            L_0x0183:
                float r11 = r11 - r15
                if (r14 != 0) goto L_0x01a4
                l0.z1 r15 = r1.f3441d     // Catch:{ all -> 0x0436 }
                float[][] r15 = r15.W()     // Catch:{ all -> 0x0436 }
                w0.k.b(r15)     // Catch:{ all -> 0x0436 }
                r15 = r15[r13]     // Catch:{ all -> 0x0436 }
                int r19 = r14 + 1
                r15 = r15[r19]     // Catch:{ all -> 0x0436 }
                l0.z1 r2 = r1.f3441d     // Catch:{ all -> 0x0436 }
                float[][] r2 = r2.W()     // Catch:{ all -> 0x0436 }
                w0.k.b(r2)     // Catch:{ all -> 0x0436 }
                r2 = r2[r13]     // Catch:{ all -> 0x0436 }
                r2 = r2[r14]     // Catch:{ all -> 0x0436 }
                float r15 = r15 - r2
                goto L_0x01c2
            L_0x01a4:
                l0.z1 r2 = r1.f3441d     // Catch:{ all -> 0x0436 }
                float[][] r2 = r2.W()     // Catch:{ all -> 0x0436 }
                w0.k.b(r2)     // Catch:{ all -> 0x0436 }
                r2 = r2[r13]     // Catch:{ all -> 0x0436 }
                r2 = r2[r14]     // Catch:{ all -> 0x0436 }
                l0.z1 r15 = r1.f3441d     // Catch:{ all -> 0x0436 }
                float[][] r15 = r15.W()     // Catch:{ all -> 0x0436 }
                w0.k.b(r15)     // Catch:{ all -> 0x0436 }
                r15 = r15[r13]     // Catch:{ all -> 0x0436 }
                int r20 = r14 + -1
                r15 = r15[r20]     // Catch:{ all -> 0x0436 }
                float r15 = r2 - r15
            L_0x01c2:
                r2 = 3
                float[] r7 = new float[r2]     // Catch:{ all -> 0x0436 }
                r7[r0] = r17     // Catch:{ all -> 0x0436 }
                r19 = 1
                r20 = 0
                r7[r19] = r20     // Catch:{ all -> 0x0436 }
                float r21 = java.lang.Math.signum(r11)     // Catch:{ all -> 0x0436 }
                float r21 = r21 * r12
                float r21 = r21 / r11
                float r21 = r21 * r17
                r11 = 2
                r7[r11] = r21     // Catch:{ all -> 0x0436 }
                float[] r11 = new float[r2]     // Catch:{ all -> 0x0436 }
                r11[r0] = r20     // Catch:{ all -> 0x0436 }
                r12 = 1
                r11[r12] = r17     // Catch:{ all -> 0x0436 }
                float r12 = java.lang.Math.signum(r15)     // Catch:{ all -> 0x0436 }
                float r12 = -r12
                float r12 = r12 * r10
                float r12 = r12 / r15
                float r12 = r12 * r17
                r10 = 2
                r11[r10] = r12     // Catch:{ all -> 0x0436 }
                float[] r2 = new float[r2]     // Catch:{ all -> 0x0436 }
                r12 = 1
                r15 = r7[r12]     // Catch:{ all -> 0x0436 }
                r18 = r11[r10]     // Catch:{ all -> 0x0436 }
                float r15 = r15 * r18
                r18 = r7[r10]     // Catch:{ all -> 0x0436 }
                r21 = r11[r12]     // Catch:{ all -> 0x0436 }
                float r18 = r18 * r21
                float r15 = r15 - r18
                r2[r0] = r15     // Catch:{ all -> 0x0436 }
                r12 = r7[r10]     // Catch:{ all -> 0x0436 }
                r15 = r11[r0]     // Catch:{ all -> 0x0436 }
                float r12 = r12 * r15
                r15 = r7[r0]     // Catch:{ all -> 0x0436 }
                r21 = r11[r10]     // Catch:{ all -> 0x0436 }
                float r15 = r15 * r21
                float r12 = r12 - r15
                r10 = 1
                r2[r10] = r12     // Catch:{ all -> 0x0436 }
                r12 = r7[r0]     // Catch:{ all -> 0x0436 }
                r15 = r11[r10]     // Catch:{ all -> 0x0436 }
                float r12 = r12 * r15
                r7 = r7[r10]     // Catch:{ all -> 0x0436 }
                r11 = r11[r0]     // Catch:{ all -> 0x0436 }
                float r7 = r7 * r11
                float r12 = r12 - r7
                r7 = 2
                r2[r7] = r12     // Catch:{ all -> 0x0436 }
                r11 = r2[r0]     // Catch:{ all -> 0x0436 }
                r12 = r2[r10]     // Catch:{ all -> 0x0436 }
                r10 = r2[r7]     // Catch:{ all -> 0x0436 }
                float r7 = android.opengl.Matrix.length(r11, r12, r10)     // Catch:{ all -> 0x0436 }
                int r10 = r9 + 1
                r11 = r2[r0]     // Catch:{ all -> 0x0436 }
                float r11 = r11 / r7
                r6[r9] = r11     // Catch:{ all -> 0x0436 }
                int r9 = r10 + 1
                r11 = 1
                r12 = r2[r11]     // Catch:{ all -> 0x0436 }
                float r12 = r12 / r7
                r6[r10] = r12     // Catch:{ all -> 0x0436 }
                int r15 = r9 + 1
                r10 = 2
                r2 = r2[r10]     // Catch:{ all -> 0x0436 }
                float r2 = r2 / r7
                r6[r9] = r2     // Catch:{ all -> 0x0436 }
                l0.z1 r2 = r1.f3441d     // Catch:{ all -> 0x0436 }
                float r2 = r2.T()     // Catch:{ all -> 0x0436 }
                l0.z1 r7 = r1.f3441d     // Catch:{ all -> 0x0436 }
                float r7 = r7.U()     // Catch:{ all -> 0x0436 }
                float r2 = r2 - r7
                l0.z1 r7 = r1.f3441d     // Catch:{ all -> 0x0436 }
                int r7 = r7.f3417o     // Catch:{ all -> 0x0436 }
                r9 = 5
                if (r7 >= r9) goto L_0x0264
                r7 = 1069547520(0x3fc00000, float:1.5)
                int r7 = (r2 > r7 ? 1 : (r2 == r7 ? 0 : -1))
                if (r7 >= 0) goto L_0x0261
                r2 = 1056964608(0x3f000000, float:0.5)
                goto L_0x0294
            L_0x0261:
                float r2 = r8 / r2
                goto L_0x0294
            L_0x0264:
                l0.z1 r7 = r1.f3441d     // Catch:{ all -> 0x0436 }
                int r7 = r7.f3417o     // Catch:{ all -> 0x0436 }
                r9 = 1
                int r7 = r7 - r9
                l0.z1 r9 = r1.f3441d     // Catch:{ all -> 0x0436 }
                int r9 = r9.f3417o     // Catch:{ all -> 0x0436 }
                r10 = 6
                if (r9 != r10) goto L_0x0279
                r9 = -1097229926(0xffffffffbe99999a, float:-0.3)
                goto L_0x027a
            L_0x0279:
                r9 = 0
            L_0x027a:
                r10 = 4616752568008179712(0x4012000000000000, double:4.5)
                double r0 = (double) r7
                java.lang.Double.isNaN(r0)
                double r10 = r10 - r0
                float r0 = (float) r10
                float r0 = r0 + r9
                float r8 = r8 / r2
                r1 = 1058642330(0x3f19999a, float:0.6)
                float r8 = r8 * r1
                float r0 = r0 + r8
                r1 = 1084227584(0x40a00000, float:5.0)
                float r0 = r0 * r1
                float r0 = r0 * r17
                r1 = 1077936128(0x40400000, float:3.0)
                float r2 = r0 / r1
            L_0x0294:
                l0.y1 r8 = l0.y1.f3362a     // Catch:{ all -> 0x0341 }
                double r9 = (double) r2     // Catch:{ all -> 0x0341 }
                r11 = r13
                r12 = r14
                r0 = r13
                r13 = r16
                int r1 = r8.e(r9, r11, r12, r13)     // Catch:{ all -> 0x0341 }
                int r7 = android.graphics.Color.red(r1)     // Catch:{ all -> 0x0341 }
                float r7 = (float) r7     // Catch:{ all -> 0x0341 }
                r8 = 1132396544(0x437f0000, float:255.0)
                float r7 = r7 / r8
                int r9 = android.graphics.Color.green(r1)     // Catch:{ all -> 0x0341 }
                float r9 = (float) r9     // Catch:{ all -> 0x0341 }
                float r9 = r9 / r8
                int r1 = android.graphics.Color.blue(r1)     // Catch:{ all -> 0x0341 }
                float r1 = (float) r1     // Catch:{ all -> 0x0341 }
                float r1 = r1 / r8
                int r8 = (r7 > r17 ? 1 : (r7 == r17 ? 0 : -1))
                if (r8 <= 0) goto L_0x02ba
                r7 = 1065353216(0x3f800000, float:1.0)
            L_0x02ba:
                int r8 = (r9 > r17 ? 1 : (r9 == r17 ? 0 : -1))
                if (r8 <= 0) goto L_0x02c0
                r9 = 1065353216(0x3f800000, float:1.0)
            L_0x02c0:
                int r8 = (r1 > r17 ? 1 : (r1 == r17 ? 0 : -1))
                if (r8 <= 0) goto L_0x02c6
                r1 = 1065353216(0x3f800000, float:1.0)
            L_0x02c6:
                int r8 = r15 + 1
                r6[r15] = r7     // Catch:{ all -> 0x0341 }
                int r7 = r8 + 1
                r6[r8] = r9     // Catch:{ all -> 0x0341 }
                int r8 = r7 + 1
                r6[r7] = r1     // Catch:{ all -> 0x0341 }
                int r1 = r8 + 1
                r6[r8] = r17     // Catch:{ all -> 0x0341 }
                int r8 = r1 + 1
                r6[r1] = r2     // Catch:{ all -> 0x0341 }
                r1 = r22
                l0.z1 r2 = r1.f3441d     // Catch:{ all -> 0x0436 }
                float[][] r2 = r2.V()     // Catch:{ all -> 0x0436 }
                w0.k.b(r2)     // Catch:{ all -> 0x0436 }
                r2 = r2[r0]     // Catch:{ all -> 0x0436 }
                r2 = r2[r14]     // Catch:{ all -> 0x0436 }
                float r2 = java.lang.Math.abs(r2)     // Catch:{ all -> 0x0436 }
                l0.z1 r7 = r1.f3441d     // Catch:{ all -> 0x0436 }
                float r7 = r7.D     // Catch:{ all -> 0x0436 }
                int r2 = (r2 > r7 ? 1 : (r2 == r7 ? 0 : -1))
                if (r2 <= 0) goto L_0x030b
                l0.z1 r2 = r1.f3441d     // Catch:{ all -> 0x0436 }
                float[][] r7 = r2.V()     // Catch:{ all -> 0x0436 }
                w0.k.b(r7)     // Catch:{ all -> 0x0436 }
                r7 = r7[r0]     // Catch:{ all -> 0x0436 }
                r7 = r7[r14]     // Catch:{ all -> 0x0436 }
                float r7 = java.lang.Math.abs(r7)     // Catch:{ all -> 0x0436 }
                r2.D = r7     // Catch:{ all -> 0x0436 }
            L_0x030b:
                l0.z1 r2 = r1.f3441d     // Catch:{ all -> 0x0436 }
                float[][] r2 = r2.W()     // Catch:{ all -> 0x0436 }
                w0.k.b(r2)     // Catch:{ all -> 0x0436 }
                r2 = r2[r0]     // Catch:{ all -> 0x0436 }
                r2 = r2[r14]     // Catch:{ all -> 0x0436 }
                float r2 = java.lang.Math.abs(r2)     // Catch:{ all -> 0x0436 }
                l0.z1 r7 = r1.f3441d     // Catch:{ all -> 0x0436 }
                float r7 = r7.D     // Catch:{ all -> 0x0436 }
                int r2 = (r2 > r7 ? 1 : (r2 == r7 ? 0 : -1))
                if (r2 <= 0) goto L_0x033a
                l0.z1 r2 = r1.f3441d     // Catch:{ all -> 0x0436 }
                float[][] r7 = r2.W()     // Catch:{ all -> 0x0436 }
                w0.k.b(r7)     // Catch:{ all -> 0x0436 }
                r7 = r7[r0]     // Catch:{ all -> 0x0436 }
                r7 = r7[r14]     // Catch:{ all -> 0x0436 }
                float r7 = java.lang.Math.abs(r7)     // Catch:{ all -> 0x0436 }
                r2.D = r7     // Catch:{ all -> 0x0436 }
            L_0x033a:
                int r13 = r0 + 1
                r0 = 0
                r2 = 1
                r7 = 0
                goto L_0x0054
            L_0x0341:
                r0 = move-exception
                r1 = r22
                goto L_0x0437
            L_0x0346:
                r20 = 0
                int r14 = r14 + 1
                r0 = 0
                r2 = 1
                r7 = 0
                goto L_0x0051
            L_0x034f:
                int r0 = r4 + -1
                int r2 = r3 * 2
                int r2 = r2 * r0
                int r7 = r0 + -1
                r8 = 2
                int r7 = r7 * 2
                int r2 = r2 + r7
                short[] r7 = new short[r2]     // Catch:{ all -> 0x0436 }
                r8 = 0
                r9 = 0
            L_0x035f:
                if (r8 >= r0) goto L_0x0399
                if (r8 <= 0) goto L_0x036b
                int r10 = r9 + 1
                int r11 = r8 * r4
                short r11 = (short) r11     // Catch:{ all -> 0x0436 }
                r7[r9] = r11     // Catch:{ all -> 0x0436 }
                r9 = r10
            L_0x036b:
                r10 = r9
                r9 = 0
            L_0x036d:
                if (r9 >= r3) goto L_0x0384
                int r11 = r10 + 1
                int r12 = r8 * r4
                int r12 = r12 + r9
                short r12 = (short) r12     // Catch:{ all -> 0x0436 }
                r7[r10] = r12     // Catch:{ all -> 0x0436 }
                int r10 = r11 + 1
                int r12 = r8 + 1
                int r12 = r12 * r4
                int r12 = r12 + r9
                short r12 = (short) r12     // Catch:{ all -> 0x0436 }
                r7[r11] = r12     // Catch:{ all -> 0x0436 }
                int r9 = r9 + 1
                goto L_0x036d
            L_0x0384:
                int r9 = r4 + -2
                if (r8 >= r9) goto L_0x0395
                int r9 = r10 + 1
                int r11 = r8 + 1
                int r11 = r11 * r4
                int r12 = r3 + -1
                int r11 = r11 + r12
                short r11 = (short) r11     // Catch:{ all -> 0x0436 }
                r7[r10] = r11     // Catch:{ all -> 0x0436 }
                goto L_0x0396
            L_0x0395:
                r9 = r10
            L_0x0396:
                int r8 = r8 + 1
                goto L_0x035f
            L_0x0399:
                r1.f3439b = r2     // Catch:{ all -> 0x0436 }
                int r0 = l0.z1.f3380r0     // Catch:{ all -> 0x0436 }
                int r5 = r5 * r0
                java.nio.ByteBuffer r0 = java.nio.ByteBuffer.allocateDirect(r5)     // Catch:{ all -> 0x0436 }
                java.nio.ByteOrder r3 = java.nio.ByteOrder.nativeOrder()     // Catch:{ all -> 0x0436 }
                java.nio.ByteBuffer r0 = r0.order(r3)     // Catch:{ all -> 0x0436 }
                java.nio.FloatBuffer r0 = r0.asFloatBuffer()     // Catch:{ all -> 0x0436 }
                java.nio.FloatBuffer r3 = r0.put(r6)     // Catch:{ all -> 0x0436 }
                r4 = 0
                r3.position(r4)     // Catch:{ all -> 0x0436 }
                int r3 = l0.z1.f3381s0     // Catch:{ all -> 0x0436 }
                int r2 = r2 * r3
                java.nio.ByteBuffer r2 = java.nio.ByteBuffer.allocateDirect(r2)     // Catch:{ all -> 0x0436 }
                java.nio.ByteOrder r3 = java.nio.ByteOrder.nativeOrder()     // Catch:{ all -> 0x0436 }
                java.nio.ByteBuffer r2 = r2.order(r3)     // Catch:{ all -> 0x0436 }
                java.nio.ShortBuffer r2 = r2.asShortBuffer()     // Catch:{ all -> 0x0436 }
                java.nio.ShortBuffer r3 = r2.put(r7)     // Catch:{ all -> 0x0436 }
                r4 = 0
                r3.position(r4)     // Catch:{ all -> 0x0436 }
                int[] r3 = r1.f3440c     // Catch:{ all -> 0x0436 }
                r5 = 1
                android.opengl.GLES20.glGenBuffers(r5, r3, r4)     // Catch:{ all -> 0x0436 }
                int[] r3 = r1.f3438a     // Catch:{ all -> 0x0436 }
                android.opengl.GLES20.glGenBuffers(r5, r3, r4)     // Catch:{ all -> 0x0436 }
                int[] r3 = r1.f3440c     // Catch:{ all -> 0x0436 }
                r3 = r3[r4]     // Catch:{ all -> 0x0436 }
                if (r3 <= 0) goto L_0x03ee
                int[] r3 = r1.f3438a     // Catch:{ all -> 0x0436 }
                r3 = r3[r4]     // Catch:{ all -> 0x0436 }
                if (r3 > 0) goto L_0x03fb
            L_0x03ee:
                l0.z1 r3 = r1.f3441d     // Catch:{ all -> 0x0436 }
                l0.i r3 = r3.f3391b     // Catch:{ all -> 0x0436 }
                l0.i$a r4 = l0.i.a.BUFFER_CREATION_ERROR     // Catch:{ all -> 0x0436 }
                java.lang.String r5 = "glGenBuffers"
                r3.a(r4, r5)     // Catch:{ all -> 0x0436 }
            L_0x03fb:
                int[] r3 = r1.f3440c     // Catch:{ all -> 0x0436 }
                r4 = 0
                r3 = r3[r4]     // Catch:{ all -> 0x0436 }
                r4 = 34962(0x8892, float:4.8992E-41)
                android.opengl.GLES20.glBindBuffer(r4, r3)     // Catch:{ all -> 0x0436 }
                int r3 = r0.capacity()     // Catch:{ all -> 0x0436 }
                int r5 = l0.z1.f3380r0     // Catch:{ all -> 0x0436 }
                int r3 = r3 * r5
                r5 = 35044(0x88e4, float:4.9107E-41)
                android.opengl.GLES20.glBufferData(r4, r3, r0, r5)     // Catch:{ all -> 0x0436 }
                int[] r0 = r1.f3438a     // Catch:{ all -> 0x0436 }
                r3 = 0
                r0 = r0[r3]     // Catch:{ all -> 0x0436 }
                r3 = 34963(0x8893, float:4.8994E-41)
                android.opengl.GLES20.glBindBuffer(r3, r0)     // Catch:{ all -> 0x0436 }
                int r0 = r2.capacity()     // Catch:{ all -> 0x0436 }
                int r6 = l0.z1.f3381s0     // Catch:{ all -> 0x0436 }
                int r0 = r0 * r6
                android.opengl.GLES20.glBufferData(r3, r0, r2, r5)     // Catch:{ all -> 0x0436 }
                r0 = 0
                android.opengl.GLES20.glBindBuffer(r4, r0)     // Catch:{ all -> 0x0436 }
                android.opengl.GLES20.glBindBuffer(r3, r0)     // Catch:{ all -> 0x0436 }
                goto L_0x0452
            L_0x0436:
                r0 = move-exception
            L_0x0437:
                java.lang.String r2 = l0.z1.M0
                android.util.Log.w(r2, r0)
                l0.z1 r2 = r1.f3441d
                l0.i r2 = r2.f3391b
                l0.i$a r3 = l0.i.a.BUFFER_CREATION_ERROR
                java.lang.String r0 = r0.getLocalizedMessage()
                java.lang.String r4 = "t.localizedMessage"
                w0.k.c(r0, r4)
                r2.a(r3, r0)
            L_0x0452:
                o0.m r0 = o0.m.f3885a
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: l0.z1.c.<init>(l0.z1):void");
        }

        public final void a() {
            this.f3441d.f3415n = -1.0f;
            GLES20.glUniform1f(z1.O0, this.f3441d.f3415n);
            int[] iArr = this.f3440c;
            if (iArr[0] > 0 && this.f3438a[0] > 0) {
                GLES20.glBindBuffer(34962, iArr[0]);
                GLES20.glVertexAttribPointer(this.f3441d.M, z1.G0, 5126, false, z1.L0, 0);
                GLES20.glEnableVertexAttribArray(this.f3441d.M);
                GLES20.glVertexAttribPointer(this.f3441d.K, z1.E0, 5126, false, z1.L0, z1.f3380r0 * z1.G0);
                GLES20.glEnableVertexAttribArray(this.f3441d.K);
                GLES20.glVertexAttribPointer(this.f3441d.f3411l, z1.f3384v0, 5126, false, z1.L0, z1.f3380r0 * (z1.G0 + z1.E0));
                GLES20.glEnableVertexAttribArray(this.f3441d.f3411l);
                GLES20.glVertexAttribPointer(this.f3441d.L, z1.H0, 5126, false, z1.L0, z1.f3380r0 * (z1.G0 + z1.E0 + z1.f3384v0));
                GLES20.glEnableVertexAttribArray(this.f3441d.L);
                this.f3441d.X();
                GLES20.glBindBuffer(34963, this.f3438a[0]);
                GLES20.glDrawElements(this.f3441d.f3392b0 > 0.5f ? 4 : 5, this.f3439b, 5123, 0);
                GLES20.glBindBuffer(34962, 0);
                GLES20.glBindBuffer(34963, 0);
                GLES20.glBindTexture(3553, 0);
            }
        }
    }

    public final class d {

        /* renamed from: a  reason: collision with root package name */
        private final int f3442a = 3;

        /* renamed from: b  reason: collision with root package name */
        private float[] f3443b = {1.0f, 0.0f, 0.0f, -1.0f};

        /* renamed from: c  reason: collision with root package name */
        private final String f3444c = "precision mediump float;uniform vec4 vColor;void main() {  gl_FragColor = vColor;}";

        /* renamed from: d  reason: collision with root package name */
        private final int[] f3445d = new int[1];

        /* renamed from: e  reason: collision with root package name */
        private float[] f3446e;

        /* renamed from: f  reason: collision with root package name */
        private short[] f3447f;

        /* renamed from: g  reason: collision with root package name */
        private final int[] f3448g;

        /* renamed from: h  reason: collision with root package name */
        private final FloatBuffer f3449h;

        /* renamed from: i  reason: collision with root package name */
        private final int f3450i;

        /* renamed from: j  reason: collision with root package name */
        private final String f3451j;

        /* renamed from: k  reason: collision with root package name */
        private final int f3452k;

        public d() {
            float[] fArr = new float[36];
            this.f3446e = fArr;
            this.f3447f = new short[6];
            this.f3448g = new int[1];
            this.f3450i = fArr.length / 3;
            this.f3451j = "attribute vec4 vPosition;void main() {  gl_Position = vPosition;}";
            this.f3452k = 12;
            ByteBuffer allocateDirect = ByteBuffer.allocateDirect(fArr.length * 4);
            allocateDirect.order(ByteOrder.nativeOrder());
            FloatBuffer asFloatBuffer = allocateDirect.asFloatBuffer();
            k.c(asFloatBuffer, "bb.asFloatBuffer()");
            this.f3449h = asFloatBuffer;
            float[] fArr2 = this.f3446e;
            fArr2[0] = 0.0f;
            fArr2[1] = 0.0f;
            fArr2[2] = 0.0f;
            fArr2[3] = 0.0f;
            fArr2[4] = 0.0f;
            fArr2[5] = 5.0f;
            fArr2[6] = 0.0f;
            fArr2[7] = 0.0f;
            fArr2[8] = 0.0f;
            fArr2[9] = 0.0f;
            fArr2[10] = 0.0f;
            fArr2[11] = 0.0f;
            fArr2[12] = 0.0f;
            fArr2[13] = 0.0f;
            fArr2[14] = 0.0f;
            fArr2[15] = 0.0f;
            fArr2[16] = 0.0f;
            fArr2[17] = 0.0f;
            fArr2[18] = 0.4f;
            fArr2[19] = 0.0f;
            fArr2[20] = 5.4f;
            fArr2[21] = -0.4f;
            fArr2[22] = 0.0f;
            fArr2[23] = 5.4f;
            fArr2[24] = -0.4f;
            fArr2[25] = 0.0f;
            fArr2[26] = 5.4f;
            fArr2[27] = 0.4f;
            fArr2[28] = 0.0f;
            fArr2[29] = 6.1f;
            fArr2[30] = 0.4f;
            fArr2[31] = 0.0f;
            fArr2[32] = 6.1f;
            fArr2[33] = -0.4f;
            fArr2[34] = 0.0f;
            fArr2[35] = 6.1f;
        }

        public final void a(float f2) {
            float f3 = f2;
            z1.this.f3415n = f3;
            float unused = z1.this.D;
            if (f3 > 1.0f) {
                float[] fArr = this.f3446e;
                fArr[18] = 0.4f;
                fArr[19] = 0.0f;
                fArr[20] = z1.this.T() + 0.4f;
                float[] fArr2 = this.f3446e;
                fArr2[21] = -0.4f;
                fArr2[22] = 0.0f;
                fArr2[23] = z1.this.T() + 0.4f;
                float[] fArr3 = this.f3446e;
                fArr3[24] = -0.4f;
                fArr3[25] = 0.0f;
                fArr3[26] = z1.this.T() + 0.4f;
                float[] fArr4 = this.f3446e;
                fArr4[27] = 0.4f;
                fArr4[28] = 0.0f;
                fArr4[29] = z1.this.T() + 1.1f;
                float[] fArr5 = this.f3446e;
                fArr5[30] = 0.4f;
                fArr5[31] = 0.0f;
                fArr5[32] = z1.this.T() + 1.1f;
                float[] fArr6 = this.f3446e;
                fArr6[33] = -0.4f;
                fArr6[34] = 0.0f;
                fArr6[35] = z1.this.T() + 1.1f;
            } else if (f3 > 0.0f) {
                float o2 = z1.this.f3418o0;
                float[] fArr7 = this.f3446e;
                fArr7[18] = 0.0f;
                fArr7[19] = o2 + 0.4f;
                fArr7[20] = 0.0f;
                fArr7[21] = 0.0f;
                float f4 = o2 + 0.75f;
                fArr7[22] = f4;
                fArr7[23] = 0.0f;
                fArr7[24] = 0.0f;
                fArr7[25] = f4;
                fArr7[26] = 0.0f;
                fArr7[27] = 0.4f;
                float f5 = o2 + 1.1f;
                fArr7[28] = f5;
                fArr7[29] = 0.0f;
                fArr7[30] = 0.0f;
                fArr7[31] = f4;
                fArr7[32] = 0.0f;
                fArr7[33] = -0.4f;
                fArr7[34] = f5;
                fArr7[35] = 0.0f;
            } else if (f3 > -1.0f) {
                float r2 = z1.this.f3416n0;
                float[] fArr8 = this.f3446e;
                float f6 = r2 + 0.4f;
                fArr8[18] = f6;
                fArr8[19] = 0.4f;
                fArr8[20] = 0.0f;
                float f7 = r2 + 1.1f;
                fArr8[21] = f7;
                fArr8[22] = -0.4f;
                fArr8[23] = 0.0f;
                float f8 = r2 + 0.75f;
                fArr8[24] = f8;
                fArr8[25] = 0.0f;
                fArr8[26] = 0.0f;
                fArr8[27] = f7;
                fArr8[28] = 0.4f;
                fArr8[29] = 0.0f;
                fArr8[30] = f8;
                fArr8[31] = 0.0f;
                fArr8[32] = 0.0f;
                fArr8[33] = f6;
                fArr8[34] = -0.4f;
                fArr8[35] = 0.0f;
            }
            this.f3449h.put(this.f3446e);
            this.f3449h.position(0);
            GLES20.glVertexAttribPointer(z1.this.M, this.f3442a, 5126, false, this.f3452k, this.f3449h);
            GLES20.glEnableVertexAttribArray(z1.this.M);
            GLES20.glDrawArrays(1, 0, this.f3450i);
            GLES20.glLineWidth(2.0f);
        }

        public final void b(float f2, float f3, float f4, float f5, float f6, float f7, float f8, float f9, float f10, float f11, float f12, float f13, float f14, float f15, float f16, float f17, float f18, float f19) {
            float[] fArr = this.f3446e;
            fArr[0] = f2;
            fArr[1] = f3;
            fArr[2] = f4;
            fArr[3] = f5;
            fArr[4] = f6;
            fArr[5] = f7;
            fArr[6] = f8;
            fArr[7] = f9;
            fArr[8] = f10;
            fArr[9] = f11;
            fArr[10] = f12;
            fArr[11] = f13;
            fArr[12] = f14;
            fArr[13] = f15;
            fArr[14] = f16;
            fArr[15] = f17;
            fArr[16] = f18;
            fArr[17] = f19;
        }
    }

    public final class e {

        /* renamed from: a  reason: collision with root package name */
        private final int f3454a = 3;

        /* renamed from: b  reason: collision with root package name */
        private float[] f3455b = {1.0f, 0.0f, 0.0f, -1.0f};

        /* renamed from: c  reason: collision with root package name */
        private final int[] f3456c = new int[1];

        /* renamed from: d  reason: collision with root package name */
        private float[] f3457d;

        /* renamed from: e  reason: collision with root package name */
        private short[] f3458e;

        /* renamed from: f  reason: collision with root package name */
        private final int[] f3459f;

        /* renamed from: g  reason: collision with root package name */
        private float f3460g;

        /* renamed from: h  reason: collision with root package name */
        private final FloatBuffer f3461h;

        /* renamed from: i  reason: collision with root package name */
        private int f3462i;

        /* renamed from: j  reason: collision with root package name */
        private final int f3463j;

        public e() {
            float[] fArr = new float[36];
            this.f3457d = fArr;
            this.f3458e = new short[36];
            this.f3459f = new int[1];
            this.f3460g = 2.0f;
            this.f3462i = fArr.length / 3;
            this.f3463j = 12;
            ByteBuffer allocate = ByteBuffer.allocate(600);
            allocate.order(ByteOrder.nativeOrder());
            FloatBuffer asFloatBuffer = allocate.asFloatBuffer();
            k.c(asFloatBuffer, "bb.asFloatBuffer()");
            this.f3461h = asFloatBuffer;
        }

        public final void a() {
            GLES20.glGenBuffers(1, this.f3459f, 0);
            GLES20.glGenBuffers(1, this.f3456c, 0);
            GLES20.glUniform1f(z1.O0, z1.this.f3415n);
            GLES20.glUniform1f(z1.this.S(), 2.0f);
            FloatBuffer asFloatBuffer = ByteBuffer.allocateDirect(this.f3457d.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
            ShortBuffer asShortBuffer = ByteBuffer.allocateDirect(this.f3458e.length * 2).order(ByteOrder.nativeOrder()).asShortBuffer();
            asShortBuffer.put(this.f3458e);
            asShortBuffer.position(0);
            asFloatBuffer.put(this.f3457d);
            asFloatBuffer.position(0);
            GLES20.glVertexAttribPointer(z1.this.M, this.f3454a, 5126, false, this.f3463j, asFloatBuffer);
            GLES20.glEnableVertexAttribArray(z1.this.M);
            GLES20.glDrawArrays(3, 0, this.f3457d.length / 3);
            GLES20.glLineWidth(this.f3460g);
            GLES20.glUniform1f(z1.this.S(), z1.this.T);
        }

        public final void b(float[] fArr) {
            k.d(fArr, "points");
            this.f3457d = fArr;
            this.f3458e = new short[(fArr.length / 3)];
            int length = fArr.length / 3;
            for (int i2 = 0; i2 < length; i2++) {
                this.f3458e[i2] = (short) i2;
            }
        }

        public final void c(float f2) {
            this.f3460g = f2;
        }
    }

    static {
        int i2 = 3 + 3 + 4 + 1;
        K0 = i2;
        L0 = i2 * 4;
    }

    public z1(MainActivity mainActivity, i iVar, Context context) {
        k.d(mainActivity, "mainActivity");
        k.d(iVar, "errorHandler");
        k.d(context, "context");
        this.f3389a = mainActivity;
        this.f3391b = iVar;
        this.f3393c = context;
    }

    /* access modifiers changed from: private */
    public final float N() {
        ArrayList<ArrayList<Double>> l2 = h.f4378j.a().l();
        Double valueOf = Double.valueOf(0.0d);
        k.b(l2);
        Iterator<ArrayList<Double>> it = l2.iterator();
        while (it.hasNext()) {
            Iterator it2 = it.next().iterator();
            while (it2.hasNext()) {
                Double d2 = (Double) it2.next();
                if (valueOf != null) {
                    double doubleValue = valueOf.doubleValue();
                    k.b(d2);
                    valueOf = Double.valueOf(doubleValue + Math.abs(d2.doubleValue()));
                } else {
                    valueOf = null;
                }
            }
        }
        k.b(valueOf);
        return (float) valueOf.doubleValue();
    }

    private final float O() {
        if (this.f3408j0 == 0.0f) {
            return 1.0f;
        }
        return (((float) Math.min(this.f3407j, this.f3401g)) * 0.85f) / this.f3408j0;
    }

    /* access modifiers changed from: private */
    public final float P(float f2, float f3, float f4, float f5) {
        return f5 / (Math.abs(f2) - (f5 / (f3 * f4)));
    }

    /* access modifiers changed from: private */
    /* JADX WARNING: Code restructure failed: missing block: B:11:0x002a, code lost:
        r0 = r0 * r2;
        r2 = (float) 10000;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0036, code lost:
        if (r8 < -1.0f) goto L_0x0026;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0024, code lost:
        if (r8 > 1.0f) goto L_0x0026;
     */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x003e  */
    /* JADX WARNING: Removed duplicated region for block: B:22:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final float Q(float r8) {
        /*
            r7 = this;
            float r0 = r7.f3418o0
            r1 = 10
            float r1 = (float) r1
            float r0 = r0 * r1
            float r2 = r7.f3416n0
            float r2 = r2 * r1
            r1 = 0
            int r3 = (r8 > r1 ? 1 : (r8 == r1 ? 0 : -1))
            if (r3 != 0) goto L_0x0012
            r3 = 1
            goto L_0x0013
        L_0x0012:
            r3 = 0
        L_0x0013:
            if (r3 == 0) goto L_0x0016
            return r1
        L_0x0016:
            r3 = 100
            r4 = 10000(0x2710, float:1.4013E-41)
            r5 = -1082130432(0xffffffffbf800000, float:-1.0)
            int r6 = (r8 > r1 ? 1 : (r8 == r1 ? 0 : -1))
            if (r6 <= 0) goto L_0x0030
            r6 = 1065353216(0x3f800000, float:1.0)
            int r6 = (r8 > r6 ? 1 : (r8 == r6 ? 0 : -1))
            if (r6 <= 0) goto L_0x002a
        L_0x0026:
            float r0 = r0 * r2
            float r2 = (float) r3
            goto L_0x002d
        L_0x002a:
            float r0 = r0 * r2
            float r2 = (float) r4
        L_0x002d:
            float r0 = r0 / r2
            float r0 = r0 / r8
            goto L_0x003a
        L_0x0030:
            int r6 = (r8 > r1 ? 1 : (r8 == r1 ? 0 : -1))
            if (r6 >= 0) goto L_0x0039
            int r6 = (r8 > r5 ? 1 : (r8 == r5 ? 0 : -1))
            if (r6 >= 0) goto L_0x002a
            goto L_0x0026
        L_0x0039:
            r0 = 0
        L_0x003a:
            int r8 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r8 >= 0) goto L_0x0040
            float r0 = r0 * r5
        L_0x0040:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: l0.z1.Q(float):float");
    }

    private final String R(float f2) {
        return String.valueOf((int) (f2 * ((float) 10)));
    }

    public final int S() {
        return this.Q;
    }

    public final float T() {
        return this.f3396d0;
    }

    public final float U() {
        return this.f3398e0;
    }

    public final float[][] V() {
        return this.f3400f0;
    }

    public final float[][] W() {
        return this.f3402g0;
    }

    public final void X() {
        GLES20.glActiveTexture(33985);
        GLES20.glBindTexture(3553, this.f3413m);
        GLES20.glUniform1i(this.J, 1);
    }

    public final void Y() {
        this.I = GLES20.glGetUniformLocation(this.N, f3387y0);
        this.G = GLES20.glGetUniformLocation(this.N, f3388z0);
        this.J = GLES20.glGetUniformLocation(this.N, A0);
        this.f3430z = GLES20.glGetUniformLocation(this.N, f3386x0);
        this.Q = GLES20.glGetUniformLocation(this.N, I0);
        this.f3390a0 = GLES20.glGetUniformLocation(this.N, N0);
        O0 = GLES20.glGetUniformLocation(this.N, f3385w0);
        this.M = GLES20.glGetAttribLocation(this.N, F0);
        this.K = GLES20.glGetAttribLocation(this.N, B0);
        this.f3411l = GLES20.glGetAttribLocation(this.N, f3382t0);
        this.L = GLES20.glGetAttribLocation(this.N, f3383u0);
    }

    public final void Z() {
        o1 o1Var = o1.f3272a;
        Bitmap c2 = y1.f3362a.c();
        k.b(c2);
        Bitmap copy = c2.copy(Bitmap.Config.ARGB_8888, false);
        k.c(copy, "imageUtilities.currentIm…(Config.ARGB_8888, false)");
        this.f3413m = o1Var.a(copy, 33985);
    }

    public final void a0(int i2, int i3) {
        int i4 = i2;
        int i5 = i3;
        GLES20.glViewport(0, 0, i4, i5);
        V0 = 1.0f;
        Math.min(i2, i3);
        Matrix.orthoM(this.O, 0, (float) ((-i4) / 2), (float) (i4 / 2), (float) ((-i5) / 2), (float) (i5 / 2), 1.0f, 10000.0f);
        Matrix.setLookAtM(this.f3410k0, 0, 0.0f, 0.0f, 2000.0f, 0.0f, 0.0f, -50.0f, 0.0f, 1.0f, 0.0f);
    }

    public final void b0() {
        this.X = 0.0f;
        this.Y = 0.0f;
        this.V = 0.0f;
        this.W = 0.0f;
        U0 = 0.0f;
        T0 = 0.0f;
        Q0 = 1.0f;
        this.f3395d = 0.0f;
        this.f3397e = 0.0f;
        Matrix.setIdentityM(this.f3409k, 0);
        Q0 = O();
        o oVar = this.f3414m0;
        if (oVar != null) {
            k.b(oVar);
            oVar.c();
        }
    }

    public final void c0(Bitmap bitmap, boolean z2) {
        IOException iOException;
        String str;
        String str2;
        k.d(bitmap, "bitmap");
        if (z2) {
            bitmap = Bitmap.createScaledBitmap(bitmap, 50, 50, true);
            k.c(bitmap, "createScaledBitmap(bitmap, 50, 50, true)");
        }
        if (this.f3425u == null) {
            this.f3425u = new File(Environment.getExternalStorageDirectory().toString() + "/Pictures/Screenshots/Surface3D_" + new SimpleDateFormat("yyyyMMddHHmmss'.png'").format(new Date()));
        }
        File file = new File(Environment.getExternalStorageDirectory().toString() + "/Pictures/Screenshots/");
        File file2 = this.f3425u;
        k.b(file2);
        if (file2.exists()) {
            File file3 = this.f3425u;
            k.b(file3);
            file3.delete();
        }
        if (!file.exists()) {
            file.mkdir();
        }
        try {
            File file4 = this.f3425u;
            k.b(file4);
            FileOutputStream fileOutputStream = new FileOutputStream(file4);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
            fileOutputStream.flush();
            fileOutputStream.close();
            MainActivity mainActivity = this.f3389a;
            File file5 = this.f3425u;
            k.b(file5);
            MediaScannerConnection.scanFile(mainActivity, new String[]{file5.getPath()}, new String[]{"image/png"}, (MediaScannerConnection.OnScanCompletedListener) null);
        } catch (FileNotFoundException e2) {
            str2 = e2.getMessage();
            str = "FileNotFound";
            iOException = e2;
        } catch (IOException e3) {
            str2 = e3.getMessage();
            str = "IO_ERROR";
            iOException = e3;
        }
        this.f3425u = null;
        Log.e(str, str2, iOException);
        this.f3425u = null;
    }

    public final void d0(int i2) {
        this.f3417o = i2;
    }

    public final void e0(boolean z2) {
        this.f3399f = z2;
        o oVar = this.f3414m0;
        if (oVar != null) {
            k.b(oVar);
            oVar.c();
        }
    }

    public final void f0(boolean z2) {
        this.f3424t = z2;
    }

    public final void g0(int i2) {
        this.f3421q = i2;
    }

    public final void h0(boolean z2) {
        this.f3412l0 = z2;
    }

    public final void i0(float[][] fArr) {
        k.d(fArr, "m");
        this.f3394c0 = fArr;
    }

    public final void j0(float f2, float f3) {
        this.f3398e0 = f2;
        this.f3396d0 = f3;
    }

    public final void k0(int i2) {
        this.E = i2;
    }

    public final void l0(float f2) {
        this.f3408j0 = f2;
    }

    public final void m0(int i2, int i3) {
        this.f3404h0 = i2;
        this.f3406i0 = i3;
    }

    public final void n0(float f2, float f3) {
        this.f3416n0 = f2;
        this.f3418o0 = f3;
        float f4 = Q0;
        this.X = (f2 * f4) / -2.0f;
        this.Y = (f3 * f4) / -2.0f;
    }

    public final void o0(int i2, int i3) {
        this.f3403h = i2;
        this.f3405i = i3;
        float[][] fArr = new float[i2][];
        for (int i4 = 0; i4 < i2; i4++) {
            fArr[i4] = new float[this.f3405i];
        }
        this.f3394c0 = fArr;
        int i5 = this.f3403h;
        float[][] fArr2 = new float[i5][];
        for (int i6 = 0; i6 < i5; i6++) {
            fArr2[i6] = new float[this.f3405i];
        }
        this.f3400f0 = fArr2;
        int i7 = this.f3403h;
        float[][] fArr3 = new float[i7][];
        for (int i8 = 0; i8 < i7; i8++) {
            fArr3[i8] = new float[this.f3405i];
        }
        this.f3402g0 = fArr3;
    }

    public void onDrawFrame(GL10 gl10) {
        float f2;
        k.d(gl10, "glUnused");
        GLES20.glClear(16640);
        GLES20.glUseProgram(this.N);
        Matrix.setIdentityM(this.f3426v, 0);
        Matrix.translateM(this.f3426v, 0, 0.0f, 7.5f, -12.0f);
        Matrix.multiplyMV(this.f3429y, 0, this.f3426v, 0, this.f3428x, 0);
        Matrix.multiplyMV(this.f3427w, 0, this.f3410k0, 0, this.f3429y, 0);
        Matrix.setIdentityM(this.F, 0);
        Matrix.translateM(this.F, 0, this.X + this.V + 0.0f, this.Y + this.W + 0.0f, 100.0f);
        float[] fArr = this.F;
        float f3 = Q0;
        Matrix.scaleM(fArr, 0, f3, f3, f3);
        if (W0) {
            this.f3395d = U0;
            f2 = T0;
        } else {
            this.f3395d += U0;
            f2 = this.f3397e + T0;
        }
        this.f3397e = f2;
        Matrix.setIdentityM(this.f3419p, 0);
        Matrix.rotateM(this.f3419p, 0, this.f3395d, 0.0f, 1.0f, 0.0f);
        Matrix.rotateM(this.f3419p, 0, this.f3397e, 1.0f, 0.0f, 0.0f);
        if (P0) {
            this.f3395d = 0.0f;
            this.f3397e = 0.0f;
            P0 = false;
        }
        Matrix.multiplyMM(this.U, 0, this.f3419p, 0, this.f3409k, 0);
        System.arraycopy(this.U, 0, this.f3409k, 0, 16);
        Matrix.multiplyMM(this.U, 0, this.F, 0, this.f3409k, 0);
        System.arraycopy(this.U, 0, this.F, 0, 16);
        Matrix.multiplyMM(this.H, 0, this.f3410k0, 0, this.F, 0);
        float f4 = V0;
        if (!(f4 == 1.0f)) {
            float f5 = Q0 * f4;
            Q0 = f5;
            if (((double) f5) < 0.001d) {
                Q0 = 0.001f;
            }
        }
        this.X += this.V;
        this.Y += this.W;
        this.V = 0.0f;
        this.W = 0.0f;
        V0 = 1.0f;
        R0 = 1.0f;
        GLES20.glUniformMatrix4fv(this.G, 1, false, this.H, 0);
        Matrix.multiplyMM(this.U, 0, this.O, 0, this.H, 0);
        System.arraycopy(this.U, 0, this.H, 0, 16);
        GLES20.glUniformMatrix4fv(this.I, 1, false, this.H, 0);
        int i2 = this.f3430z;
        float[] fArr2 = this.f3427w;
        GLES20.glUniform3f(i2, fArr2[0], fArr2[1], fArr2[2]);
        GLES20.glUniform1f(this.Q, this.T);
        GLES20.glUniform1f(this.f3390a0, this.Z);
        c cVar = this.f3422r;
        k.b(cVar);
        cVar.a();
        if (this.f3421q > 0) {
            if (this.D < 1.6f) {
                this.D = 1.6f;
            }
            float f6 = this.f3418o0;
            GLES20.glUniform1f(this.Q, 2.0f);
            GLES20.glUniform1f(O0, -1.0f);
            d dVar = this.A;
            k.b(dVar);
            float f7 = f6 - 0.6f;
            dVar.b(0.0f, 0.0f, 0.0f, 0.0f, f6 - 0.01f, 0.0f, 0.0f, f6, 0.0f, -0.15f, f7, 0.0f, 0.0f, f6, 0.0f, 0.15f, f7, 0.0f);
            d dVar2 = this.A;
            k.b(dVar2);
            dVar2.a(1.0f);
            GLES20.glUniform1f(O0, 1.0f);
            float f8 = this.f3416n0;
            d dVar3 = this.A;
            k.b(dVar3);
            float f9 = f8 - 0.6f;
            dVar3.b(0.0f, 0.0f, 0.0f, f8 - 0.01f, 0.0f, 0.0f, f8, 0.0f, 0.0f, f9, -0.15f, 0.0f, f8, 0.0f, 0.0f, f9, 0.15f, 0.0f);
            d dVar4 = this.A;
            k.b(dVar4);
            dVar4.a(0.0f);
            GLES20.glUniform1f(O0, 0.0f);
            float f10 = this.f3398e0;
            float f11 = f10 > 0.0f ? 0.0f : f10;
            d dVar5 = this.A;
            d dVar6 = dVar5;
            k.b(dVar5);
            float f12 = this.f3396d0;
            dVar6.b(0.0f, 0.0f, f11, 0.0f, 0.0f, f12 - 0.01f, 0.0f, 0.0f, f12, -0.15f, 0.0f, f12 - 0.6f, 0.0f, 0.0f, f12, 0.15f, 0.0f, f12 - 0.6f);
            d dVar7 = this.A;
            k.b(dVar7);
            dVar7.a(2.0f);
            GLES20.glUniform1f(this.Q, this.T);
        }
        if (this.f3424t && this.f3408j0 > 0.0f) {
            b bVar = this.f3423s;
            k.b(bVar);
            bVar.a(this.H, this.f3414m0, true);
            if (this.f3421q > 0) {
                o oVar = this.f3414m0;
                k.b(oVar);
                oVar.b(0.0f, 1.0f, 0.0f, 1.0f, this.H);
                o oVar2 = this.f3414m0;
                k.b(oVar2);
                oVar2.p(0.08f);
                o oVar3 = this.f3414m0;
                k.b(oVar3);
                oVar3.d("0", 0.0f, -2.0f, 0.0f, 0.0f);
                String R2 = R(this.f3416n0);
                o oVar4 = this.f3414m0;
                k.b(oVar4);
                oVar4.d(R2, this.f3416n0, -2.0f, 0.0f, 0.0f);
                String R3 = R(this.f3418o0);
                o oVar5 = this.f3414m0;
                k.b(oVar5);
                oVar5.f(R3, -1.0f, this.f3418o0, 0.0f, 90.0f);
                o oVar6 = this.f3414m0;
                k.b(oVar6);
                oVar6.j();
            }
        }
        if (this.S) {
            this.S = false;
            c0(y0(gl10), this.f3420p0);
        }
    }

    public void onSurfaceChanged(GL10 gl10, int i2, int i3) {
        k.d(gl10, "glUnused");
        this.f3407j = i2;
        this.f3401g = i3;
        a0(i2, i3);
    }

    public void onSurfaceCreated(GL10 gl10, EGLConfig eGLConfig) {
        k.d(gl10, "glUnused");
        k.d(eGLConfig, "config");
        GLES20.glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
        this.f3422r = new c(this);
        if (this.f3421q > 0) {
            this.A = new d();
        }
        MainActivity mainActivity = this.f3389a;
        AssetManager assets = this.f3393c.getAssets();
        k.c(assets, "context.assets");
        o oVar = new o(mainActivity, assets);
        this.f3414m0 = oVar;
        k.b(oVar);
        oVar.p(0.08f);
        o oVar2 = this.f3414m0;
        k.b(oVar2);
        oVar2.o("Roboto-Regular.ttf", 14, 2, 2);
        GLES20.glEnable(3042);
        GLES20.glBlendFunc(1, 771);
        GLES20.glEnable(2929);
        l1 l1Var = l1.f3220a;
        String a2 = l1Var.a(this.f3389a, R.raw.per_pixel_vertex_shader_no_tex);
        String a3 = l1Var.a(this.f3389a, R.raw.per_pixel_fragment_shader_no_tex);
        m1 m1Var = m1.f3230a;
        k.b(a2);
        int a4 = m1Var.a(35633, a2);
        k.b(a3);
        this.N = m1Var.b(a4, m1Var.a(35632, a3), new String[]{F0, B0, f3382t0, f3383u0});
        Y();
        o oVar3 = this.f3414m0;
        k.b(oVar3);
        oVar3.n(this.f3389a);
        this.f3423s = new b();
        if (this.R) {
            Matrix.setIdentityM(this.f3409k, 0);
        }
    }

    public final void p0(boolean z2) {
        this.R = z2;
    }

    public final void q0(float f2, float f3) {
        U0 = 0.0f;
        T0 = 0.0f;
        Q0 = 1.0f;
        this.f3395d = f2;
        this.f3397e = f3;
        Matrix.setIdentityM(this.f3409k, 0);
        Q0 = O();
        W0 = false;
        P0 = true;
    }

    public final void r0(boolean z2, File file, boolean z3) {
        k.d(file, "path");
        this.S = z2;
        this.f3425u = file;
        this.f3420p0 = z3;
    }

    public final void s0(float f2) {
        this.T = f2;
    }

    public final void t0(float f2, float f3) {
        this.V = f2;
        this.W = f3;
    }

    public final void u0(float f2) {
        this.Z = f2;
    }

    public final void v0(float f2) {
        this.f3392b0 = f2;
    }

    public final void w0(float[][] fArr) {
        this.f3400f0 = fArr;
    }

    public final void x0(float[][] fArr) {
        this.f3402g0 = fArr;
    }

    public final Bitmap y0(GL10 gl10) {
        k.d(gl10, "gl");
        int i2 = this.f3407j;
        int i3 = this.f3401g;
        int i4 = i2 * i3;
        IntBuffer allocate = IntBuffer.allocate(i4);
        IntBuffer allocate2 = IntBuffer.allocate(i4);
        gl10.glReadPixels(0, 0, i2, i3, 6408, 5121, allocate);
        for (int i5 = 0; i5 < i3; i5++) {
            for (int i6 = 0; i6 < i2; i6++) {
                allocate2.put((((i3 - i5) - 1) * i2) + i6, allocate.get((i5 * i2) + i6));
            }
        }
        Bitmap createBitmap = Bitmap.createBitmap(i2, i3, Bitmap.Config.ARGB_8888);
        createBitmap.copyPixelsFromBuffer(allocate2);
        k.c(createBitmap, "mBitmap");
        S0 = createBitmap;
        return createBitmap;
    }
}
