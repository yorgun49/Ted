package l0;

import android.view.View;
import com.te.tem3d.MainActivity;

public final /* synthetic */ class i0 implements View.OnClickListener {

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ MainActivity f3197b;

    public /* synthetic */ i0(MainActivity mainActivity) {
        this.f3197b = mainActivity;
    }

    public final void onClick(View view) {
        MainActivity.Z0(this.f3197b, view);
    }
}
