package l0;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RectShape;
import n0.a;
import w0.k;
import z.h;
import z.j;

public final class y1 {

    /* renamed from: a  reason: collision with root package name */
    public static final y1 f3362a = new y1();

    /* renamed from: b  reason: collision with root package name */
    private static Bitmap f3363b;

    /* renamed from: c  reason: collision with root package name */
    private static int[] f3364c;

    /* renamed from: d  reason: collision with root package name */
    private static int f3365d;

    /* renamed from: e  reason: collision with root package name */
    private static int f3366e;

    /* renamed from: f  reason: collision with root package name */
    private static int f3367f;

    /* renamed from: g  reason: collision with root package name */
    private static int f3368g;

    /* renamed from: h  reason: collision with root package name */
    private static int f3369h;

    /* renamed from: i  reason: collision with root package name */
    private static int f3370i;

    /* renamed from: j  reason: collision with root package name */
    private static boolean f3371j;

    /* renamed from: k  reason: collision with root package name */
    private static boolean f3372k;

    /* renamed from: l  reason: collision with root package name */
    private static int f3373l;

    /* renamed from: m  reason: collision with root package name */
    private static int f3374m;

    /* renamed from: n  reason: collision with root package name */
    private static final int f3375n = 200;

    /* renamed from: o  reason: collision with root package name */
    private static int f3376o;

    private y1() {
    }

    private final r1 g(int i2) {
        return i2 == 1 ? new b().a() : i2 == 2 ? new c().a() : i2 == 3 ? new d().a() : i2 == 4 ? new e().a() : i2 == 5 ? new f().a() : i2 == 6 ? new g().a() : new a().a();
    }

    public final void a() {
        int i2 = f3375n;
        f3364c = new int[i2];
        for (int i3 = 0; i3 < i2; i3++) {
            int[] iArr = f3364c;
            k.b(iArr);
            Bitmap bitmap = f3363b;
            k.b(bitmap);
            iArr[i3] = bitmap.getPixel(i3, 0);
        }
    }

    public final void b(int i2) {
        int i3 = f3375n;
        f3363b = Bitmap.createBitmap(i3, i3, Bitmap.Config.ARGB_8888);
        Bitmap bitmap = f3363b;
        k.b(bitmap);
        Canvas canvas = new Canvas(bitmap);
        f3376o = i2;
        ShapeDrawable shapeDrawable = new ShapeDrawable();
        shapeDrawable.setShaderFactory(g(i2).a().a());
        shapeDrawable.setShape(new RectShape());
        shapeDrawable.setBounds(0, 0, i3, i3);
        shapeDrawable.setFilterBitmap(true);
        shapeDrawable.setDither(false);
        shapeDrawable.draw(canvas);
        a();
    }

    public final Bitmap c() {
        return f3363b;
    }

    public final int d(double d2) {
        if (d2 > 1.0d) {
            d2 = 1.0d;
        }
        if (d2 < 0.0d) {
            d2 = 0.0d;
        }
        int i2 = f3375n;
        double d3 = (double) i2;
        Double.isNaN(d3);
        int floor = (int) Math.floor(d2 * d3);
        if (floor >= i2) {
            floor = i2 - 1;
        }
        int[] iArr = f3364c;
        k.b(iArr);
        return iArr[floor];
    }

    public final int e(double d2, int i2, int i3, float f2) {
        if (f3372k) {
            if (i2 >= f3374m) {
                return 0;
            }
            if (i2 >= f3373l) {
                if (f3371j) {
                    if (i3 < f3369h) {
                        return 0;
                    }
                } else if (i3 > f3369h) {
                    return 0;
                }
            }
        }
        return d(d2);
    }

    public final a f(double d2) {
        int d3 = d(d2);
        return new a(i.a.a(((float) Color.red(d3)) / 255.0f, 0.0f, 1.0f), i.a.a(((float) Color.green(d3)) / 255.0f, 0.0f, 1.0f), i.a.a(((float) Color.blue(d3)) / 255.0f, 0.0f, 1.0f));
    }

    public final void h() {
        h.a aVar = h.f4378j;
        f3365d = aVar.a().h();
        f3366e = aVar.a().g();
        j.a aVar2 = j.f4399n;
        f3367f = aVar2.a().f();
        f3368g = aVar2.a().g();
        float b2 = ((float) aVar.b()) / ((float) f3368g);
        float c2 = ((float) aVar.c()) / ((float) f3367f);
        int i2 = f3366e;
        f3373l = (int) (((float) i2) * b2);
        f3374m = (int) (((float) (i2 + 1)) * b2);
        boolean z2 = i2 % 2 == 1;
        f3371j = z2;
        f3369h = (int) (((float) (z2 ? f3365d : f3365d + 1)) * c2);
        f3370i = (int) ((((float) i2) / ((float) f3368g)) * ((float) aVar.b()));
        f3372k = aVar.a().k();
    }
}
