package l0;

import android.graphics.drawable.StateListDrawable;
import w0.k;

public final class r1 extends StateListDrawable {

    /* renamed from: b  reason: collision with root package name */
    private q1 f3289b;

    public r1(int[] iArr, int[] iArr2, int[] iArr3) {
        k.d(iArr, "normalColors");
        k.d(iArr2, "focusedColors");
        this.f3289b = new q1(iArr);
        q1 q1Var = new q1(iArr2);
        q1 q1Var2 = iArr3 == null ? this.f3289b : new q1(iArr3);
        addState(new int[]{16842908}, q1Var);
        addState(new int[]{16842919}, q1Var2);
        addState(new int[]{-16842919, -16842908}, this.f3289b);
    }

    public final q1 a() {
        return this.f3289b;
    }
}
