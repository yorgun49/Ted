package l0;

import com.te.tem3d.surfaceGL;
import l0.i;

public final /* synthetic */ class a2 implements Runnable {

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ i.a f3166b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ surfaceGL f3167c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ String f3168d;

    public /* synthetic */ a2(i.a aVar, surfaceGL surfacegl, String str) {
        this.f3166b = aVar;
        this.f3167c = surfacegl;
        this.f3168d = str;
    }

    public final void run() {
        surfaceGL.j(this.f3166b, this.f3167c, this.f3168d);
    }
}
