package l0;

import w0.k;

public final class p {

    /* renamed from: a  reason: collision with root package name */
    public static final p f3273a = new p();

    /* renamed from: b  reason: collision with root package name */
    private static final char[] f3274b = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};

    private p() {
    }

    public static /* synthetic */ String d(p pVar, byte[] bArr, int i2, int i3, int i4, Object obj) {
        if ((i4 & 2) != 0) {
            i2 = 0;
        }
        if ((i4 & 4) != 0) {
            i3 = bArr.length;
        }
        return pVar.c(bArr, i2, i3);
    }

    public final byte[] a(byte b2) {
        return new byte[]{b2};
    }

    public final String b(byte b2) {
        return d(this, a(b2), 0, 0, 6, (Object) null);
    }

    public final String c(byte[] bArr, int i2, int i3) {
        k.d(bArr, "array");
        char[] cArr = new char[(i3 * 2)];
        int i4 = i3 + i2;
        int i5 = 0;
        while (i2 < i4) {
            byte b2 = bArr[i2];
            int i6 = i5 + 1;
            char[] cArr2 = f3274b;
            cArr[i5] = cArr2[(b2 >>> 4) & 15];
            i5 = i6 + 1;
            cArr[i6] = cArr2[b2 & 15];
            i2++;
        }
        return new String(cArr);
    }
}
