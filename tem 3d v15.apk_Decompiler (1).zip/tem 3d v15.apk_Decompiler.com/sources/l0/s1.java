package l0;

import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.drawable.ShapeDrawable;
import w0.k;

public final class s1 extends ShapeDrawable.ShaderFactory {

    /* renamed from: a  reason: collision with root package name */
    private int[] f3295a;

    /* renamed from: b  reason: collision with root package name */
    private float[] f3296b;

    public s1(int[] iArr) {
        k.d(iArr, "colors");
        a(iArr, (float[]) null);
    }

    private final void a(int[] iArr, float[] fArr) {
        if (iArr == null || iArr.length == 0) {
            int[] iArr2 = new int[2];
            this.f3295a = iArr2;
            k.b(iArr2);
            iArr2[0] = Color.argb(255, 255, 255, 255);
            int[] iArr3 = this.f3295a;
            k.b(iArr3);
            iArr3[1] = Color.argb(0, 0, 0, 0);
        } else if (iArr.length == 1) {
            int[] iArr4 = new int[2];
            this.f3295a = iArr4;
            k.b(iArr4);
            iArr4[0] = iArr[0];
            int[] iArr5 = this.f3295a;
            k.b(iArr5);
            iArr5[1] = Color.argb(0, 0, 0, 0);
        } else {
            this.f3295a = iArr;
        }
        this.f3296b = fArr;
    }

    public Shader resize(int i2, int i3) {
        int[] iArr = this.f3295a;
        k.b(iArr);
        return new LinearGradient(0.0f, 0.0f, (float) i2, 0.0f, iArr, this.f3296b, Shader.TileMode.REPEAT);
    }
}
