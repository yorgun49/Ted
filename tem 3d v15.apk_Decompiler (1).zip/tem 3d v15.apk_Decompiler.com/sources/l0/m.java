package l0;

import android.app.Activity;
import android.app.Dialog;
import android.os.Environment;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import com.te.tem3d.R;
import java.io.File;
import java.util.Arrays;
import java.util.Objects;
import r.j;
import w0.g;
import w0.k;

public final class m {

    /* renamed from: g  reason: collision with root package name */
    public static final a f3221g = new a((g) null);
    /* access modifiers changed from: private */

    /* renamed from: h  reason: collision with root package name */
    public static final String f3222h = "..";

    /* renamed from: a  reason: collision with root package name */
    private final Activity f3223a;

    /* renamed from: b  reason: collision with root package name */
    private File f3224b;

    /* renamed from: c  reason: collision with root package name */
    private final Dialog f3225c;

    /* renamed from: d  reason: collision with root package name */
    private String f3226d;

    /* renamed from: e  reason: collision with root package name */
    private b f3227e;

    /* renamed from: f  reason: collision with root package name */
    private final ListView f3228f;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(g gVar) {
            this();
        }
    }

    public interface b {
        void a(File file);
    }

    public static final class c extends ArrayAdapter<String> {
        c(String[] strArr, Activity activity) {
            super(activity, 17367043, strArr);
        }

        public View getView(int i2, View view, ViewGroup viewGroup) {
            k.d(viewGroup, "parent");
            View view2 = super.getView(i2, view, viewGroup);
            TextView textView = (TextView) view2;
            k.b(textView);
            textView.setSingleLine(true);
            textView.setTextColor(-7829368);
            textView.setTextSize(18.0f);
            textView.setCompoundDrawablePadding(10);
            textView.setPadding(20, 0, 0, 0);
            textView.setCompoundDrawablesWithIntrinsicBounds(textView.getText().charAt(textView.getText().length() - 1) == '/' ? R.drawable.openfile_white : k.a(textView.getText().toString(), m.f3222h) ? R.drawable.arrow_back : R.drawable.filecsv, 0, 0, 0);
            return view2;
        }
    }

    public m(Activity activity) {
        File file;
        k.d(activity, "activity");
        this.f3223a = activity;
        Dialog dialog = new Dialog(activity);
        this.f3225c = dialog;
        dialog.requestWindowFeature(1);
        dialog.getWindow().clearFlags(2);
        dialog.getWindow().getAttributes().gravity = j.Q0;
        ListView listView = new ListView(activity);
        this.f3228f = listView;
        listView.setBackgroundResource(R.drawable.background_view_rounded_single);
        listView.setOnItemClickListener(new j(this));
        dialog.setContentView(listView);
        Window window = dialog.getWindow();
        k.b(window);
        window.setLayout(-2, -1);
        if (g()) {
            file = Environment.getExternalStorageDirectory();
            k.c(file, "getExternalStorageDirectory()");
        } else {
            file = activity.getExternalFilesDir((String) null);
            k.b(file);
        }
        h(file);
    }

    /* access modifiers changed from: private */
    public static final void d(m mVar, AdapterView adapterView, View view, int i2, long j2) {
        k.d(mVar, "this$0");
        Object itemAtPosition = mVar.f3228f.getItemAtPosition(i2);
        Objects.requireNonNull(itemAtPosition, "null cannot be cast to non-null type kotlin.String");
        File f2 = mVar.f((String) itemAtPosition);
        if (f2.isDirectory()) {
            mVar.h(f2);
            return;
        }
        b bVar = mVar.f3227e;
        if (bVar != null) {
            k.b(bVar);
            bVar.a(f2);
        }
        mVar.f3225c.dismiss();
    }

    private final File f(String str) {
        if (!k.a(str, f3222h)) {
            return new File(this.f3224b, str);
        }
        File file = this.f3224b;
        k.b(file);
        File parentFile = file.getParentFile();
        k.c(parentFile, "{\n            this.curre…th!!.parentFile\n        }");
        return parentFile;
    }

    private final void h(File file) {
        String[] strArr;
        int i2;
        this.f3224b = file;
        if (file.exists()) {
            File[] listFiles = file.listFiles(l.f3206a);
            File[] listFiles2 = file.listFiles(new k(this));
            if (listFiles != null || listFiles2 != null) {
                int length = listFiles != null ? listFiles.length : 0;
                int length2 = listFiles2 != null ? listFiles2.length : 0;
                if (file.getParentFile() == null) {
                    strArr = new String[(length + length2)];
                    i2 = 0;
                } else {
                    strArr = new String[(length + length2 + 1)];
                    strArr[0] = f3222h;
                    i2 = 1;
                }
                k.b(listFiles);
                Arrays.sort(listFiles);
                k.b(listFiles2);
                Arrays.sort(listFiles2);
                if (length != 0) {
                    for (int i3 = 0; i3 < length; i3++) {
                        strArr[i2] = listFiles[i3].getName() + '/';
                        i2++;
                    }
                }
                if (length2 != 0) {
                    for (int i4 = 0; i4 < length2; i4++) {
                        strArr[i2] = listFiles2[i4].getName();
                        i2++;
                    }
                }
                Dialog dialog = this.f3225c;
                File file2 = this.f3224b;
                k.b(file2);
                dialog.setTitle(file2.getPath());
                this.f3228f.setAdapter(new c(strArr, this.f3223a));
            } else {
                return;
            }
        }
        ViewGroup.LayoutParams layoutParams = this.f3228f.getLayoutParams();
        Objects.requireNonNull(layoutParams, "null cannot be cast to non-null type android.view.ViewGroup.MarginLayoutParams");
        ((ViewGroup.MarginLayoutParams) layoutParams).setMargins(2, 0, 2, 10);
    }

    /* access modifiers changed from: private */
    public static final boolean i(File file) {
        return file.isDirectory() && file.canRead();
    }

    /* access modifiers changed from: private */
    public static final boolean j(m mVar, File file) {
        k.d(mVar, "this$0");
        if (file.isDirectory() || !file.canRead()) {
            return false;
        }
        if (mVar.f3226d == null) {
            return true;
        }
        String name = file.getName();
        k.c(name, "file.name");
        String lowerCase = name.toLowerCase();
        k.c(lowerCase, "this as java.lang.String).toLowerCase()");
        String str = mVar.f3226d;
        k.b(str);
        return p.i(lowerCase, str, false, 2, (Object) null);
    }

    public final boolean g() {
        String externalStorageState = Environment.getExternalStorageState();
        return k.a("mounted", externalStorageState) || k.a("mounted_ro", externalStorageState);
    }

    public final void k(String str) {
        String str2;
        if (str != null) {
            str2 = str.toLowerCase();
            k.c(str2, "this as java.lang.String).toLowerCase()");
        } else {
            str2 = null;
        }
        this.f3226d = str2;
    }

    public final m l(b bVar) {
        k.d(bVar, "fileListener");
        this.f3227e = bVar;
        return this;
    }

    public final void m() {
        this.f3225c.show();
    }
}
