package l0;

import android.content.DialogInterface;
import android.widget.NumberPicker;
import com.te.tem3d.MainActivity;
import l0.v1;

public final /* synthetic */ class q implements DialogInterface.OnClickListener {

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ NumberPicker f3280b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ v1.a f3281c;

    public /* synthetic */ q(NumberPicker numberPicker, v1.a aVar) {
        this.f3280b = numberPicker;
        this.f3281c = aVar;
    }

    public final void onClick(DialogInterface dialogInterface, int i2) {
        MainActivity.q0(this.f3280b, this.f3281c, dialogInterface, i2);
    }
}
