package l0;

import android.view.View;
import android.widget.EditText;
import com.te.tem3d.MainActivity;

public final /* synthetic */ class k0 implements View.OnClickListener {

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ MainActivity f3203b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ EditText f3204c;

    public /* synthetic */ k0(MainActivity mainActivity, EditText editText) {
        this.f3203b = mainActivity;
        this.f3204c = editText;
    }

    public final void onClick(View view) {
        MainActivity.i2(this.f3203b, this.f3204c, view);
    }
}
