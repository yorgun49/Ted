package l0;

import android.widget.RadioGroup;
import com.te.tem3d.MainActivity;

public final /* synthetic */ class z0 implements RadioGroup.OnCheckedChangeListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ MainActivity f3378a;

    public /* synthetic */ z0(MainActivity mainActivity) {
        this.f3378a = mainActivity;
    }

    public final void onCheckedChanged(RadioGroup radioGroup, int i2) {
        MainActivity.t1(this.f3378a, radioGroup, i2);
    }
}
