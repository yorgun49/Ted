package l0;

import java.io.File;
import java.io.FileFilter;

public final /* synthetic */ class k implements FileFilter {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ m f3202a;

    public /* synthetic */ k(m mVar) {
        this.f3202a = mVar;
    }

    public final boolean accept(File file) {
        return m.j(this.f3202a, file);
    }
}
