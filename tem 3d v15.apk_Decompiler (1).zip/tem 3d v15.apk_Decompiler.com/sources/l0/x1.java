package l0;

public enum x1 {
    A_Position(1, "a_Position"),
    a_texture(2, "a_texture"),
    A_Color(3, "a_Color"),
    A_PositionWorld(4, "a_PositionWorld");
    

    /* renamed from: b  reason: collision with root package name */
    private final int f3355b;

    /* renamed from: c  reason: collision with root package name */
    private final String f3356c;

    private x1(int i2, String str) {
        this.f3355b = i2;
        this.f3356c = str;
    }

    public final int b() {
        return this.f3355b;
    }

    public final String c() {
        return this.f3356c;
    }
}
