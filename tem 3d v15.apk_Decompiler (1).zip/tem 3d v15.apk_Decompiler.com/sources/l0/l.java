package l0;

import java.io.File;
import java.io.FileFilter;

public final /* synthetic */ class l implements FileFilter {

    /* renamed from: a  reason: collision with root package name */
    public static final /* synthetic */ l f3206a = new l();

    private /* synthetic */ l() {
    }

    public final boolean accept(File file) {
        return m.i(file);
    }
}
