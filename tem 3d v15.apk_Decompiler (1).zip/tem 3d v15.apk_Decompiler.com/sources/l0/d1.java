package l0;

import android.view.View;
import android.widget.EditText;
import com.te.tem3d.MainActivity;

public final /* synthetic */ class d1 implements View.OnClickListener {

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ EditText f3177b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ MainActivity f3178c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ EditText f3179d;

    /* renamed from: e  reason: collision with root package name */
    public final /* synthetic */ EditText f3180e;

    public /* synthetic */ d1(EditText editText, MainActivity mainActivity, EditText editText2, EditText editText3) {
        this.f3177b = editText;
        this.f3178c = mainActivity;
        this.f3179d = editText2;
        this.f3180e = editText3;
    }

    public final void onClick(View view) {
        MainActivity.o2(this.f3177b, this.f3178c, this.f3179d, this.f3180e, view);
    }
}
