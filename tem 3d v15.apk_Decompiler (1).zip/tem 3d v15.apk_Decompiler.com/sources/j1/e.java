package j1;

import d1.d0;
import d1.o;
import d1.p;
import d1.v;
import d1.w;
import e1.b;
import java.io.EOFException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import q1.h;
import w0.k;

public final class e {

    /* renamed from: a  reason: collision with root package name */
    private static final h f3009a;

    /* renamed from: b  reason: collision with root package name */
    private static final h f3010b;

    static {
        h.a aVar = h.f3955f;
        f3009a = aVar.c("\"\\");
        f3010b = aVar.c("\t ,=");
    }

    public static final List<d1.h> a(v vVar, String str) {
        k.d(vVar, "$this$parseChallenges");
        k.d(str, "headerName");
        ArrayList arrayList = new ArrayList();
        int size = vVar.size();
        for (int i2 = 0; i2 < size; i2++) {
            if (p.j(str, vVar.b(i2), true)) {
                try {
                    c(new q1.e().j(vVar.d(i2)), arrayList);
                } catch (EOFException e2) {
                    m1.h.f3787c.g().j("Unable to parse challenge", 5, e2);
                }
            }
        }
        return arrayList;
    }

    public static final boolean b(d0 d0Var) {
        k.d(d0Var, "$this$promisesBody");
        if (k.a(d0Var.P().g(), "HEAD")) {
            return false;
        }
        int D = d0Var.D();
        return (((D >= 100 && D < 200) || D == 204 || D == 304) && b.r(d0Var) == -1 && !p.j("chunked", d0.H(d0Var, "Transfer-Encoding", (String) null, 2, (Object) null), true)) ? false : true;
    }

    private static final void c(q1.e eVar, List<d1.h> list) {
        String e2;
        int G;
        while (true) {
            String str = null;
            while (true) {
                if (str == null) {
                    g(eVar);
                    str = e(eVar);
                    if (str == null) {
                        return;
                    }
                }
                boolean g2 = g(eVar);
                e2 = e(eVar);
                if (e2 != null) {
                    byte b2 = (byte) 61;
                    G = b.G(eVar, b2);
                    boolean g3 = g(eVar);
                    if (g2 || (!g3 && !eVar.m())) {
                        LinkedHashMap linkedHashMap = new LinkedHashMap();
                        int G2 = G + b.G(eVar, b2);
                        while (true) {
                            if (e2 == null) {
                                e2 = e(eVar);
                                if (g(eVar)) {
                                    continue;
                                    break;
                                }
                                G2 = b.G(eVar, b2);
                            }
                            if (G2 == 0) {
                                continue;
                                break;
                            } else if (G2 <= 1 && !g(eVar)) {
                                String d2 = h(eVar, (byte) 34) ? d(eVar) : e(eVar);
                                if (d2 != null && ((String) linkedHashMap.put(e2, d2)) == null) {
                                    if (g(eVar) || eVar.m()) {
                                        e2 = null;
                                    } else {
                                        return;
                                    }
                                } else {
                                    return;
                                }
                            } else {
                                return;
                            }
                        }
                        list.add(new d1.h(str, linkedHashMap));
                        str = e2;
                    }
                } else if (eVar.m()) {
                    list.add(new d1.h(str, f0.d()));
                    return;
                } else {
                    return;
                }
            }
            Map singletonMap = Collections.singletonMap((Object) null, e2 + p.n("=", G));
            k.c(singletonMap, "Collections.singletonMap…ek + \"=\".repeat(eqCount))");
            list.add(new d1.h(str, singletonMap));
        }
    }

    private static final String d(q1.e eVar) {
        byte b2 = (byte) 34;
        if (eVar.w() == b2) {
            q1.e eVar2 = new q1.e();
            while (true) {
                long H = eVar.H(f3009a);
                if (H == -1) {
                    return null;
                }
                if (eVar.F(H) == b2) {
                    eVar2.v(eVar, H);
                    eVar.w();
                    return eVar2.Q();
                } else if (eVar.T() == H + 1) {
                    return null;
                } else {
                    eVar2.v(eVar, H);
                    eVar.w();
                    eVar2.v(eVar, 1);
                }
            }
        } else {
            throw new IllegalArgumentException("Failed requirement.".toString());
        }
    }

    private static final String e(q1.e eVar) {
        long H = eVar.H(f3010b);
        if (H == -1) {
            H = eVar.T();
        }
        if (H != 0) {
            return eVar.R(H);
        }
        return null;
    }

    public static final void f(p pVar, w wVar, v vVar) {
        k.d(pVar, "$this$receiveHeaders");
        k.d(wVar, "url");
        k.d(vVar, "headers");
        if (pVar != p.f2435a) {
            List<o> e2 = o.f2425n.e(wVar, vVar);
            if (!e2.isEmpty()) {
                pVar.b(wVar, e2);
            }
        }
    }

    private static final boolean g(q1.e eVar) {
        boolean z2 = false;
        while (!eVar.m()) {
            byte F = eVar.F(0);
            if (F == 9 || F == 32) {
                eVar.w();
            } else if (F != 44) {
                break;
            } else {
                eVar.w();
                z2 = true;
            }
        }
        return z2;
    }

    private static final boolean h(q1.e eVar, byte b2) {
        return !eVar.m() && eVar.F(0) == b2;
    }
}
