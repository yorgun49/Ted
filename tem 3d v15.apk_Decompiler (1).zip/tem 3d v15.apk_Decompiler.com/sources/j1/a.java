package j1;

import d1.b0;
import d1.c0;
import d1.d0;
import d1.e0;
import d1.o;
import d1.p;
import d1.x;
import d1.y;
import e1.b;
import java.util.List;
import q1.l;
import w0.k;

public final class a implements x {

    /* renamed from: a  reason: collision with root package name */
    private final p f3004a;

    public a(p pVar) {
        k.d(pVar, "cookieJar");
        this.f3004a = pVar;
    }

    private final String b(List<o> list) {
        StringBuilder sb = new StringBuilder();
        int i2 = 0;
        for (T next : list) {
            int i3 = i2 + 1;
            if (i2 < 0) {
                l.n();
            }
            o oVar = (o) next;
            if (i2 > 0) {
                sb.append("; ");
            }
            sb.append(oVar.e());
            sb.append('=');
            sb.append(oVar.g());
            i2 = i3;
        }
        String sb2 = sb.toString();
        k.c(sb2, "StringBuilder().apply(builderAction).toString()");
        return sb2;
    }

    public d0 a(x.a aVar) {
        e0 o2;
        k.d(aVar, "chain");
        b0 b2 = aVar.b();
        b0.a h2 = b2.h();
        c0 a2 = b2.a();
        if (a2 != null) {
            y b3 = a2.b();
            if (b3 != null) {
                h2.b("Content-Type", b3.toString());
            }
            long a3 = a2.a();
            if (a3 != -1) {
                h2.b("Content-Length", String.valueOf(a3));
                h2.f("Transfer-Encoding");
            } else {
                h2.b("Transfer-Encoding", "chunked");
                h2.f("Content-Length");
            }
        }
        boolean z2 = false;
        if (b2.d("Host") == null) {
            h2.b("Host", b.M(b2.i(), false, 1, (Object) null));
        }
        if (b2.d("Connection") == null) {
            h2.b("Connection", "Keep-Alive");
        }
        if (b2.d("Accept-Encoding") == null && b2.d("Range") == null) {
            h2.b("Accept-Encoding", "gzip");
            z2 = true;
        }
        List<o> a4 = this.f3004a.a(b2.i());
        if (!a4.isEmpty()) {
            h2.b("Cookie", b(a4));
        }
        if (b2.d("User-Agent") == null) {
            h2.b("User-Agent", "okhttp/4.9.2");
        }
        d0 a5 = aVar.a(h2.a());
        e.f(this.f3004a, b2.i(), a5.I());
        d0.a r2 = a5.L().r(b2);
        if (z2 && p.j("gzip", d0.H(a5, "Content-Encoding", (String) null, 2, (Object) null), true) && e.b(a5) && (o2 = a5.o()) != null) {
            l lVar = new l(o2.C());
            r2.k(a5.I().c().f("Content-Encoding").f("Content-Length").d());
            r2.b(new h(d0.H(a5, "Content-Type", (String) null, 2, (Object) null), -1, q1.o.b(lVar)));
        }
        return r2.c();
    }
}
