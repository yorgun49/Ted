package j1;

import d1.b0;
import d1.d0;
import d1.x;
import i1.c;
import i1.e;
import java.util.List;
import w0.k;

public final class g implements x.a {

    /* renamed from: a  reason: collision with root package name */
    private int f3012a;

    /* renamed from: b  reason: collision with root package name */
    private final e f3013b;

    /* renamed from: c  reason: collision with root package name */
    private final List<x> f3014c;

    /* renamed from: d  reason: collision with root package name */
    private final int f3015d;

    /* renamed from: e  reason: collision with root package name */
    private final c f3016e;

    /* renamed from: f  reason: collision with root package name */
    private final b0 f3017f;

    /* renamed from: g  reason: collision with root package name */
    private final int f3018g;

    /* renamed from: h  reason: collision with root package name */
    private final int f3019h;

    /* renamed from: i  reason: collision with root package name */
    private final int f3020i;

    public g(e eVar, List<? extends x> list, int i2, c cVar, b0 b0Var, int i3, int i4, int i5) {
        k.d(eVar, "call");
        k.d(list, "interceptors");
        k.d(b0Var, "request");
        this.f3013b = eVar;
        this.f3014c = list;
        this.f3015d = i2;
        this.f3016e = cVar;
        this.f3017f = b0Var;
        this.f3018g = i3;
        this.f3019h = i4;
        this.f3020i = i5;
    }

    public static /* synthetic */ g d(g gVar, int i2, c cVar, b0 b0Var, int i3, int i4, int i5, int i6, Object obj) {
        if ((i6 & 1) != 0) {
            i2 = gVar.f3015d;
        }
        if ((i6 & 2) != 0) {
            cVar = gVar.f3016e;
        }
        c cVar2 = cVar;
        if ((i6 & 4) != 0) {
            b0Var = gVar.f3017f;
        }
        b0 b0Var2 = b0Var;
        if ((i6 & 8) != 0) {
            i3 = gVar.f3018g;
        }
        int i7 = i3;
        if ((i6 & 16) != 0) {
            i4 = gVar.f3019h;
        }
        int i8 = i4;
        if ((i6 & 32) != 0) {
            i5 = gVar.f3020i;
        }
        return gVar.c(i2, cVar2, b0Var2, i7, i8, i5);
    }

    public d0 a(b0 b0Var) {
        k.d(b0Var, "request");
        boolean z2 = false;
        if (this.f3015d < this.f3014c.size()) {
            this.f3012a++;
            c cVar = this.f3016e;
            if (cVar != null) {
                if (cVar.j().g(b0Var.i())) {
                    if (!(this.f3012a == 1)) {
                        throw new IllegalStateException(("network interceptor " + this.f3014c.get(this.f3015d - 1) + " must call proceed() exactly once").toString());
                    }
                } else {
                    throw new IllegalStateException(("network interceptor " + this.f3014c.get(this.f3015d - 1) + " must retain the same host and port").toString());
                }
            }
            g d2 = d(this, this.f3015d + 1, (c) null, b0Var, 0, 0, 0, 58, (Object) null);
            x xVar = this.f3014c.get(this.f3015d);
            d0 a2 = xVar.a(d2);
            if (a2 != null) {
                if (this.f3016e != null) {
                    if (!(this.f3015d + 1 >= this.f3014c.size() || d2.f3012a == 1)) {
                        throw new IllegalStateException(("network interceptor " + xVar + " must call proceed() exactly once").toString());
                    }
                }
                if (a2.o() != null) {
                    z2 = true;
                }
                if (z2) {
                    return a2;
                }
                throw new IllegalStateException(("interceptor " + xVar + " returned a response with no body").toString());
            }
            throw new NullPointerException("interceptor " + xVar + " returned null");
        }
        throw new IllegalStateException("Check failed.".toString());
    }

    public b0 b() {
        return this.f3017f;
    }

    public final g c(int i2, c cVar, b0 b0Var, int i3, int i4, int i5) {
        k.d(b0Var, "request");
        return new g(this.f3013b, this.f3014c, i2, cVar, b0Var, i3, i4, i5);
    }

    public d1.e call() {
        return this.f3013b;
    }

    public final e e() {
        return this.f3013b;
    }

    public final int f() {
        return this.f3018g;
    }

    public final c g() {
        return this.f3016e;
    }

    public final int h() {
        return this.f3019h;
    }

    public final b0 i() {
        return this.f3017f;
    }

    public final int j() {
        return this.f3020i;
    }

    public int k() {
        return this.f3019h;
    }
}
