package j1;

import d1.b0;
import d1.c0;
import d1.d0;
import d1.e0;
import d1.x;
import i1.c;
import java.net.ProtocolException;
import q1.f;
import q1.o;
import w0.k;

public final class b implements x {

    /* renamed from: a  reason: collision with root package name */
    private final boolean f3005a;

    public b(boolean z2) {
        this.f3005a = z2;
    }

    public d0 a(x.a aVar) {
        boolean z2;
        d0.a aVar2;
        d0.a aVar3;
        e0 e0Var;
        k.d(aVar, "chain");
        g gVar = (g) aVar;
        c g2 = gVar.g();
        k.b(g2);
        b0 i2 = gVar.i();
        c0 a2 = i2.a();
        long currentTimeMillis = System.currentTimeMillis();
        g2.t(i2);
        Long l2 = null;
        if (!f.a(i2.g()) || a2 == null) {
            g2.n();
            aVar2 = null;
            z2 = true;
        } else {
            if (p.j("100-continue", i2.d("Expect"), true)) {
                g2.f();
                aVar2 = g2.p(true);
                g2.r();
                z2 = false;
            } else {
                aVar2 = null;
                z2 = true;
            }
            if (aVar2 != null) {
                g2.n();
                if (!g2.h().v()) {
                    g2.m();
                }
            } else if (a2.c()) {
                g2.f();
                a2.e(o.a(g2.c(i2, true)));
            } else {
                f a3 = o.a(g2.c(i2, false));
                a2.e(a3);
                a3.close();
            }
        }
        if (a2 == null || !a2.c()) {
            g2.e();
        }
        if (aVar2 == null) {
            aVar2 = g2.p(false);
            k.b(aVar2);
            if (z2) {
                g2.r();
                z2 = false;
            }
        }
        d0 c2 = aVar2.r(i2).i(g2.h().r()).s(currentTimeMillis).q(System.currentTimeMillis()).c();
        int D = c2.D();
        if (D == 100) {
            d0.a p2 = g2.p(false);
            k.b(p2);
            if (z2) {
                g2.r();
            }
            c2 = p2.r(i2).i(g2.h().r()).s(currentTimeMillis).q(System.currentTimeMillis()).c();
            D = c2.D();
        }
        g2.q(c2);
        if (!this.f3005a || D != 101) {
            aVar3 = c2.L();
            e0Var = g2.o(c2);
        } else {
            aVar3 = c2.L();
            e0Var = e1.b.f2637c;
        }
        d0 c3 = aVar3.b(e0Var).c();
        if (p.j("close", c3.P().d("Connection"), true) || p.j("close", d0.H(c3, "Connection", (String) null, 2, (Object) null), true)) {
            g2.m();
        }
        if (D == 204 || D == 205) {
            e0 o2 = c3.o();
            if ((o2 != null ? o2.A() : -1) > 0) {
                StringBuilder sb = new StringBuilder();
                sb.append("HTTP ");
                sb.append(D);
                sb.append(" had non-zero Content-Length: ");
                e0 o3 = c3.o();
                if (o3 != null) {
                    l2 = Long.valueOf(o3.A());
                }
                sb.append(l2);
                throw new ProtocolException(sb.toString());
            }
        }
        return c3;
    }
}
