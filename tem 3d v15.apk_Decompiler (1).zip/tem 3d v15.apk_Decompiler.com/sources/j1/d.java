package j1;

import d1.b0;
import d1.d0;
import i1.f;
import q1.a0;
import q1.y;

public interface d {
    y a(b0 b0Var, long j2);

    void b();

    void c();

    void cancel();

    d0.a d(boolean z2);

    long e(d0 d0Var);

    void f(b0 b0Var);

    f g();

    a0 h(d0 d0Var);
}
