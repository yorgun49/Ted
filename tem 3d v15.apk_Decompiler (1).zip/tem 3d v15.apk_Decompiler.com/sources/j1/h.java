package j1;

import d1.e0;
import d1.y;
import q1.g;
import w0.k;

public final class h extends e0 {

    /* renamed from: c  reason: collision with root package name */
    private final String f3021c;

    /* renamed from: d  reason: collision with root package name */
    private final long f3022d;

    /* renamed from: e  reason: collision with root package name */
    private final g f3023e;

    public h(String str, long j2, g gVar) {
        k.d(gVar, "source");
        this.f3021c = str;
        this.f3022d = j2;
        this.f3023e = gVar;
    }

    public long A() {
        return this.f3022d;
    }

    public y B() {
        String str = this.f3021c;
        if (str != null) {
            return y.f2482g.b(str);
        }
        return null;
    }

    public g C() {
        return this.f3023e;
    }
}
