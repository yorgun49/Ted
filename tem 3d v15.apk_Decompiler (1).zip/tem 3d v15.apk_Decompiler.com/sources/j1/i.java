package j1;

import d1.b0;
import d1.w;
import java.net.Proxy;
import w0.k;

public final class i {

    /* renamed from: a  reason: collision with root package name */
    public static final i f3024a = new i();

    private i() {
    }

    private final boolean b(b0 b0Var, Proxy.Type type) {
        return !b0Var.f() && type == Proxy.Type.HTTP;
    }

    public final String a(b0 b0Var, Proxy.Type type) {
        k.d(b0Var, "request");
        k.d(type, "proxyType");
        StringBuilder sb = new StringBuilder();
        sb.append(b0Var.g());
        sb.append(' ');
        i iVar = f3024a;
        boolean b2 = iVar.b(b0Var, type);
        w i2 = b0Var.i();
        if (b2) {
            sb.append(i2);
        } else {
            sb.append(iVar.c(i2));
        }
        sb.append(" HTTP/1.1");
        String sb2 = sb.toString();
        k.c(sb2, "StringBuilder().apply(builderAction).toString()");
        return sb2;
    }

    public final String c(w wVar) {
        k.d(wVar, "url");
        String d2 = wVar.d();
        String f2 = wVar.f();
        if (f2 == null) {
            return d2;
        }
        return d2 + '?' + f2;
    }
}
