package j1;

import d1.a0;
import java.net.ProtocolException;
import w0.g;

public final class k {

    /* renamed from: d  reason: collision with root package name */
    public static final a f3027d = new a((g) null);

    /* renamed from: a  reason: collision with root package name */
    public final a0 f3028a;

    /* renamed from: b  reason: collision with root package name */
    public final int f3029b;

    /* renamed from: c  reason: collision with root package name */
    public final String f3030c;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(g gVar) {
            this();
        }

        public final k a(String str) {
            a0 a0Var;
            String str2;
            w0.k.d(str, "statusLine");
            int i2 = 9;
            if (p.v(str, "HTTP/1.", false, 2, (Object) null)) {
                if (str.length() < 9 || str.charAt(8) != ' ') {
                    throw new ProtocolException("Unexpected status line: " + str);
                }
                int charAt = str.charAt(7) - '0';
                if (charAt == 0) {
                    a0Var = a0.HTTP_1_0;
                } else if (charAt == 1) {
                    a0Var = a0.HTTP_1_1;
                } else {
                    throw new ProtocolException("Unexpected status line: " + str);
                }
            } else if (p.v(str, "ICY ", false, 2, (Object) null)) {
                a0Var = a0.HTTP_1_0;
                i2 = 4;
            } else {
                throw new ProtocolException("Unexpected status line: " + str);
            }
            int i3 = i2 + 3;
            if (str.length() >= i3) {
                try {
                    String substring = str.substring(i2, i3);
                    w0.k.c(substring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                    int parseInt = Integer.parseInt(substring);
                    if (str.length() <= i3) {
                        str2 = "";
                    } else if (str.charAt(i3) == ' ') {
                        str2 = str.substring(i2 + 4);
                        w0.k.c(str2, "(this as java.lang.String).substring(startIndex)");
                    } else {
                        throw new ProtocolException("Unexpected status line: " + str);
                    }
                    return new k(a0Var, parseInt, str2);
                } catch (NumberFormatException unused) {
                    throw new ProtocolException("Unexpected status line: " + str);
                }
            } else {
                throw new ProtocolException("Unexpected status line: " + str);
            }
        }
    }

    public k(a0 a0Var, int i2, String str) {
        w0.k.d(a0Var, "protocol");
        w0.k.d(str, "message");
        this.f3028a = a0Var;
        this.f3029b = i2;
        this.f3030c = str;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.f3028a == a0.HTTP_1_0 ? "HTTP/1.0" : "HTTP/1.1");
        sb.append(' ');
        sb.append(this.f3029b);
        sb.append(' ');
        sb.append(this.f3030c);
        String sb2 = sb.toString();
        w0.k.c(sb2, "StringBuilder().apply(builderAction).toString()");
        return sb2;
    }
}
