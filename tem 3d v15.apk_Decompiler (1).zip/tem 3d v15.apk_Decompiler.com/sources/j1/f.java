package j1;

import w0.k;

public final class f {

    /* renamed from: a  reason: collision with root package name */
    public static final f f3011a = new f();

    private f() {
    }

    public static final boolean a(String str) {
        k.d(str, "method");
        return !k.a(str, "GET") && !k.a(str, "HEAD");
    }

    public static final boolean d(String str) {
        k.d(str, "method");
        return k.a(str, "POST") || k.a(str, "PUT") || k.a(str, "PATCH") || k.a(str, "PROPPATCH") || k.a(str, "REPORT");
    }

    public final boolean b(String str) {
        k.d(str, "method");
        return !k.a(str, "PROPFIND");
    }

    public final boolean c(String str) {
        k.d(str, "method");
        return k.a(str, "PROPFIND");
    }
}
