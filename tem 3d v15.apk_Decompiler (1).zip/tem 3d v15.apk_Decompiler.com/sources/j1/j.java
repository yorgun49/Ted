package j1;

import c1.f;
import d1.b0;
import d1.c0;
import d1.d0;
import d1.e0;
import d1.w;
import d1.x;
import d1.z;
import e1.b;
import i1.c;
import i1.e;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.ProtocolException;
import java.net.SocketTimeoutException;
import java.security.cert.CertificateException;
import java.util.List;
import javax.net.ssl.SSLHandshakeException;
import javax.net.ssl.SSLPeerUnverifiedException;
import w0.g;
import w0.k;

public final class j implements x {

    /* renamed from: b  reason: collision with root package name */
    public static final a f3025b = new a((g) null);

    /* renamed from: a  reason: collision with root package name */
    private final z f3026a;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(g gVar) {
            this();
        }
    }

    public j(z zVar) {
        k.d(zVar, "client");
        this.f3026a = zVar;
    }

    private final b0 b(d0 d0Var, String str) {
        String H;
        w o2;
        c0 c0Var = null;
        if (!this.f3026a.n() || (H = d0.H(d0Var, "Location", (String) null, 2, (Object) null)) == null || (o2 = d0Var.P().i().o(H)) == null) {
            return null;
        }
        if (!k.a(o2.p(), d0Var.P().i().p()) && !this.f3026a.p()) {
            return null;
        }
        b0.a h2 = d0Var.P().h();
        if (f.a(str)) {
            int D = d0Var.D();
            f fVar = f.f3011a;
            boolean z2 = fVar.c(str) || D == 308 || D == 307;
            if (fVar.b(str) && D != 308 && D != 307) {
                str = "GET";
            } else if (z2) {
                c0Var = d0Var.P().a();
            }
            h2.d(str, c0Var);
            if (!z2) {
                h2.f("Transfer-Encoding");
                h2.f("Content-Length");
                h2.f("Content-Type");
            }
        }
        if (!b.g(d0Var.P().i(), o2)) {
            h2.f("Authorization");
        }
        return h2.g(o2).a();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0003, code lost:
        r1 = r7.h();
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private final d1.b0 c(d1.d0 r6, i1.c r7) {
        /*
            r5 = this;
            r0 = 0
            if (r7 == 0) goto L_0x000e
            i1.f r1 = r7.h()
            if (r1 == 0) goto L_0x000e
            d1.f0 r1 = r1.z()
            goto L_0x000f
        L_0x000e:
            r1 = r0
        L_0x000f:
            int r2 = r6.D()
            d1.b0 r3 = r6.P()
            java.lang.String r3 = r3.g()
            r4 = 307(0x133, float:4.3E-43)
            if (r2 == r4) goto L_0x00df
            r4 = 308(0x134, float:4.32E-43)
            if (r2 == r4) goto L_0x00df
            r4 = 401(0x191, float:5.62E-43)
            if (r2 == r4) goto L_0x00d4
            r4 = 421(0x1a5, float:5.9E-43)
            if (r2 == r4) goto L_0x00ad
            r7 = 503(0x1f7, float:7.05E-43)
            if (r2 == r7) goto L_0x0091
            r7 = 407(0x197, float:5.7E-43)
            if (r2 == r7) goto L_0x006f
            r7 = 408(0x198, float:5.72E-43)
            if (r2 == r7) goto L_0x003b
            switch(r2) {
                case 300: goto L_0x00df;
                case 301: goto L_0x00df;
                case 302: goto L_0x00df;
                case 303: goto L_0x00df;
                default: goto L_0x003a;
            }
        L_0x003a:
            return r0
        L_0x003b:
            d1.z r1 = r5.f3026a
            boolean r1 = r1.B()
            if (r1 != 0) goto L_0x0044
            return r0
        L_0x0044:
            d1.b0 r1 = r6.P()
            d1.c0 r1 = r1.a()
            if (r1 == 0) goto L_0x0055
            boolean r1 = r1.d()
            if (r1 == 0) goto L_0x0055
            return r0
        L_0x0055:
            d1.d0 r1 = r6.M()
            if (r1 == 0) goto L_0x0062
            int r1 = r1.D()
            if (r1 != r7) goto L_0x0062
            return r0
        L_0x0062:
            r7 = 0
            int r7 = r5.g(r6, r7)
            if (r7 <= 0) goto L_0x006a
            return r0
        L_0x006a:
            d1.b0 r6 = r6.P()
            return r6
        L_0x006f:
            w0.k.b(r1)
            java.net.Proxy r7 = r1.b()
            java.net.Proxy$Type r7 = r7.type()
            java.net.Proxy$Type r0 = java.net.Proxy.Type.HTTP
            if (r7 != r0) goto L_0x0089
            d1.z r7 = r5.f3026a
            d1.b r7 = r7.y()
            d1.b0 r6 = r7.a(r1, r6)
            return r6
        L_0x0089:
            java.net.ProtocolException r6 = new java.net.ProtocolException
            java.lang.String r7 = "Received HTTP_PROXY_AUTH (407) code while not using proxy"
            r6.<init>(r7)
            throw r6
        L_0x0091:
            d1.d0 r1 = r6.M()
            if (r1 == 0) goto L_0x009e
            int r1 = r1.D()
            if (r1 != r7) goto L_0x009e
            return r0
        L_0x009e:
            r7 = 2147483647(0x7fffffff, float:NaN)
            int r7 = r5.g(r6, r7)
            if (r7 != 0) goto L_0x00ac
            d1.b0 r6 = r6.P()
            return r6
        L_0x00ac:
            return r0
        L_0x00ad:
            d1.b0 r1 = r6.P()
            d1.c0 r1 = r1.a()
            if (r1 == 0) goto L_0x00be
            boolean r1 = r1.d()
            if (r1 == 0) goto L_0x00be
            return r0
        L_0x00be:
            if (r7 == 0) goto L_0x00d3
            boolean r1 = r7.k()
            if (r1 != 0) goto L_0x00c7
            goto L_0x00d3
        L_0x00c7:
            i1.f r7 = r7.h()
            r7.x()
            d1.b0 r6 = r6.P()
            return r6
        L_0x00d3:
            return r0
        L_0x00d4:
            d1.z r7 = r5.f3026a
            d1.b r7 = r7.c()
            d1.b0 r6 = r7.a(r1, r6)
            return r6
        L_0x00df:
            d1.b0 r6 = r5.b(r6, r3)
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: j1.j.c(d1.d0, i1.c):d1.b0");
    }

    private final boolean d(IOException iOException, boolean z2) {
        if (iOException instanceof ProtocolException) {
            return false;
        }
        return iOException instanceof InterruptedIOException ? (iOException instanceof SocketTimeoutException) && !z2 : (!(iOException instanceof SSLHandshakeException) || !(iOException.getCause() instanceof CertificateException)) && !(iOException instanceof SSLPeerUnverifiedException);
    }

    private final boolean e(IOException iOException, e eVar, b0 b0Var, boolean z2) {
        if (!this.f3026a.B()) {
            return false;
        }
        return (!z2 || !f(iOException, b0Var)) && d(iOException, z2) && eVar.y();
    }

    private final boolean f(IOException iOException, b0 b0Var) {
        c0 a2 = b0Var.a();
        return (a2 != null && a2.d()) || (iOException instanceof FileNotFoundException);
    }

    private final int g(d0 d0Var, int i2) {
        String H = d0.H(d0Var, "Retry-After", (String) null, 2, (Object) null);
        if (H == null) {
            return i2;
        }
        if (!new f("\\d+").a(H)) {
            return Integer.MAX_VALUE;
        }
        Integer valueOf = Integer.valueOf(H);
        k.c(valueOf, "Integer.valueOf(header)");
        return valueOf.intValue();
    }

    public d0 a(x.a aVar) {
        IOException e2;
        k.d(aVar, "chain");
        g gVar = (g) aVar;
        b0 i2 = gVar.i();
        e e3 = gVar.e();
        List g2 = l.g();
        d0 d0Var = null;
        boolean z2 = true;
        int i3 = 0;
        while (true) {
            e3.i(i2, z2);
            try {
                if (!e3.t()) {
                    d0 a2 = gVar.a(i2);
                    if (d0Var != null) {
                        a2 = a2.L().o(d0Var.L().b((e0) null).c()).c();
                    }
                    d0Var = a2;
                    c p2 = e3.p();
                    b0 c2 = c(d0Var, p2);
                    if (c2 == null) {
                        if (p2 != null && p2.l()) {
                            e3.A();
                        }
                        e3.j(false);
                        return d0Var;
                    }
                    c0 a3 = c2.a();
                    if (a3 == null || !a3.d()) {
                        e0 o2 = d0Var.o();
                        if (o2 != null) {
                            b.i(o2);
                        }
                        i3++;
                        if (i3 <= 20) {
                            e3.j(true);
                            i2 = c2;
                            z2 = true;
                        } else {
                            throw new ProtocolException("Too many follow-up requests: " + i3);
                        }
                    } else {
                        e3.j(false);
                        return d0Var;
                    }
                } else {
                    throw new IOException("Canceled");
                }
            } catch (i1.j e4) {
                if (e(e4.c(), e3, i2, false)) {
                    e2 = e4.b();
                    g2 = t.H(g2, e2);
                    e3.j(true);
                    z2 = false;
                } else {
                    throw b.T(e4.b(), g2);
                }
            } catch (IOException e5) {
                e2 = e5;
                if (e(e2, e3, i2, !(e2 instanceof l1.a))) {
                    g2 = t.H(g2, e2);
                    e3.j(true);
                    z2 = false;
                } else {
                    throw b.T(e2, g2);
                }
            } catch (Throwable th) {
                e3.j(true);
                throw th;
            }
        }
    }
}
