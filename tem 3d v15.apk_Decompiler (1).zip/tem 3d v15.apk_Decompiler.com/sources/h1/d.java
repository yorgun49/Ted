package h1;

import e1.b;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import o0.m;
import w0.k;

public final class d {

    /* renamed from: a  reason: collision with root package name */
    private boolean f2789a;

    /* renamed from: b  reason: collision with root package name */
    private a f2790b;

    /* renamed from: c  reason: collision with root package name */
    private final List<a> f2791c = new ArrayList();

    /* renamed from: d  reason: collision with root package name */
    private boolean f2792d;

    /* renamed from: e  reason: collision with root package name */
    private final e f2793e;

    /* renamed from: f  reason: collision with root package name */
    private final String f2794f;

    public d(e eVar, String str) {
        k.d(eVar, "taskRunner");
        k.d(str, "name");
        this.f2793e = eVar;
        this.f2794f = str;
    }

    public static /* synthetic */ void j(d dVar, a aVar, long j2, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            j2 = 0;
        }
        dVar.i(aVar, j2);
    }

    public final void a() {
        if (!b.f2642h || !Thread.holdsLock(this)) {
            synchronized (this.f2793e) {
                if (b()) {
                    this.f2793e.h(this);
                }
                m mVar = m.f3885a;
            }
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Thread ");
        Thread currentThread = Thread.currentThread();
        k.c(currentThread, "Thread.currentThread()");
        sb.append(currentThread.getName());
        sb.append(" MUST NOT hold lock on ");
        sb.append(this);
        throw new AssertionError(sb.toString());
    }

    public final boolean b() {
        a aVar = this.f2790b;
        if (aVar != null) {
            k.b(aVar);
            if (aVar.a()) {
                this.f2792d = true;
            }
        }
        boolean z2 = false;
        for (int size = this.f2791c.size() - 1; size >= 0; size--) {
            if (this.f2791c.get(size).a()) {
                a aVar2 = this.f2791c.get(size);
                if (e.f2797j.a().isLoggable(Level.FINE)) {
                    b.c(aVar2, this, "canceled");
                }
                this.f2791c.remove(size);
                z2 = true;
            }
        }
        return z2;
    }

    public final a c() {
        return this.f2790b;
    }

    public final boolean d() {
        return this.f2792d;
    }

    public final List<a> e() {
        return this.f2791c;
    }

    public final String f() {
        return this.f2794f;
    }

    public final boolean g() {
        return this.f2789a;
    }

    public final e h() {
        return this.f2793e;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0026, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void i(h1.a r3, long r4) {
        /*
            r2 = this;
            java.lang.String r0 = "task"
            w0.k.d(r3, r0)
            h1.e r0 = r2.f2793e
            monitor-enter(r0)
            boolean r1 = r2.f2789a     // Catch:{ all -> 0x0050 }
            if (r1 == 0) goto L_0x0040
            boolean r4 = r3.a()     // Catch:{ all -> 0x0050 }
            if (r4 == 0) goto L_0x0027
            h1.e$b r4 = h1.e.f2797j     // Catch:{ all -> 0x0050 }
            java.util.logging.Logger r4 = r4.a()     // Catch:{ all -> 0x0050 }
            java.util.logging.Level r5 = java.util.logging.Level.FINE     // Catch:{ all -> 0x0050 }
            boolean r4 = r4.isLoggable(r5)     // Catch:{ all -> 0x0050 }
            if (r4 == 0) goto L_0x0025
            java.lang.String r4 = "schedule canceled (queue is shutdown)"
            h1.b.c(r3, r2, r4)     // Catch:{ all -> 0x0050 }
        L_0x0025:
            monitor-exit(r0)
            return
        L_0x0027:
            h1.e$b r4 = h1.e.f2797j     // Catch:{ all -> 0x0050 }
            java.util.logging.Logger r4 = r4.a()     // Catch:{ all -> 0x0050 }
            java.util.logging.Level r5 = java.util.logging.Level.FINE     // Catch:{ all -> 0x0050 }
            boolean r4 = r4.isLoggable(r5)     // Catch:{ all -> 0x0050 }
            if (r4 == 0) goto L_0x003a
            java.lang.String r4 = "schedule failed (queue is shutdown)"
            h1.b.c(r3, r2, r4)     // Catch:{ all -> 0x0050 }
        L_0x003a:
            java.util.concurrent.RejectedExecutionException r3 = new java.util.concurrent.RejectedExecutionException     // Catch:{ all -> 0x0050 }
            r3.<init>()     // Catch:{ all -> 0x0050 }
            throw r3     // Catch:{ all -> 0x0050 }
        L_0x0040:
            r1 = 0
            boolean r3 = r2.k(r3, r4, r1)     // Catch:{ all -> 0x0050 }
            if (r3 == 0) goto L_0x004c
            h1.e r3 = r2.f2793e     // Catch:{ all -> 0x0050 }
            r3.h(r2)     // Catch:{ all -> 0x0050 }
        L_0x004c:
            o0.m r3 = o0.m.f3885a     // Catch:{ all -> 0x0050 }
            monitor-exit(r0)
            return
        L_0x0050:
            r3 = move-exception
            monitor-exit(r0)
            throw r3
        */
        throw new UnsupportedOperationException("Method not decompiled: h1.d.i(h1.a, long):void");
    }

    public final boolean k(a aVar, long j2, boolean z2) {
        StringBuilder sb;
        String str;
        k.d(aVar, "task");
        aVar.e(this);
        long b2 = this.f2793e.g().b();
        long j3 = b2 + j2;
        int indexOf = this.f2791c.indexOf(aVar);
        if (indexOf != -1) {
            if (aVar.c() <= j3) {
                if (e.f2797j.a().isLoggable(Level.FINE)) {
                    b.c(aVar, this, "already scheduled");
                }
                return false;
            }
            this.f2791c.remove(indexOf);
        }
        aVar.g(j3);
        if (e.f2797j.a().isLoggable(Level.FINE)) {
            if (z2) {
                sb = new StringBuilder();
                str = "run again after ";
            } else {
                sb = new StringBuilder();
                str = "scheduled after ";
            }
            sb.append(str);
            sb.append(b.b(j3 - b2));
            b.c(aVar, this, sb.toString());
        }
        Iterator<a> it = this.f2791c.iterator();
        int i2 = 0;
        while (true) {
            if (!it.hasNext()) {
                i2 = -1;
                break;
            }
            if (it.next().c() - b2 > j2) {
                break;
            }
            i2++;
        }
        if (i2 == -1) {
            i2 = this.f2791c.size();
        }
        this.f2791c.add(i2, aVar);
        return i2 == 0;
    }

    public final void l(a aVar) {
        this.f2790b = aVar;
    }

    public final void m(boolean z2) {
        this.f2792d = z2;
    }

    public final void n() {
        if (!b.f2642h || !Thread.holdsLock(this)) {
            synchronized (this.f2793e) {
                this.f2789a = true;
                if (b()) {
                    this.f2793e.h(this);
                }
                m mVar = m.f3885a;
            }
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Thread ");
        Thread currentThread = Thread.currentThread();
        k.c(currentThread, "Thread.currentThread()");
        sb.append(currentThread.getName());
        sb.append(" MUST NOT hold lock on ");
        sb.append(this);
        throw new AssertionError(sb.toString());
    }

    public String toString() {
        return this.f2794f;
    }
}
