package h1;

import w0.g;
import w0.k;

public abstract class a {

    /* renamed from: a  reason: collision with root package name */
    private d f2782a;

    /* renamed from: b  reason: collision with root package name */
    private long f2783b;

    /* renamed from: c  reason: collision with root package name */
    private final String f2784c;

    /* renamed from: d  reason: collision with root package name */
    private final boolean f2785d;

    public a(String str, boolean z2) {
        k.d(str, "name");
        this.f2784c = str;
        this.f2785d = z2;
        this.f2783b = -1;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ a(String str, boolean z2, int i2, g gVar) {
        this(str, (i2 & 2) != 0 ? true : z2);
    }

    public final boolean a() {
        return this.f2785d;
    }

    public final String b() {
        return this.f2784c;
    }

    public final long c() {
        return this.f2783b;
    }

    public final d d() {
        return this.f2782a;
    }

    public final void e(d dVar) {
        k.d(dVar, "queue");
        d dVar2 = this.f2782a;
        if (dVar2 != dVar) {
            if (dVar2 == null) {
                this.f2782a = dVar;
                return;
            }
            throw new IllegalStateException("task is in multiple queues".toString());
        }
    }

    public abstract long f();

    public final void g(long j2) {
        this.f2783b = j2;
    }

    public String toString() {
        return this.f2784c;
    }
}
