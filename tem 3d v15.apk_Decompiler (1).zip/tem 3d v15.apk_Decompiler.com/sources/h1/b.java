package h1;

import java.util.Arrays;
import java.util.logging.Logger;
import w0.k;
import w0.s;

public final class b {
    public static final String b(long j2) {
        StringBuilder sb;
        long j3;
        long j4;
        StringBuilder sb2;
        long j5;
        if (j2 <= ((long) -999500000)) {
            sb = new StringBuilder();
            j3 = j2 - ((long) 500000000);
        } else {
            if (j2 <= ((long) -999500)) {
                sb = new StringBuilder();
                j4 = j2 - ((long) 500000);
            } else {
                if (j2 <= 0) {
                    sb2 = new StringBuilder();
                    j5 = j2 - ((long) 500);
                } else if (j2 < ((long) 999500)) {
                    sb2 = new StringBuilder();
                    j5 = j2 + ((long) 500);
                } else if (j2 < ((long) 999500000)) {
                    j4 = j2 + ((long) 500000);
                } else {
                    sb = new StringBuilder();
                    j3 = j2 + ((long) 500000000);
                }
                sb2.append(j5 / ((long) 1000));
                sb2.append(" µs");
                String sb3 = sb2.toString();
                s sVar = s.f4287a;
                String format = String.format("%6s", Arrays.copyOf(new Object[]{sb3}, 1));
                k.c(format, "java.lang.String.format(format, *args)");
                return format;
            }
            sb2.append(j4 / ((long) 1000000));
            sb2.append(" ms");
            String sb32 = sb2.toString();
            s sVar2 = s.f4287a;
            String format2 = String.format("%6s", Arrays.copyOf(new Object[]{sb32}, 1));
            k.c(format2, "java.lang.String.format(format, *args)");
            return format2;
        }
        sb2.append(j3 / ((long) 1000000000));
        sb2.append(" s ");
        String sb322 = sb2.toString();
        s sVar22 = s.f4287a;
        String format22 = String.format("%6s", Arrays.copyOf(new Object[]{sb322}, 1));
        k.c(format22, "java.lang.String.format(format, *args)");
        return format22;
    }

    /* access modifiers changed from: private */
    public static final void c(a aVar, d dVar, String str) {
        Logger a2 = e.f2797j.a();
        StringBuilder sb = new StringBuilder();
        sb.append(dVar.f());
        sb.append(' ');
        s sVar = s.f4287a;
        String format = String.format("%-22s", Arrays.copyOf(new Object[]{str}, 1));
        k.c(format, "java.lang.String.format(format, *args)");
        sb.append(format);
        sb.append(": ");
        sb.append(aVar.b());
        a2.fine(sb.toString());
    }
}
