package h1;

import v0.a;

public final class c extends a {

    /* renamed from: e  reason: collision with root package name */
    final /* synthetic */ a f2786e;

    /* renamed from: f  reason: collision with root package name */
    final /* synthetic */ String f2787f;

    /* renamed from: g  reason: collision with root package name */
    final /* synthetic */ boolean f2788g;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public c(a aVar, String str, boolean z2, String str2, boolean z3) {
        super(str2, z3);
        this.f2786e = aVar;
        this.f2787f = str;
        this.f2788g = z2;
    }

    public long f() {
        this.f2786e.c();
        return -1;
    }
}
