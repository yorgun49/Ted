package h1;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import o0.m;
import w0.g;
import w0.k;

public final class e {

    /* renamed from: h  reason: collision with root package name */
    public static final e f2795h = new e(new c(e1.b.I(e1.b.f2643i + " TaskRunner", true)));
    /* access modifiers changed from: private */

    /* renamed from: i  reason: collision with root package name */
    public static final Logger f2796i;

    /* renamed from: j  reason: collision with root package name */
    public static final b f2797j = new b((g) null);

    /* renamed from: a  reason: collision with root package name */
    private int f2798a = 10000;

    /* renamed from: b  reason: collision with root package name */
    private boolean f2799b;

    /* renamed from: c  reason: collision with root package name */
    private long f2800c;

    /* renamed from: d  reason: collision with root package name */
    private final List<d> f2801d = new ArrayList();

    /* renamed from: e  reason: collision with root package name */
    private final List<d> f2802e = new ArrayList();

    /* renamed from: f  reason: collision with root package name */
    private final Runnable f2803f = new d(this);

    /* renamed from: g  reason: collision with root package name */
    private final a f2804g;

    public interface a {
        void a(e eVar, long j2);

        long b();

        void c(e eVar);

        void execute(Runnable runnable);
    }

    public static final class b {
        private b() {
        }

        public /* synthetic */ b(g gVar) {
            this();
        }

        public final Logger a() {
            return e.f2796i;
        }
    }

    public static final class c implements a {

        /* renamed from: a  reason: collision with root package name */
        private final ThreadPoolExecutor f2805a;

        public c(ThreadFactory threadFactory) {
            k.d(threadFactory, "threadFactory");
            this.f2805a = new ThreadPoolExecutor(0, Integer.MAX_VALUE, 60, TimeUnit.SECONDS, new SynchronousQueue(), threadFactory);
        }

        public void a(e eVar, long j2) {
            k.d(eVar, "taskRunner");
            long j3 = j2 / 1000000;
            long j4 = j2 - (1000000 * j3);
            if (j3 > 0 || j2 > 0) {
                eVar.wait(j3, (int) j4);
            }
        }

        public long b() {
            return System.nanoTime();
        }

        public void c(e eVar) {
            k.d(eVar, "taskRunner");
            eVar.notify();
        }

        public void execute(Runnable runnable) {
            k.d(runnable, "runnable");
            this.f2805a.execute(runnable);
        }
    }

    public static final class d implements Runnable {

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ e f2806b;

        d(e eVar) {
            this.f2806b = eVar;
        }

        public void run() {
            a d2;
            while (true) {
                synchronized (this.f2806b) {
                    d2 = this.f2806b.d();
                }
                if (d2 != null) {
                    d d3 = d2.d();
                    k.b(d3);
                    long j2 = -1;
                    boolean isLoggable = e.f2797j.a().isLoggable(Level.FINE);
                    if (isLoggable) {
                        j2 = d3.h().g().b();
                        b.c(d2, d3, "starting");
                    }
                    try {
                        this.f2806b.j(d2);
                        m mVar = m.f3885a;
                        if (isLoggable) {
                            long b2 = d3.h().g().b() - j2;
                            b.c(d2, d3, "finished run in " + b.b(b2));
                        }
                    } catch (Throwable th) {
                        if (isLoggable) {
                            long b3 = d3.h().g().b() - j2;
                            b.c(d2, d3, "failed a run in " + b.b(b3));
                        }
                        throw th;
                    }
                } else {
                    return;
                }
            }
        }
    }

    static {
        Logger logger = Logger.getLogger(e.class.getName());
        k.c(logger, "Logger.getLogger(TaskRunner::class.java.name)");
        f2796i = logger;
    }

    public e(a aVar) {
        k.d(aVar, "backend");
        this.f2804g = aVar;
    }

    private final void c(a aVar, long j2) {
        if (!e1.b.f2642h || Thread.holdsLock(this)) {
            d d2 = aVar.d();
            k.b(d2);
            if (d2.c() == aVar) {
                boolean d3 = d2.d();
                d2.m(false);
                d2.l((a) null);
                this.f2801d.remove(d2);
                if (j2 != -1 && !d3 && !d2.g()) {
                    d2.k(aVar, j2, true);
                }
                if (!d2.e().isEmpty()) {
                    this.f2802e.add(d2);
                    return;
                }
                return;
            }
            throw new IllegalStateException("Check failed.".toString());
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Thread ");
        Thread currentThread = Thread.currentThread();
        k.c(currentThread, "Thread.currentThread()");
        sb.append(currentThread.getName());
        sb.append(" MUST hold lock on ");
        sb.append(this);
        throw new AssertionError(sb.toString());
    }

    private final void e(a aVar) {
        if (!e1.b.f2642h || Thread.holdsLock(this)) {
            aVar.g(-1);
            d d2 = aVar.d();
            k.b(d2);
            d2.e().remove(aVar);
            this.f2802e.remove(d2);
            d2.l(aVar);
            this.f2801d.add(d2);
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Thread ");
        Thread currentThread = Thread.currentThread();
        k.c(currentThread, "Thread.currentThread()");
        sb.append(currentThread.getName());
        sb.append(" MUST hold lock on ");
        sb.append(this);
        throw new AssertionError(sb.toString());
    }

    /* access modifiers changed from: private */
    public final void j(a aVar) {
        if (!e1.b.f2642h || !Thread.holdsLock(this)) {
            Thread currentThread = Thread.currentThread();
            k.c(currentThread, "currentThread");
            String name = currentThread.getName();
            currentThread.setName(aVar.b());
            try {
                long f2 = aVar.f();
                synchronized (this) {
                    c(aVar, f2);
                    m mVar = m.f3885a;
                }
                currentThread.setName(name);
            } catch (Throwable th) {
                synchronized (this) {
                    c(aVar, -1);
                    m mVar2 = m.f3885a;
                    currentThread.setName(name);
                    throw th;
                }
            }
        } else {
            StringBuilder sb = new StringBuilder();
            sb.append("Thread ");
            Thread currentThread2 = Thread.currentThread();
            k.c(currentThread2, "Thread.currentThread()");
            sb.append(currentThread2.getName());
            sb.append(" MUST NOT hold lock on ");
            sb.append(this);
            throw new AssertionError(sb.toString());
        }
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(7:34|35|36|39|40|47|37) */
    /* JADX WARNING: Code restructure failed: missing block: B:38:0x00c1, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:41:0x00c7, code lost:
        r15.f2799b = false;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:42:0x00ca, code lost:
        throw r0;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:39:0x00c3 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final h1.a d() {
        /*
            r15 = this;
            boolean r0 = e1.b.f2642h
            if (r0 == 0) goto L_0x0037
            boolean r0 = java.lang.Thread.holdsLock(r15)
            if (r0 == 0) goto L_0x000b
            goto L_0x0037
        L_0x000b:
            java.lang.AssertionError r0 = new java.lang.AssertionError
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "Thread "
            r1.append(r2)
            java.lang.Thread r2 = java.lang.Thread.currentThread()
            java.lang.String r3 = "Thread.currentThread()"
            w0.k.c(r2, r3)
            java.lang.String r2 = r2.getName()
            r1.append(r2)
            java.lang.String r2 = " MUST hold lock on "
            r1.append(r2)
            r1.append(r15)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x0037:
            java.util.List<h1.d> r0 = r15.f2802e
            boolean r0 = r0.isEmpty()
            r1 = 0
            if (r0 == 0) goto L_0x0041
            return r1
        L_0x0041:
            h1.e$a r0 = r15.f2804g
            long r2 = r0.b()
            r4 = 9223372036854775807(0x7fffffffffffffff, double:NaN)
            java.util.List<h1.d> r0 = r15.f2802e
            java.util.Iterator r0 = r0.iterator()
            r6 = r1
        L_0x0053:
            boolean r7 = r0.hasNext()
            r8 = 1
            r9 = 0
            if (r7 == 0) goto L_0x0085
            java.lang.Object r7 = r0.next()
            h1.d r7 = (h1.d) r7
            java.util.List r7 = r7.e()
            java.lang.Object r7 = r7.get(r9)
            h1.a r7 = (h1.a) r7
            long r10 = r7.c()
            long r10 = r10 - r2
            r12 = 0
            long r10 = java.lang.Math.max(r12, r10)
            int r14 = (r10 > r12 ? 1 : (r10 == r12 ? 0 : -1))
            if (r14 <= 0) goto L_0x007f
            long r4 = java.lang.Math.min(r10, r4)
            goto L_0x0053
        L_0x007f:
            if (r6 == 0) goto L_0x0083
            r0 = 1
            goto L_0x0086
        L_0x0083:
            r6 = r7
            goto L_0x0053
        L_0x0085:
            r0 = 0
        L_0x0086:
            if (r6 == 0) goto L_0x00a2
            r15.e(r6)
            if (r0 != 0) goto L_0x009a
            boolean r0 = r15.f2799b
            if (r0 != 0) goto L_0x00a1
            java.util.List<h1.d> r0 = r15.f2802e
            boolean r0 = r0.isEmpty()
            r0 = r0 ^ r8
            if (r0 == 0) goto L_0x00a1
        L_0x009a:
            h1.e$a r0 = r15.f2804g
            java.lang.Runnable r1 = r15.f2803f
            r0.execute(r1)
        L_0x00a1:
            return r6
        L_0x00a2:
            boolean r0 = r15.f2799b
            if (r0 == 0) goto L_0x00b3
            long r6 = r15.f2800c
            long r6 = r6 - r2
            int r0 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r0 >= 0) goto L_0x00b2
            h1.e$a r0 = r15.f2804g
            r0.c(r15)
        L_0x00b2:
            return r1
        L_0x00b3:
            r15.f2799b = r8
            long r2 = r2 + r4
            r15.f2800c = r2
            h1.e$a r0 = r15.f2804g     // Catch:{ InterruptedException -> 0x00c3 }
            r0.a(r15, r4)     // Catch:{ InterruptedException -> 0x00c3 }
        L_0x00bd:
            r15.f2799b = r9
            goto L_0x0037
        L_0x00c1:
            r0 = move-exception
            goto L_0x00c7
        L_0x00c3:
            r15.f()     // Catch:{ all -> 0x00c1 }
            goto L_0x00bd
        L_0x00c7:
            r15.f2799b = r9
            goto L_0x00cb
        L_0x00ca:
            throw r0
        L_0x00cb:
            goto L_0x00ca
        */
        throw new UnsupportedOperationException("Method not decompiled: h1.e.d():h1.a");
    }

    public final void f() {
        for (int size = this.f2801d.size() - 1; size >= 0; size--) {
            this.f2801d.get(size).b();
        }
        for (int size2 = this.f2802e.size() - 1; size2 >= 0; size2--) {
            d dVar = this.f2802e.get(size2);
            dVar.b();
            if (dVar.e().isEmpty()) {
                this.f2802e.remove(size2);
            }
        }
    }

    public final a g() {
        return this.f2804g;
    }

    public final void h(d dVar) {
        k.d(dVar, "taskQueue");
        if (!e1.b.f2642h || Thread.holdsLock(this)) {
            if (dVar.c() == null) {
                if (!dVar.e().isEmpty()) {
                    e1.b.a(this.f2802e, dVar);
                } else {
                    this.f2802e.remove(dVar);
                }
            }
            if (this.f2799b) {
                this.f2804g.c(this);
            } else {
                this.f2804g.execute(this.f2803f);
            }
        } else {
            StringBuilder sb = new StringBuilder();
            sb.append("Thread ");
            Thread currentThread = Thread.currentThread();
            k.c(currentThread, "Thread.currentThread()");
            sb.append(currentThread.getName());
            sb.append(" MUST hold lock on ");
            sb.append(this);
            throw new AssertionError(sb.toString());
        }
    }

    public final d i() {
        int i2;
        synchronized (this) {
            i2 = this.f2798a;
            this.f2798a = i2 + 1;
        }
        StringBuilder sb = new StringBuilder();
        sb.append('Q');
        sb.append(i2);
        return new d(this, sb.toString());
    }
}
