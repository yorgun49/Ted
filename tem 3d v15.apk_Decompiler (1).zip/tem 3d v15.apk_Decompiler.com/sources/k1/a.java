package k1;

import d1.v;
import w0.g;
import w0.k;

public final class a {

    /* renamed from: c  reason: collision with root package name */
    public static final C0043a f3123c = new C0043a((g) null);

    /* renamed from: a  reason: collision with root package name */
    private long f3124a = ((long) 262144);

    /* renamed from: b  reason: collision with root package name */
    private final q1.g f3125b;

    /* renamed from: k1.a$a  reason: collision with other inner class name */
    public static final class C0043a {
        private C0043a() {
        }

        public /* synthetic */ C0043a(g gVar) {
            this();
        }
    }

    public a(q1.g gVar) {
        k.d(gVar, "source");
        this.f3125b = gVar;
    }

    public final v a() {
        v.a aVar = new v.a();
        while (true) {
            String b2 = b();
            if (b2.length() == 0) {
                return aVar.d();
            }
            aVar.b(b2);
        }
    }

    public final String b() {
        String k2 = this.f3125b.k(this.f3124a);
        this.f3124a -= (long) k2.length();
        return k2;
    }
}
