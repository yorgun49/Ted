package k1;

import d1.d0;
import d1.p;
import d1.v;
import d1.w;
import d1.z;
import j1.i;
import java.io.EOFException;
import java.io.IOException;
import java.net.ProtocolException;
import java.net.Proxy;
import java.util.concurrent.TimeUnit;
import q1.a0;
import q1.b0;
import q1.k;
import q1.y;

public final class b implements j1.d {

    /* renamed from: h  reason: collision with root package name */
    public static final d f3126h = new d((w0.g) null);
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public int f3127a;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public final a f3128b;
    /* access modifiers changed from: private */

    /* renamed from: c  reason: collision with root package name */
    public v f3129c;
    /* access modifiers changed from: private */

    /* renamed from: d  reason: collision with root package name */
    public final z f3130d;

    /* renamed from: e  reason: collision with root package name */
    private final i1.f f3131e;
    /* access modifiers changed from: private */

    /* renamed from: f  reason: collision with root package name */
    public final q1.g f3132f;
    /* access modifiers changed from: private */

    /* renamed from: g  reason: collision with root package name */
    public final q1.f f3133g;

    private abstract class a implements a0 {

        /* renamed from: b  reason: collision with root package name */
        private final k f3134b;

        /* renamed from: c  reason: collision with root package name */
        private boolean f3135c;

        public a() {
            this.f3134b = new k(b.this.f3132f.b());
        }

        public final void A() {
            if (b.this.f3127a != 6) {
                if (b.this.f3127a == 5) {
                    b.this.r(this.f3134b);
                    b.this.f3127a = 6;
                    return;
                }
                throw new IllegalStateException("state: " + b.this.f3127a);
            }
        }

        /* access modifiers changed from: protected */
        public final void B(boolean z2) {
            this.f3135c = z2;
        }

        public b0 b() {
            return this.f3134b;
        }

        /* access modifiers changed from: protected */
        public final boolean o() {
            return this.f3135c;
        }

        public long x(q1.e eVar, long j2) {
            w0.k.d(eVar, "sink");
            try {
                return b.this.f3132f.x(eVar, j2);
            } catch (IOException e2) {
                b.this.g().y();
                A();
                throw e2;
            }
        }
    }

    /* renamed from: k1.b$b  reason: collision with other inner class name */
    private final class C0044b implements y {

        /* renamed from: b  reason: collision with root package name */
        private final k f3137b;

        /* renamed from: c  reason: collision with root package name */
        private boolean f3138c;

        public C0044b() {
            this.f3137b = new k(b.this.f3133g.b());
        }

        public b0 b() {
            return this.f3137b;
        }

        public synchronized void close() {
            if (!this.f3138c) {
                this.f3138c = true;
                b.this.f3133g.j("0\r\n\r\n");
                b.this.r(this.f3137b);
                b.this.f3127a = 3;
            }
        }

        public synchronized void flush() {
            if (!this.f3138c) {
                b.this.f3133g.flush();
            }
        }

        public void v(q1.e eVar, long j2) {
            w0.k.d(eVar, "source");
            if (!(!this.f3138c)) {
                throw new IllegalStateException("closed".toString());
            } else if (j2 != 0) {
                b.this.f3133g.g(j2);
                b.this.f3133g.j("\r\n");
                b.this.f3133g.v(eVar, j2);
                b.this.f3133g.j("\r\n");
            }
        }
    }

    private final class c extends a {

        /* renamed from: e  reason: collision with root package name */
        private long f3140e = -1;

        /* renamed from: f  reason: collision with root package name */
        private boolean f3141f = true;

        /* renamed from: g  reason: collision with root package name */
        private final w f3142g;

        /* renamed from: h  reason: collision with root package name */
        final /* synthetic */ b f3143h;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public c(b bVar, w wVar) {
            super();
            w0.k.d(wVar, "url");
            this.f3143h = bVar;
            this.f3142g = wVar;
        }

        private final void C() {
            if (this.f3140e != -1) {
                this.f3143h.f3132f.f();
            }
            try {
                this.f3140e = this.f3143h.f3132f.t();
                String f2 = this.f3143h.f3132f.f();
                if (f2 != null) {
                    String obj = q.o0(f2).toString();
                    if (this.f3140e >= 0) {
                        if (!(obj.length() > 0) || p.v(obj, ";", false, 2, (Object) null)) {
                            if (this.f3140e == 0) {
                                this.f3141f = false;
                                b bVar = this.f3143h;
                                bVar.f3129c = bVar.f3128b.a();
                                z j2 = this.f3143h.f3130d;
                                w0.k.b(j2);
                                p j3 = j2.j();
                                w wVar = this.f3142g;
                                v o2 = this.f3143h.f3129c;
                                w0.k.b(o2);
                                j1.e.f(j3, wVar, o2);
                                A();
                                return;
                            }
                            return;
                        }
                    }
                    throw new ProtocolException("expected chunk size and optional extensions" + " but was \"" + this.f3140e + obj + '\"');
                }
                throw new NullPointerException("null cannot be cast to non-null type kotlin.CharSequence");
            } catch (NumberFormatException e2) {
                throw new ProtocolException(e2.getMessage());
            }
        }

        public void close() {
            if (!o()) {
                if (this.f3141f && !e1.b.o(this, 100, TimeUnit.MILLISECONDS)) {
                    this.f3143h.g().y();
                    A();
                }
                B(true);
            }
        }

        public long x(q1.e eVar, long j2) {
            w0.k.d(eVar, "sink");
            if (!(j2 >= 0)) {
                throw new IllegalArgumentException(("byteCount < 0: " + j2).toString());
            } else if (!(true ^ o())) {
                throw new IllegalStateException("closed".toString());
            } else if (!this.f3141f) {
                return -1;
            } else {
                long j3 = this.f3140e;
                if (j3 == 0 || j3 == -1) {
                    C();
                    if (!this.f3141f) {
                        return -1;
                    }
                }
                long x2 = super.x(eVar, Math.min(j2, this.f3140e));
                if (x2 != -1) {
                    this.f3140e -= x2;
                    return x2;
                }
                this.f3143h.g().y();
                ProtocolException protocolException = new ProtocolException("unexpected end of stream");
                A();
                throw protocolException;
            }
        }
    }

    public static final class d {
        private d() {
        }

        public /* synthetic */ d(w0.g gVar) {
            this();
        }
    }

    private final class e extends a {

        /* renamed from: e  reason: collision with root package name */
        private long f3144e;

        public e(long j2) {
            super();
            this.f3144e = j2;
            if (j2 == 0) {
                A();
            }
        }

        public void close() {
            if (!o()) {
                if (this.f3144e != 0 && !e1.b.o(this, 100, TimeUnit.MILLISECONDS)) {
                    b.this.g().y();
                    A();
                }
                B(true);
            }
        }

        public long x(q1.e eVar, long j2) {
            w0.k.d(eVar, "sink");
            if (!(j2 >= 0)) {
                throw new IllegalArgumentException(("byteCount < 0: " + j2).toString());
            } else if (true ^ o()) {
                long j3 = this.f3144e;
                if (j3 == 0) {
                    return -1;
                }
                long x2 = super.x(eVar, Math.min(j3, j2));
                if (x2 != -1) {
                    long j4 = this.f3144e - x2;
                    this.f3144e = j4;
                    if (j4 == 0) {
                        A();
                    }
                    return x2;
                }
                b.this.g().y();
                ProtocolException protocolException = new ProtocolException("unexpected end of stream");
                A();
                throw protocolException;
            } else {
                throw new IllegalStateException("closed".toString());
            }
        }
    }

    private final class f implements y {

        /* renamed from: b  reason: collision with root package name */
        private final k f3146b;

        /* renamed from: c  reason: collision with root package name */
        private boolean f3147c;

        public f() {
            this.f3146b = new k(b.this.f3133g.b());
        }

        public b0 b() {
            return this.f3146b;
        }

        public void close() {
            if (!this.f3147c) {
                this.f3147c = true;
                b.this.r(this.f3146b);
                b.this.f3127a = 3;
            }
        }

        public void flush() {
            if (!this.f3147c) {
                b.this.f3133g.flush();
            }
        }

        public void v(q1.e eVar, long j2) {
            w0.k.d(eVar, "source");
            if (!this.f3147c) {
                e1.b.h(eVar.T(), 0, j2);
                b.this.f3133g.v(eVar, j2);
                return;
            }
            throw new IllegalStateException("closed".toString());
        }
    }

    private final class g extends a {

        /* renamed from: e  reason: collision with root package name */
        private boolean f3149e;

        public g() {
            super();
        }

        public void close() {
            if (!o()) {
                if (!this.f3149e) {
                    A();
                }
                B(true);
            }
        }

        public long x(q1.e eVar, long j2) {
            w0.k.d(eVar, "sink");
            if (!(j2 >= 0)) {
                throw new IllegalArgumentException(("byteCount < 0: " + j2).toString());
            } else if (!(!o())) {
                throw new IllegalStateException("closed".toString());
            } else if (this.f3149e) {
                return -1;
            } else {
                long x2 = super.x(eVar, j2);
                if (x2 != -1) {
                    return x2;
                }
                this.f3149e = true;
                A();
                return -1;
            }
        }
    }

    public b(z zVar, i1.f fVar, q1.g gVar, q1.f fVar2) {
        w0.k.d(fVar, "connection");
        w0.k.d(gVar, "source");
        w0.k.d(fVar2, "sink");
        this.f3130d = zVar;
        this.f3131e = fVar;
        this.f3132f = gVar;
        this.f3133g = fVar2;
        this.f3128b = new a(gVar);
    }

    /* access modifiers changed from: private */
    public final void r(k kVar) {
        b0 i2 = kVar.i();
        kVar.j(b0.f3936d);
        i2.a();
        i2.b();
    }

    private final boolean s(d1.b0 b0Var) {
        return p.j("chunked", b0Var.d("Transfer-Encoding"), true);
    }

    private final boolean t(d0 d0Var) {
        return p.j("chunked", d0.H(d0Var, "Transfer-Encoding", (String) null, 2, (Object) null), true);
    }

    private final y u() {
        boolean z2 = true;
        if (this.f3127a != 1) {
            z2 = false;
        }
        if (z2) {
            this.f3127a = 2;
            return new C0044b();
        }
        throw new IllegalStateException(("state: " + this.f3127a).toString());
    }

    private final a0 v(w wVar) {
        if (this.f3127a == 4) {
            this.f3127a = 5;
            return new c(this, wVar);
        }
        throw new IllegalStateException(("state: " + this.f3127a).toString());
    }

    private final a0 w(long j2) {
        if (this.f3127a == 4) {
            this.f3127a = 5;
            return new e(j2);
        }
        throw new IllegalStateException(("state: " + this.f3127a).toString());
    }

    private final y x() {
        boolean z2 = true;
        if (this.f3127a != 1) {
            z2 = false;
        }
        if (z2) {
            this.f3127a = 2;
            return new f();
        }
        throw new IllegalStateException(("state: " + this.f3127a).toString());
    }

    private final a0 y() {
        if (this.f3127a == 4) {
            this.f3127a = 5;
            g().y();
            return new g();
        }
        throw new IllegalStateException(("state: " + this.f3127a).toString());
    }

    public final void A(v vVar, String str) {
        w0.k.d(vVar, "headers");
        w0.k.d(str, "requestLine");
        if (this.f3127a == 0) {
            this.f3133g.j(str).j("\r\n");
            int size = vVar.size();
            for (int i2 = 0; i2 < size; i2++) {
                this.f3133g.j(vVar.b(i2)).j(": ").j(vVar.d(i2)).j("\r\n");
            }
            this.f3133g.j("\r\n");
            this.f3127a = 1;
            return;
        }
        throw new IllegalStateException(("state: " + this.f3127a).toString());
    }

    public y a(d1.b0 b0Var, long j2) {
        w0.k.d(b0Var, "request");
        if (b0Var.a() != null && b0Var.a().c()) {
            throw new ProtocolException("Duplex connections are not supported for HTTP/1");
        } else if (s(b0Var)) {
            return u();
        } else {
            if (j2 != -1) {
                return x();
            }
            throw new IllegalStateException("Cannot stream a request body without chunked encoding or a known content length!");
        }
    }

    public void b() {
        this.f3133g.flush();
    }

    public void c() {
        this.f3133g.flush();
    }

    public void cancel() {
        g().d();
    }

    public d0.a d(boolean z2) {
        int i2 = this.f3127a;
        boolean z3 = true;
        if (!(i2 == 1 || i2 == 3)) {
            z3 = false;
        }
        if (z3) {
            try {
                j1.k a2 = j1.k.f3027d.a(this.f3128b.b());
                d0.a k2 = new d0.a().p(a2.f3028a).g(a2.f3029b).m(a2.f3030c).k(this.f3128b.a());
                if (z2 && a2.f3029b == 100) {
                    return null;
                }
                if (a2.f3029b == 100) {
                    this.f3127a = 3;
                    return k2;
                }
                this.f3127a = 4;
                return k2;
            } catch (EOFException e2) {
                String n2 = g().z().a().l().n();
                throw new IOException("unexpected end of stream on " + n2, e2);
            }
        } else {
            throw new IllegalStateException(("state: " + this.f3127a).toString());
        }
    }

    public long e(d0 d0Var) {
        w0.k.d(d0Var, "response");
        if (!j1.e.b(d0Var)) {
            return 0;
        }
        if (t(d0Var)) {
            return -1;
        }
        return e1.b.r(d0Var);
    }

    public void f(d1.b0 b0Var) {
        w0.k.d(b0Var, "request");
        i iVar = i.f3024a;
        Proxy.Type type = g().z().b().type();
        w0.k.c(type, "connection.route().proxy.type()");
        A(b0Var.e(), iVar.a(b0Var, type));
    }

    public i1.f g() {
        return this.f3131e;
    }

    public a0 h(d0 d0Var) {
        long r2;
        w0.k.d(d0Var, "response");
        if (!j1.e.b(d0Var)) {
            r2 = 0;
        } else if (t(d0Var)) {
            return v(d0Var.P().i());
        } else {
            r2 = e1.b.r(d0Var);
            if (r2 == -1) {
                return y();
            }
        }
        return w(r2);
    }

    public final void z(d0 d0Var) {
        w0.k.d(d0Var, "response");
        long r2 = e1.b.r(d0Var);
        if (r2 != -1) {
            a0 w2 = w(r2);
            e1.b.H(w2, Integer.MAX_VALUE, TimeUnit.MILLISECONDS);
            w2.close();
        }
    }
}
