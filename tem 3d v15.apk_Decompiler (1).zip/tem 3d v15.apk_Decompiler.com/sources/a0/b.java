package a0;

import android.content.Context;
import android.os.Build;
import com.te.tem3d.R;
import w0.k;

public final class b {

    /* renamed from: a  reason: collision with root package name */
    public static final b f13a = new b();

    /* renamed from: b  reason: collision with root package name */
    private static String f14b = "";

    /* renamed from: c  reason: collision with root package name */
    private static String f15c = "";

    /* renamed from: d  reason: collision with root package name */
    private static String f16d = "";

    /* renamed from: e  reason: collision with root package name */
    private static String f17e = "";

    /* renamed from: f  reason: collision with root package name */
    private static String f18f = "";

    private b() {
    }

    public final String a() {
        return f18f;
    }

    public final String b() {
        return f17e;
    }

    public final String c() {
        return f14b;
    }

    public final String d() {
        return f16d;
    }

    public final String e() {
        return f15c;
    }

    public final void f(Context context) {
        k.d(context, "context");
        String a2 = z.k.f4432a.a(context);
        k.b(a2);
        f15c = a2;
        String str = Build.MODEL;
        k.c(str, "MODEL");
        f17e = str;
        String string = context.getString(R.string.app_name);
        k.c(string, "context.getString(\n     …string.app_name\n        )");
        f14b = string;
        String string2 = context.getSharedPreferences("prefs", 0).getString("activationRequestID", "");
        k.b(string2);
        f18f = string2;
    }

    public final void g(String str) {
        k.d(str, "<set-?>");
        f16d = str;
    }

    public final void h(String str) {
        k.d(str, "<set-?>");
        f15c = str;
    }

    public final void i(Context context, String str) {
        k.d(context, "context");
        k.d(str, "id");
        context.getSharedPreferences("prefs", 0).edit().putString("activationRequestID", str).apply();
        f18f = str;
    }
}
