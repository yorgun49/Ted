package a0;

import d1.b0;
import d1.c0;
import d1.d0;
import d1.e;
import d1.e0;
import d1.f;
import d1.y;
import d1.z;
import java.io.IOException;
import w0.g;
import w0.k;
import w0.p;

public final class a {

    /* renamed from: b  reason: collision with root package name */
    public static final C0001a f8b = new C0001a((g) null);

    /* renamed from: a  reason: collision with root package name */
    private final y f9a;

    /* renamed from: a0.a$a  reason: collision with other inner class name */
    public static final class C0001a {
        private C0001a() {
        }

        public /* synthetic */ C0001a(g gVar) {
            this();
        }
    }

    public static final class b implements f {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ c f10a;

        /* renamed from: b  reason: collision with root package name */
        final /* synthetic */ p<String> f11b;

        b(c cVar, p<String> pVar) {
            this.f10a = cVar;
            this.f11b = pVar;
        }

        public void a(e eVar, d0 d0Var) {
            k.d(eVar, "call");
            k.d(d0Var, "response");
            p<String> pVar = this.f11b;
            e0 o2 = d0Var.o();
            k.b(o2);
            pVar.f4284b = q.o0(o2.D()).toString();
            if (q.A((CharSequence) this.f11b.f4284b, "activationTicket", false, 2, (Object) null)) {
                T t2 = this.f11b.f4284b;
                this.f10a.a(q.b0(q.o0(((String) t2).subSequence(q.P((CharSequence) t2, ':', 0, false, 6, (Object) null) + 1, q.P((CharSequence) this.f11b.f4284b, '}', 0, false, 6, (Object) null))), "\"").toString());
                return;
            }
            this.f10a.b();
        }

        public void b(e eVar, IOException iOException) {
            k.d(eVar, "call");
            k.d(iOException, "e");
            this.f10a.b();
        }
    }

    public interface c {
        void a(String str);

        void b();
    }

    public static final class d implements f {

        /* renamed from: a  reason: collision with root package name */
        final /* synthetic */ c f12a;

        d(c cVar) {
            this.f12a = cVar;
        }

        public void a(e eVar, d0 d0Var) {
            k.d(eVar, "call");
            k.d(d0Var, "response");
            e0 o2 = d0Var.o();
            k.b(o2);
            String obj = q.o0(o2.D()).toString();
            System.out.println(obj);
            if (q.A(obj, "activationTicket", false, 2, (Object) null)) {
                String str = obj;
                this.f12a.a(q.b0(q.o0(obj.subSequence(q.P(str, ':', 0, false, 6, (Object) null) + 1, q.P(str, '}', 0, false, 6, (Object) null))), "\"").toString());
                return;
            }
            this.f12a.b();
        }

        public void b(e eVar, IOException iOException) {
            k.d(eVar, "call");
            k.d(iOException, "e");
            this.f12a.b();
        }
    }

    public a() {
        y a2 = y.f2482g.a("application/json; charset=utf-8");
        k.b(a2);
        this.f9a = a2;
    }

    public final void a(c cVar) {
        k.d(cVar, "onCallback");
        String e2 = i.e("\n     {\n        \"operationType\":\"CheckActivation\",\n        \"data\":{\n        \"activationRequestID\":\"" + b.f13a.a() + "\"\n        }\n     }\n        ", (String) null, 1, (Object) null);
        p pVar = new p();
        pVar.f4284b = "";
        new z().u(new b0.a().h("http://www.teknolojiekibi.com/actsystem/api/checkactivation.php").e(c0.f2251a.a(e2, this.f9a)).a()).o(new b(cVar, pVar));
    }

    public final void b(c cVar) {
        k.d(cVar, "onCallback");
        StringBuilder sb = new StringBuilder();
        sb.append("\n     {\n        \"operationType\":\"RequestActivation\",\n        \"data\":{\n        \"deviceName\":\"");
        b bVar = b.f13a;
        sb.append(bVar.b());
        sb.append("\",\n        \"groupName\":\"");
        sb.append(bVar.c());
        sb.append("\",\n        \"serialCode\":\"");
        sb.append(bVar.e());
        sb.append("\",\n        \"licenseCode\":\"");
        sb.append(bVar.d());
        sb.append("\"\n        }\n     }\n        ");
        String e2 = i.e(sb.toString(), (String) null, 1, (Object) null);
        System.out.println(e2);
        new z().u(new b0.a().h("http://www.teknolojiekibi.com/actsystem/api/createrequest.php").e(c0.f2251a.a(e2, this.f9a)).a()).o(new d(cVar));
    }
}
