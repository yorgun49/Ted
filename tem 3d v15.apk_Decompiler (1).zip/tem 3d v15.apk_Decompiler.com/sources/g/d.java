package g;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.Drawable;

class d extends Drawable implements Drawable.Callback, c, b {

    /* renamed from: h  reason: collision with root package name */
    static final PorterDuff.Mode f2690h = PorterDuff.Mode.SRC_IN;

    /* renamed from: b  reason: collision with root package name */
    private int f2691b;

    /* renamed from: c  reason: collision with root package name */
    private PorterDuff.Mode f2692c;

    /* renamed from: d  reason: collision with root package name */
    private boolean f2693d;

    /* renamed from: e  reason: collision with root package name */
    a f2694e;

    /* renamed from: f  reason: collision with root package name */
    private boolean f2695f;

    /* renamed from: g  reason: collision with root package name */
    Drawable f2696g;

    protected static abstract class a extends Drawable.ConstantState {

        /* renamed from: a  reason: collision with root package name */
        int f2697a;

        /* renamed from: b  reason: collision with root package name */
        Drawable.ConstantState f2698b;

        /* renamed from: c  reason: collision with root package name */
        ColorStateList f2699c = null;

        /* renamed from: d  reason: collision with root package name */
        PorterDuff.Mode f2700d = d.f2690h;

        a(a aVar, Resources resources) {
            if (aVar != null) {
                this.f2697a = aVar.f2697a;
                this.f2698b = aVar.f2698b;
                this.f2699c = aVar.f2699c;
                this.f2700d = aVar.f2700d;
            }
        }

        /* access modifiers changed from: package-private */
        public boolean a() {
            return this.f2698b != null;
        }

        public int getChangingConfigurations() {
            int i2 = this.f2697a;
            Drawable.ConstantState constantState = this.f2698b;
            return i2 | (constantState != null ? constantState.getChangingConfigurations() : 0);
        }

        public Drawable newDrawable() {
            return newDrawable((Resources) null);
        }

        public abstract Drawable newDrawable(Resources resources);
    }

    private static class b extends a {
        b(a aVar, Resources resources) {
            super(aVar, resources);
        }

        public Drawable newDrawable(Resources resources) {
            return new d(this, resources);
        }
    }

    d(Drawable drawable) {
        this.f2694e = d();
        b(drawable);
    }

    d(a aVar, Resources resources) {
        this.f2694e = aVar;
        e(resources);
    }

    private void e(Resources resources) {
        Drawable.ConstantState constantState;
        a aVar = this.f2694e;
        if (aVar != null && (constantState = aVar.f2698b) != null) {
            b(constantState.newDrawable(resources));
        }
    }

    private boolean f(int[] iArr) {
        if (!c()) {
            return false;
        }
        a aVar = this.f2694e;
        ColorStateList colorStateList = aVar.f2699c;
        PorterDuff.Mode mode = aVar.f2700d;
        if (colorStateList == null || mode == null) {
            this.f2693d = false;
            clearColorFilter();
        } else {
            int colorForState = colorStateList.getColorForState(iArr, colorStateList.getDefaultColor());
            if (!(this.f2693d && colorForState == this.f2691b && mode == this.f2692c)) {
                setColorFilter(colorForState, mode);
                this.f2691b = colorForState;
                this.f2692c = mode;
                this.f2693d = true;
                return true;
            }
        }
        return false;
    }

    public final Drawable a() {
        return this.f2696g;
    }

    public final void b(Drawable drawable) {
        Drawable drawable2 = this.f2696g;
        if (drawable2 != null) {
            drawable2.setCallback((Drawable.Callback) null);
        }
        this.f2696g = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            setVisible(drawable.isVisible(), true);
            setState(drawable.getState());
            setLevel(drawable.getLevel());
            setBounds(drawable.getBounds());
            a aVar = this.f2694e;
            if (aVar != null) {
                aVar.f2698b = drawable.getConstantState();
            }
        }
        invalidateSelf();
    }

    /* access modifiers changed from: protected */
    public boolean c() {
        return true;
    }

    /* access modifiers changed from: package-private */
    public a d() {
        return new b(this.f2694e, (Resources) null);
    }

    public void draw(Canvas canvas) {
        this.f2696g.draw(canvas);
    }

    public int getChangingConfigurations() {
        int changingConfigurations = super.getChangingConfigurations();
        a aVar = this.f2694e;
        return changingConfigurations | (aVar != null ? aVar.getChangingConfigurations() : 0) | this.f2696g.getChangingConfigurations();
    }

    public Drawable.ConstantState getConstantState() {
        a aVar = this.f2694e;
        if (aVar == null || !aVar.a()) {
            return null;
        }
        this.f2694e.f2697a = getChangingConfigurations();
        return this.f2694e;
    }

    public Drawable getCurrent() {
        return this.f2696g.getCurrent();
    }

    public int getIntrinsicHeight() {
        return this.f2696g.getIntrinsicHeight();
    }

    public int getIntrinsicWidth() {
        return this.f2696g.getIntrinsicWidth();
    }

    public int getMinimumHeight() {
        return this.f2696g.getMinimumHeight();
    }

    public int getMinimumWidth() {
        return this.f2696g.getMinimumWidth();
    }

    public int getOpacity() {
        return this.f2696g.getOpacity();
    }

    public boolean getPadding(Rect rect) {
        return this.f2696g.getPadding(rect);
    }

    public int[] getState() {
        return this.f2696g.getState();
    }

    public Region getTransparentRegion() {
        return this.f2696g.getTransparentRegion();
    }

    public void invalidateDrawable(Drawable drawable) {
        invalidateSelf();
    }

    public boolean isAutoMirrored() {
        return this.f2696g.isAutoMirrored();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0006, code lost:
        r0 = r1.f2694e;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean isStateful() {
        /*
            r1 = this;
            boolean r0 = r1.c()
            if (r0 == 0) goto L_0x000d
            g.d$a r0 = r1.f2694e
            if (r0 == 0) goto L_0x000d
            android.content.res.ColorStateList r0 = r0.f2699c
            goto L_0x000e
        L_0x000d:
            r0 = 0
        L_0x000e:
            if (r0 == 0) goto L_0x0016
            boolean r0 = r0.isStateful()
            if (r0 != 0) goto L_0x001e
        L_0x0016:
            android.graphics.drawable.Drawable r0 = r1.f2696g
            boolean r0 = r0.isStateful()
            if (r0 == 0) goto L_0x0020
        L_0x001e:
            r0 = 1
            goto L_0x0021
        L_0x0020:
            r0 = 0
        L_0x0021:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: g.d.isStateful():boolean");
    }

    public void jumpToCurrentState() {
        this.f2696g.jumpToCurrentState();
    }

    public Drawable mutate() {
        if (!this.f2695f && super.mutate() == this) {
            this.f2694e = d();
            Drawable drawable = this.f2696g;
            if (drawable != null) {
                drawable.mutate();
            }
            a aVar = this.f2694e;
            if (aVar != null) {
                Drawable drawable2 = this.f2696g;
                aVar.f2698b = drawable2 != null ? drawable2.getConstantState() : null;
            }
            this.f2695f = true;
        }
        return this;
    }

    /* access modifiers changed from: protected */
    public void onBoundsChange(Rect rect) {
        Drawable drawable = this.f2696g;
        if (drawable != null) {
            drawable.setBounds(rect);
        }
    }

    /* access modifiers changed from: protected */
    public boolean onLevelChange(int i2) {
        return this.f2696g.setLevel(i2);
    }

    public void scheduleDrawable(Drawable drawable, Runnable runnable, long j2) {
        scheduleSelf(runnable, j2);
    }

    public void setAlpha(int i2) {
        this.f2696g.setAlpha(i2);
    }

    public void setAutoMirrored(boolean z2) {
        this.f2696g.setAutoMirrored(z2);
    }

    public void setChangingConfigurations(int i2) {
        this.f2696g.setChangingConfigurations(i2);
    }

    public void setColorFilter(ColorFilter colorFilter) {
        this.f2696g.setColorFilter(colorFilter);
    }

    public void setDither(boolean z2) {
        this.f2696g.setDither(z2);
    }

    public void setFilterBitmap(boolean z2) {
        this.f2696g.setFilterBitmap(z2);
    }

    public boolean setState(int[] iArr) {
        return f(iArr) || this.f2696g.setState(iArr);
    }

    public void setTint(int i2) {
        setTintList(ColorStateList.valueOf(i2));
    }

    public void setTintList(ColorStateList colorStateList) {
        this.f2694e.f2699c = colorStateList;
        f(getState());
    }

    public void setTintMode(PorterDuff.Mode mode) {
        this.f2694e.f2700d = mode;
        f(getState());
    }

    public boolean setVisible(boolean z2, boolean z3) {
        return super.setVisible(z2, z3) || this.f2696g.setVisible(z2, z3);
    }

    public void unscheduleDrawable(Drawable drawable, Runnable runnable) {
        unscheduleSelf(runnable);
    }
}
