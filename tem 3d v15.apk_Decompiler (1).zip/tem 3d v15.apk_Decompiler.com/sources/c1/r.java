package c1;

class r extends q {
}
