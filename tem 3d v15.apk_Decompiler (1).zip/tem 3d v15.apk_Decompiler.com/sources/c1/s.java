package c1;

import w0.k;

class s extends r {
    public static String p0(String str, int i2) {
        k.d(str, "<this>");
        if (i2 >= 0) {
            String substring = str.substring(0, f.c(i2, str.length()));
            k.c(substring, "this as java.lang.String…ing(startIndex, endIndex)");
            return substring;
        }
        throw new IllegalArgumentException(("Requested character count " + i2 + " is less than zero.").toString());
    }
}
