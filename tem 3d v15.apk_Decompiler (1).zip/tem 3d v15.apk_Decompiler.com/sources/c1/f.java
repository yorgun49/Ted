package c1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import w0.g;
import w0.k;

public final class f implements Serializable {

    /* renamed from: c  reason: collision with root package name */
    public static final a f1704c = new a((g) null);

    /* renamed from: b  reason: collision with root package name */
    private final Pattern f1705b;

    public static final class a {
        private a() {
        }

        public /* synthetic */ a(g gVar) {
            this();
        }
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public f(java.lang.String r2) {
        /*
            r1 = this;
            java.lang.String r0 = "pattern"
            w0.k.d(r2, r0)
            java.util.regex.Pattern r2 = java.util.regex.Pattern.compile(r2)
            java.lang.String r0 = "compile(pattern)"
            w0.k.c(r2, r0)
            r1.<init>((java.util.regex.Pattern) r2)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: c1.f.<init>(java.lang.String):void");
    }

    public f(Pattern pattern) {
        k.d(pattern, "nativePattern");
        this.f1705b = pattern;
    }

    public final boolean a(CharSequence charSequence) {
        k.d(charSequence, "input");
        return this.f1705b.matcher(charSequence).matches();
    }

    public final String b(CharSequence charSequence, String str) {
        k.d(charSequence, "input");
        k.d(str, "replacement");
        String replaceAll = this.f1705b.matcher(charSequence).replaceAll(str);
        k.c(replaceAll, "nativePattern.matcher(in…).replaceAll(replacement)");
        return replaceAll;
    }

    public final List<String> c(CharSequence charSequence, int i2) {
        k.d(charSequence, "input");
        q.d0(i2);
        Matcher matcher = this.f1705b.matcher(charSequence);
        if (i2 == 1 || !matcher.find()) {
            return k.b(charSequence.toString());
        }
        int i3 = 10;
        if (i2 > 0) {
            i3 = f.c(i2, 10);
        }
        ArrayList arrayList = new ArrayList(i3);
        int i4 = 0;
        int i5 = i2 - 1;
        do {
            arrayList.add(charSequence.subSequence(i4, matcher.start()).toString());
            i4 = matcher.end();
            if ((i5 >= 0 && arrayList.size() == i5) || !matcher.find()) {
                arrayList.add(charSequence.subSequence(i4, charSequence.length()).toString());
            }
            arrayList.add(charSequence.subSequence(i4, matcher.start()).toString());
            i4 = matcher.end();
            break;
        } while (!matcher.find());
        arrayList.add(charSequence.subSequence(i4, charSequence.length()).toString());
        return arrayList;
    }

    public String toString() {
        String pattern = this.f1705b.toString();
        k.c(pattern, "nativePattern.toString()");
        return pattern;
    }
}
