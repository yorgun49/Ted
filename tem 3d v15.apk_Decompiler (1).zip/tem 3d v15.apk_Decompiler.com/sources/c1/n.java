package c1;

class n extends m {
}
