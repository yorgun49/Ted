package c1;

class h {
    /* JADX WARNING: type inference failed for: r3v0, types: [v0.l<? super T, ? extends java.lang.CharSequence>, v0.l] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static <T> void a(java.lang.Appendable r1, T r2, v0.l<? super T, ? extends java.lang.CharSequence> r3) {
        /*
            java.lang.String r0 = "<this>"
            w0.k.d(r1, r0)
            if (r3 == 0) goto L_0x0011
            java.lang.Object r2 = r3.b(r2)
        L_0x000b:
            java.lang.CharSequence r2 = (java.lang.CharSequence) r2
        L_0x000d:
            r1.append(r2)
            goto L_0x002d
        L_0x0011:
            if (r2 != 0) goto L_0x0015
            r3 = 1
            goto L_0x0017
        L_0x0015:
            boolean r3 = r2 instanceof java.lang.CharSequence
        L_0x0017:
            if (r3 == 0) goto L_0x001a
            goto L_0x000b
        L_0x001a:
            boolean r3 = r2 instanceof java.lang.Character
            if (r3 == 0) goto L_0x0028
            java.lang.Character r2 = (java.lang.Character) r2
            char r2 = r2.charValue()
            r1.append(r2)
            goto L_0x002d
        L_0x0028:
            java.lang.String r2 = java.lang.String.valueOf(r2)
            goto L_0x000d
        L_0x002d:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: c1.h.a(java.lang.Appendable, java.lang.Object, v0.l):void");
    }
}
