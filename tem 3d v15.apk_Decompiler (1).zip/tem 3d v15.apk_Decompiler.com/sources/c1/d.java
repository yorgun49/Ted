package c1;

import java.nio.charset.Charset;
import w0.k;

public final class d {

    /* renamed from: a  reason: collision with root package name */
    public static final d f1685a = new d();

    /* renamed from: b  reason: collision with root package name */
    public static final Charset f1686b;

    /* renamed from: c  reason: collision with root package name */
    public static final Charset f1687c;

    /* renamed from: d  reason: collision with root package name */
    public static final Charset f1688d;

    /* renamed from: e  reason: collision with root package name */
    public static final Charset f1689e;

    /* renamed from: f  reason: collision with root package name */
    public static final Charset f1690f;

    /* renamed from: g  reason: collision with root package name */
    public static final Charset f1691g;

    /* renamed from: h  reason: collision with root package name */
    private static Charset f1692h;

    /* renamed from: i  reason: collision with root package name */
    private static Charset f1693i;

    static {
        Charset forName = Charset.forName("UTF-8");
        k.c(forName, "forName(\"UTF-8\")");
        f1686b = forName;
        Charset forName2 = Charset.forName("UTF-16");
        k.c(forName2, "forName(\"UTF-16\")");
        f1687c = forName2;
        Charset forName3 = Charset.forName("UTF-16BE");
        k.c(forName3, "forName(\"UTF-16BE\")");
        f1688d = forName3;
        Charset forName4 = Charset.forName("UTF-16LE");
        k.c(forName4, "forName(\"UTF-16LE\")");
        f1689e = forName4;
        Charset forName5 = Charset.forName("US-ASCII");
        k.c(forName5, "forName(\"US-ASCII\")");
        f1690f = forName5;
        Charset forName6 = Charset.forName("ISO-8859-1");
        k.c(forName6, "forName(\"ISO-8859-1\")");
        f1691g = forName6;
    }

    private d() {
    }

    public final Charset a() {
        Charset charset = f1693i;
        if (charset != null) {
            return charset;
        }
        Charset forName = Charset.forName("UTF-32BE");
        k.c(forName, "forName(\"UTF-32BE\")");
        f1693i = forName;
        return forName;
    }

    public final Charset b() {
        Charset charset = f1692h;
        if (charset != null) {
            return charset;
        }
        Charset forName = Charset.forName("UTF-32LE");
        k.c(forName, "forName(\"UTF-32LE\")");
        f1692h = forName;
        return forName;
    }
}
