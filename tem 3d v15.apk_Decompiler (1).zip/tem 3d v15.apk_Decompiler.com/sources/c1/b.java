package c1;

import z0.c;

class b {
    public static int a(int i2) {
        boolean z2 = false;
        if (2 <= i2 && i2 < 37) {
            z2 = true;
        }
        if (z2) {
            return i2;
        }
        throw new IllegalArgumentException("radix " + i2 + " was not in valid range " + new c(2, 36));
    }

    public static final int b(char c2, int i2) {
        return Character.digit(c2, i2);
    }

    public static final boolean c(char c2) {
        return Character.isWhitespace(c2) || Character.isSpaceChar(c2);
    }
}
