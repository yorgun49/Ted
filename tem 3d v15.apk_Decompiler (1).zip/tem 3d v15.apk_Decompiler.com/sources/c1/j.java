package c1;

class j extends i {
}
