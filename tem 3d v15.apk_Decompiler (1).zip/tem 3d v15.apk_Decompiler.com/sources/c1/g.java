package c1;

public final class g extends s {
}
