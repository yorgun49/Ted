package c1;

import java.util.ArrayList;
import java.util.List;
import w0.k;
import w0.l;

class i extends h {

    static final class a extends l implements v0.l<String, String> {

        /* renamed from: c  reason: collision with root package name */
        public static final a f1706c = new a();

        a() {
            super(1);
        }

        /* renamed from: d */
        public final String b(String str) {
            k.d(str, "line");
            return str;
        }
    }

    static final class b extends l implements v0.l<String, String> {

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ String f1707c;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        b(String str) {
            super(1);
            this.f1707c = str;
        }

        /* renamed from: d */
        public final String b(String str) {
            k.d(str, "line");
            return this.f1707c + str;
        }
    }

    private static final v0.l<String, String> b(String str) {
        return str.length() == 0 ? a.f1706c : new b(str);
    }

    public static final String c(String str, String str2, String str3) {
        int i2;
        String b2;
        k.d(str, "<this>");
        k.d(str2, "newIndent");
        k.d(str3, "marginPrefix");
        if (!p.k(str3)) {
            List<String> T = q.T(str);
            int length = str.length() + (str2.length() * T.size());
            v0.l<String, String> b3 = b(str2);
            int h2 = l.h(T);
            ArrayList arrayList = new ArrayList();
            int i3 = 0;
            for (T next : T) {
                int i4 = i3 + 1;
                if (i3 < 0) {
                    l.n();
                }
                String str4 = (String) next;
                String str5 = null;
                if ((i3 == 0 || i3 == h2) && p.k(str4)) {
                    str4 = null;
                } else {
                    int length2 = str4.length();
                    int i5 = 0;
                    while (true) {
                        if (i5 >= length2) {
                            i2 = -1;
                            break;
                        } else if (!b.c(str4.charAt(i5))) {
                            i2 = i5;
                            break;
                        } else {
                            i5++;
                        }
                    }
                    if (i2 != -1) {
                        int i6 = i2;
                        if (p.u(str4, str3, i2, false, 4, (Object) null)) {
                            str5 = str4.substring(i6 + str3.length());
                            k.c(str5, "this as java.lang.String).substring(startIndex)");
                        }
                    }
                    if (!(str5 == null || (b2 = b3.b(str5)) == null)) {
                        str4 = b2;
                    }
                }
                if (str4 != null) {
                    arrayList.add(str4);
                }
                i3 = i4;
            }
            String sb = ((StringBuilder) t.A(arrayList, new StringBuilder(length), "\n", (CharSequence) null, (CharSequence) null, 0, (CharSequence) null, (v0.l) null, 124, (Object) null)).toString();
            k.c(sb, "mapIndexedNotNull { inde…\"\\n\")\n        .toString()");
            return sb;
        }
        throw new IllegalArgumentException("marginPrefix must be non-blank string.".toString());
    }

    public static final String d(String str, String str2) {
        k.d(str, "<this>");
        k.d(str2, "marginPrefix");
        return c(str, "", str2);
    }

    public static /* synthetic */ String e(String str, String str2, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            str2 = "|";
        }
        return d(str, str2);
    }
}
