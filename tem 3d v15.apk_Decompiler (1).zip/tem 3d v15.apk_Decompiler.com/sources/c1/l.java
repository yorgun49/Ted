package c1;

class l extends k {
}
