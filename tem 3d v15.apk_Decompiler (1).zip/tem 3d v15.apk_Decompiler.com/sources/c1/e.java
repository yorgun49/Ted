package c1;

import b1.d;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Objects;
import o0.h;
import v0.p;
import w0.k;
import z0.c;

final class e implements d<c> {
    /* access modifiers changed from: private */

    /* renamed from: a  reason: collision with root package name */
    public final CharSequence f1694a;
    /* access modifiers changed from: private */

    /* renamed from: b  reason: collision with root package name */
    public final int f1695b;
    /* access modifiers changed from: private */

    /* renamed from: c  reason: collision with root package name */
    public final int f1696c;
    /* access modifiers changed from: private */

    /* renamed from: d  reason: collision with root package name */
    public final p<CharSequence, Integer, h<Integer, Integer>> f1697d;

    public static final class a implements Iterator<c>, x0.a {

        /* renamed from: b  reason: collision with root package name */
        private int f1698b = -1;

        /* renamed from: c  reason: collision with root package name */
        private int f1699c;

        /* renamed from: d  reason: collision with root package name */
        private int f1700d;

        /* renamed from: e  reason: collision with root package name */
        private c f1701e;

        /* renamed from: f  reason: collision with root package name */
        private int f1702f;

        /* renamed from: g  reason: collision with root package name */
        final /* synthetic */ e f1703g;

        a(e eVar) {
            this.f1703g = eVar;
            int d2 = f.d(eVar.f1695b, 0, eVar.f1694a.length());
            this.f1699c = d2;
            this.f1700d = d2;
        }

        /* JADX WARNING: Code restructure failed: missing block: B:6:0x0021, code lost:
            if (r0 < c1.e.d(r6.f1703g)) goto L_0x0023;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        private final void a() {
            /*
                r6 = this;
                int r0 = r6.f1700d
                r1 = 0
                if (r0 >= 0) goto L_0x000c
                r6.f1698b = r1
                r0 = 0
                r6.f1701e = r0
                goto L_0x0099
            L_0x000c:
                c1.e r0 = r6.f1703g
                int r0 = r0.f1696c
                r2 = -1
                r3 = 1
                if (r0 <= 0) goto L_0x0023
                int r0 = r6.f1702f
                int r0 = r0 + r3
                r6.f1702f = r0
                c1.e r4 = r6.f1703g
                int r4 = r4.f1696c
                if (r0 >= r4) goto L_0x0031
            L_0x0023:
                int r0 = r6.f1700d
                c1.e r4 = r6.f1703g
                java.lang.CharSequence r4 = r4.f1694a
                int r4 = r4.length()
                if (r0 <= r4) goto L_0x0047
            L_0x0031:
                z0.c r0 = new z0.c
                int r1 = r6.f1699c
                c1.e r4 = r6.f1703g
                java.lang.CharSequence r4 = r4.f1694a
                int r4 = c1.q.F(r4)
                r0.<init>(r1, r4)
            L_0x0042:
                r6.f1701e = r0
            L_0x0044:
                r6.f1700d = r2
                goto L_0x0097
            L_0x0047:
                c1.e r0 = r6.f1703g
                v0.p r0 = r0.f1697d
                c1.e r4 = r6.f1703g
                java.lang.CharSequence r4 = r4.f1694a
                int r5 = r6.f1700d
                java.lang.Integer r5 = java.lang.Integer.valueOf(r5)
                java.lang.Object r0 = r0.a(r4, r5)
                o0.h r0 = (o0.h) r0
                if (r0 != 0) goto L_0x0073
                z0.c r0 = new z0.c
                int r1 = r6.f1699c
                c1.e r4 = r6.f1703g
                java.lang.CharSequence r4 = r4.f1694a
                int r4 = c1.q.F(r4)
                r0.<init>(r1, r4)
                goto L_0x0042
            L_0x0073:
                java.lang.Object r2 = r0.a()
                java.lang.Number r2 = (java.lang.Number) r2
                int r2 = r2.intValue()
                java.lang.Object r0 = r0.b()
                java.lang.Number r0 = (java.lang.Number) r0
                int r0 = r0.intValue()
                int r4 = r6.f1699c
                z0.c r4 = z0.f.g(r4, r2)
                r6.f1701e = r4
                int r2 = r2 + r0
                r6.f1699c = r2
                if (r0 != 0) goto L_0x0095
                r1 = 1
            L_0x0095:
                int r2 = r2 + r1
                goto L_0x0044
            L_0x0097:
                r6.f1698b = r3
            L_0x0099:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: c1.e.a.a():void");
        }

        /* renamed from: b */
        public c next() {
            if (this.f1698b == -1) {
                a();
            }
            if (this.f1698b != 0) {
                c cVar = this.f1701e;
                Objects.requireNonNull(cVar, "null cannot be cast to non-null type kotlin.ranges.IntRange");
                this.f1701e = null;
                this.f1698b = -1;
                return cVar;
            }
            throw new NoSuchElementException();
        }

        public boolean hasNext() {
            if (this.f1698b == -1) {
                a();
            }
            return this.f1698b == 1;
        }

        public void remove() {
            throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }
    }

    public e(CharSequence charSequence, int i2, int i3, p<? super CharSequence, ? super Integer, h<Integer, Integer>> pVar) {
        k.d(charSequence, "input");
        k.d(pVar, "getNextMatch");
        this.f1694a = charSequence;
        this.f1695b = i2;
        this.f1696c = i3;
        this.f1697d = pVar;
    }

    public Iterator<c> iterator() {
        return new a(this);
    }
}
