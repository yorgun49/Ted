package c1;

class m extends l {
}
