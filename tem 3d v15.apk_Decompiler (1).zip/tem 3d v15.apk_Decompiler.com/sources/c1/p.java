package c1;

import w0.k;

class p extends o {
    public static final boolean h(String str, String str2, boolean z2) {
        k.d(str, "<this>");
        k.d(str2, "suffix");
        if (!z2) {
            return str.endsWith(str2);
        }
        return l(str, str.length() - str2.length(), str2, 0, str2.length(), true);
    }

    public static /* synthetic */ boolean i(String str, String str2, boolean z2, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            z2 = false;
        }
        return h(str, str2, z2);
    }

    public static boolean j(String str, String str2, boolean z2) {
        return str == null ? str2 == null : !z2 ? str.equals(str2) : str.equalsIgnoreCase(str2);
    }

    /* JADX WARNING: Removed duplicated region for block: B:17:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final boolean k(java.lang.CharSequence r4) {
        /*
            java.lang.String r0 = "<this>"
            w0.k.d(r4, r0)
            int r0 = r4.length()
            r1 = 0
            r2 = 1
            if (r0 == 0) goto L_0x003e
            z0.c r0 = c1.q.E(r4)
            boolean r3 = r0 instanceof java.util.Collection
            if (r3 == 0) goto L_0x0020
            r3 = r0
            java.util.Collection r3 = (java.util.Collection) r3
            boolean r3 = r3.isEmpty()
            if (r3 == 0) goto L_0x0020
        L_0x001e:
            r4 = 1
            goto L_0x003c
        L_0x0020:
            java.util.Iterator r0 = r0.iterator()
        L_0x0024:
            boolean r3 = r0.hasNext()
            if (r3 == 0) goto L_0x001e
            r3 = r0
            p0.b0 r3 = (p0.b0) r3
            int r3 = r3.a()
            char r3 = r4.charAt(r3)
            boolean r3 = c1.b.c(r3)
            if (r3 != 0) goto L_0x0024
            r4 = 0
        L_0x003c:
            if (r4 == 0) goto L_0x003f
        L_0x003e:
            r1 = 1
        L_0x003f:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: c1.p.k(java.lang.CharSequence):boolean");
    }

    public static final boolean l(String str, int i2, String str2, int i3, int i4, boolean z2) {
        k.d(str, "<this>");
        k.d(str2, "other");
        return !z2 ? str.regionMatches(i2, str2, i3, i4) : str.regionMatches(z2, i2, str2, i3, i4);
    }

    public static /* synthetic */ boolean m(String str, int i2, String str2, int i3, int i4, boolean z2, int i5, Object obj) {
        return l(str, i2, str2, i3, i4, (i5 & 16) != 0 ? false : z2);
    }

    public static String n(CharSequence charSequence, int i2) {
        k.d(charSequence, "<this>");
        int i3 = 1;
        if (!(i2 >= 0)) {
            throw new IllegalArgumentException(("Count 'n' must be non-negative, but was " + i2 + '.').toString());
        } else if (i2 == 0) {
            return "";
        } else {
            if (i2 == 1) {
                return charSequence.toString();
            }
            int length = charSequence.length();
            if (length == 0) {
                return "";
            }
            if (length != 1) {
                StringBuilder sb = new StringBuilder(charSequence.length() * i2);
                if (1 <= i2) {
                    while (true) {
                        sb.append(charSequence);
                        if (i3 == i2) {
                            break;
                        }
                        i3++;
                    }
                }
                String sb2 = sb.toString();
                k.c(sb2, "{\n                    va…tring()\n                }");
                return sb2;
            }
            char charAt = charSequence.charAt(0);
            char[] cArr = new char[i2];
            for (int i4 = 0; i4 < i2; i4++) {
                cArr[i4] = charAt;
            }
            return new String(cArr);
        }
    }

    public static final String o(String str, char c2, char c3, boolean z2) {
        String sb;
        String str2;
        k.d(str, "<this>");
        if (!z2) {
            sb = str.replace(c2, c3);
            str2 = "this as java.lang.String…replace(oldChar, newChar)";
        } else {
            StringBuilder sb2 = new StringBuilder(str.length());
            for (int i2 = 0; i2 < str.length(); i2++) {
                char charAt = str.charAt(i2);
                if (c.d(charAt, c2, z2)) {
                    charAt = c3;
                }
                sb2.append(charAt);
            }
            sb = sb2.toString();
            str2 = "StringBuilder(capacity).…builderAction).toString()";
        }
        k.c(sb, str2);
        return sb;
    }

    public static final String p(String str, String str2, String str3, boolean z2) {
        k.d(str, "<this>");
        k.d(str2, "oldValue");
        k.d(str3, "newValue");
        int i2 = 0;
        int H = q.H(str, str2, 0, z2);
        if (H < 0) {
            return str;
        }
        int length = str2.length();
        int b2 = f.b(length, 1);
        int length2 = (str.length() - length) + str3.length();
        if (length2 >= 0) {
            StringBuilder sb = new StringBuilder(length2);
            do {
                sb.append(str, i2, H);
                sb.append(str3);
                i2 = H + length;
                if (H >= str.length() || (H = q.H(str, str2, H + b2, z2)) <= 0) {
                    sb.append(str, i2, str.length());
                    String sb2 = sb.toString();
                    k.c(sb2, "stringBuilder.append(this, i, length).toString()");
                }
                sb.append(str, i2, H);
                sb.append(str3);
                i2 = H + length;
                break;
            } while ((H = q.H(str, str2, H + b2, z2)) <= 0);
            sb.append(str, i2, str.length());
            String sb22 = sb.toString();
            k.c(sb22, "stringBuilder.append(this, i, length).toString()");
            return sb22;
        }
        throw new OutOfMemoryError();
    }

    public static /* synthetic */ String q(String str, char c2, char c3, boolean z2, int i2, Object obj) {
        if ((i2 & 4) != 0) {
            z2 = false;
        }
        return o(str, c2, c3, z2);
    }

    public static /* synthetic */ String r(String str, String str2, String str3, boolean z2, int i2, Object obj) {
        if ((i2 & 4) != 0) {
            z2 = false;
        }
        return p(str, str2, str3, z2);
    }

    public static boolean s(String str, String str2, int i2, boolean z2) {
        k.d(str, "<this>");
        k.d(str2, "prefix");
        if (!z2) {
            return str.startsWith(str2, i2);
        }
        return l(str, i2, str2, 0, str2.length(), z2);
    }

    public static boolean t(String str, String str2, boolean z2) {
        k.d(str, "<this>");
        k.d(str2, "prefix");
        if (!z2) {
            return str.startsWith(str2);
        }
        return l(str, 0, str2, 0, str2.length(), z2);
    }

    public static /* synthetic */ boolean u(String str, String str2, int i2, boolean z2, int i3, Object obj) {
        if ((i3 & 4) != 0) {
            z2 = false;
        }
        return s(str, str2, i2, z2);
    }

    public static /* synthetic */ boolean v(String str, String str2, boolean z2, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            z2 = false;
        }
        return t(str, str2, z2);
    }
}
