package c1;

class k extends j {
}
