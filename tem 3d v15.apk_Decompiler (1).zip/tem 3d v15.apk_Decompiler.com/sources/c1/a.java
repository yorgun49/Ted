package c1;

public final class a extends c {
}
