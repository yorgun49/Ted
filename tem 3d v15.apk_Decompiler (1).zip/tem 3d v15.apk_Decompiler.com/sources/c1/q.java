package c1;

import b1.d;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import o0.h;
import o0.j;
import v0.p;
import w0.k;
import w0.l;

class q extends p {

    static final class a extends l implements p<CharSequence, Integer, h<? extends Integer, ? extends Integer>> {

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ char[] f1708c;

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ boolean f1709d;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        a(char[] cArr, boolean z2) {
            super(2);
            this.f1708c = cArr;
            this.f1709d = z2;
        }

        public /* bridge */ /* synthetic */ Object a(Object obj, Object obj2) {
            return d((CharSequence) obj, ((Number) obj2).intValue());
        }

        public final h<Integer, Integer> d(CharSequence charSequence, int i2) {
            k.d(charSequence, "$this$$receiver");
            int M = q.M(charSequence, this.f1708c, i2, this.f1709d);
            if (M < 0) {
                return null;
            }
            return j.a(Integer.valueOf(M), 1);
        }
    }

    static final class b extends l implements p<CharSequence, Integer, h<? extends Integer, ? extends Integer>> {

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ List<String> f1710c;

        /* renamed from: d  reason: collision with root package name */
        final /* synthetic */ boolean f1711d;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        b(List<String> list, boolean z2) {
            super(2);
            this.f1710c = list;
            this.f1711d = z2;
        }

        public /* bridge */ /* synthetic */ Object a(Object obj, Object obj2) {
            return d((CharSequence) obj, ((Number) obj2).intValue());
        }

        public final h<Integer, Integer> d(CharSequence charSequence, int i2) {
            k.d(charSequence, "$this$$receiver");
            h w2 = q.D(charSequence, this.f1710c, i2, this.f1711d, false);
            if (w2 != null) {
                return j.a(w2.c(), Integer.valueOf(((String) w2.d()).length()));
            }
            return null;
        }
    }

    static final class c extends l implements v0.l<z0.c, String> {

        /* renamed from: c  reason: collision with root package name */
        final /* synthetic */ CharSequence f1712c;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        c(CharSequence charSequence) {
            super(1);
            this.f1712c = charSequence;
        }

        /* renamed from: d */
        public final String b(z0.c cVar) {
            k.d(cVar, "it");
            return q.l0(this.f1712c, cVar);
        }
    }

    public static /* synthetic */ boolean A(CharSequence charSequence, CharSequence charSequence2, boolean z2, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            z2 = false;
        }
        return y(charSequence, charSequence2, z2);
    }

    public static final boolean B(CharSequence charSequence, CharSequence charSequence2, boolean z2) {
        k.d(charSequence, "<this>");
        k.d(charSequence2, "suffix");
        if (!z2 && (charSequence instanceof String) && (charSequence2 instanceof String)) {
            return p.i((String) charSequence, (String) charSequence2, false, 2, (Object) null);
        }
        return Y(charSequence, charSequence.length() - charSequence2.length(), charSequence2, 0, charSequence2.length(), z2);
    }

    public static /* synthetic */ boolean C(CharSequence charSequence, CharSequence charSequence2, boolean z2, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            z2 = false;
        }
        return B(charSequence, charSequence2, z2);
    }

    /* access modifiers changed from: private */
    public static final h<Integer, String> D(CharSequence charSequence, Collection<String> collection, int i2, boolean z2, boolean z3) {
        int i3;
        T t2;
        String str;
        T t3;
        if (z2 || collection.size() != 1) {
            z0.a cVar = !z3 ? new z0.c(f.b(i2, 0), charSequence.length()) : f.e(f.c(i2, F(charSequence)), 0);
            if (charSequence instanceof String) {
                i3 = cVar.a();
                int b2 = cVar.b();
                int c2 = cVar.c();
                if ((c2 > 0 && i3 <= b2) || (c2 < 0 && b2 <= i3)) {
                    while (true) {
                        Iterator<T> it = collection.iterator();
                        while (true) {
                            if (!it.hasNext()) {
                                t3 = null;
                                break;
                            }
                            t3 = it.next();
                            String str2 = (String) t3;
                            if (p.l(str2, 0, (String) charSequence, i3, str2.length(), z2)) {
                                break;
                            }
                        }
                        str = (String) t3;
                        if (str == null) {
                            if (i3 == b2) {
                                break;
                            }
                            i3 += c2;
                        } else {
                            break;
                        }
                    }
                }
                return null;
            }
            int a2 = cVar.a();
            int b3 = cVar.b();
            int c3 = cVar.c();
            if ((c3 > 0 && a2 <= b3) || (c3 < 0 && b3 <= a2)) {
                while (true) {
                    Iterator<T> it2 = collection.iterator();
                    while (true) {
                        if (!it2.hasNext()) {
                            t2 = null;
                            break;
                        }
                        t2 = it2.next();
                        String str3 = (String) t2;
                        if (Y(str3, 0, charSequence, i3, str3.length(), z2)) {
                            break;
                        }
                    }
                    str = (String) t2;
                    if (str == null) {
                        if (i3 == b3) {
                            break;
                        }
                        a2 = i3 + c3;
                    } else {
                        break;
                    }
                }
            }
            return null;
            return j.a(Integer.valueOf(i3), str);
        }
        String str4 = (String) t.I(collection);
        CharSequence charSequence2 = charSequence;
        String str5 = str4;
        int i4 = i2;
        int L = !z3 ? L(charSequence2, str5, i4, false, 4, (Object) null) : Q(charSequence2, str5, i4, false, 4, (Object) null);
        if (L < 0) {
            return null;
        }
        return j.a(Integer.valueOf(L), str4);
    }

    public static final z0.c E(CharSequence charSequence) {
        k.d(charSequence, "<this>");
        return new z0.c(0, charSequence.length() - 1);
    }

    public static final int F(CharSequence charSequence) {
        k.d(charSequence, "<this>");
        return charSequence.length() - 1;
    }

    public static final int G(CharSequence charSequence, char c2, int i2, boolean z2) {
        k.d(charSequence, "<this>");
        if (!z2 && (charSequence instanceof String)) {
            return ((String) charSequence).indexOf(c2, i2);
        }
        return M(charSequence, new char[]{c2}, i2, z2);
    }

    public static final int H(CharSequence charSequence, String str, int i2, boolean z2) {
        k.d(charSequence, "<this>");
        k.d(str, "string");
        if (!z2 && (charSequence instanceof String)) {
            return ((String) charSequence).indexOf(str, i2);
        }
        return J(charSequence, str, i2, charSequence.length(), z2, false, 16, (Object) null);
    }

    private static final int I(CharSequence charSequence, CharSequence charSequence2, int i2, int i3, boolean z2, boolean z3) {
        z0.a cVar = !z3 ? new z0.c(f.b(i2, 0), f.c(i3, charSequence.length())) : f.e(f.c(i2, F(charSequence)), f.b(i3, 0));
        if (!(charSequence instanceof String) || !(charSequence2 instanceof String)) {
            int a2 = cVar.a();
            int b2 = cVar.b();
            int c2 = cVar.c();
            if ((c2 <= 0 || a2 > b2) && (c2 >= 0 || b2 > a2)) {
                return -1;
            }
            while (true) {
                if (Y(charSequence2, 0, charSequence, a2, charSequence2.length(), z2)) {
                    return a2;
                }
                if (a2 == b2) {
                    return -1;
                }
                a2 += c2;
            }
        } else {
            int a3 = cVar.a();
            int b3 = cVar.b();
            int c3 = cVar.c();
            if ((c3 <= 0 || a3 > b3) && (c3 >= 0 || b3 > a3)) {
                return -1;
            }
            while (true) {
                if (p.l((String) charSequence2, 0, (String) charSequence, a3, charSequence2.length(), z2)) {
                    return a3;
                }
                if (a3 == b3) {
                    return -1;
                }
                a3 += c3;
            }
        }
    }

    static /* synthetic */ int J(CharSequence charSequence, CharSequence charSequence2, int i2, int i3, boolean z2, boolean z3, int i4, Object obj) {
        return I(charSequence, charSequence2, i2, i3, z2, (i4 & 16) != 0 ? false : z3);
    }

    public static /* synthetic */ int K(CharSequence charSequence, char c2, int i2, boolean z2, int i3, Object obj) {
        if ((i3 & 2) != 0) {
            i2 = 0;
        }
        if ((i3 & 4) != 0) {
            z2 = false;
        }
        return G(charSequence, c2, i2, z2);
    }

    public static /* synthetic */ int L(CharSequence charSequence, String str, int i2, boolean z2, int i3, Object obj) {
        if ((i3 & 2) != 0) {
            i2 = 0;
        }
        if ((i3 & 4) != 0) {
            z2 = false;
        }
        return H(charSequence, str, i2, z2);
    }

    public static final int M(CharSequence charSequence, char[] cArr, int i2, boolean z2) {
        boolean z3;
        k.d(charSequence, "<this>");
        k.d(cArr, "chars");
        if (z2 || cArr.length != 1 || !(charSequence instanceof String)) {
            int b2 = f.b(i2, 0);
            int F = F(charSequence);
            if (b2 > F) {
                return -1;
            }
            while (true) {
                char charAt = charSequence.charAt(b2);
                int length = cArr.length;
                int i3 = 0;
                while (true) {
                    if (i3 >= length) {
                        z3 = false;
                        break;
                    } else if (c.d(cArr[i3], charAt, z2)) {
                        z3 = true;
                        break;
                    } else {
                        i3++;
                    }
                }
                if (z3) {
                    return b2;
                }
                if (b2 == F) {
                    return -1;
                }
                b2++;
            }
        } else {
            return ((String) charSequence).indexOf(h.r(cArr), i2);
        }
    }

    public static final int N(CharSequence charSequence, char c2, int i2, boolean z2) {
        k.d(charSequence, "<this>");
        if (!z2 && (charSequence instanceof String)) {
            return ((String) charSequence).lastIndexOf(c2, i2);
        }
        return R(charSequence, new char[]{c2}, i2, z2);
    }

    public static final int O(CharSequence charSequence, String str, int i2, boolean z2) {
        k.d(charSequence, "<this>");
        k.d(str, "string");
        return (z2 || !(charSequence instanceof String)) ? I(charSequence, str, i2, 0, z2, true) : ((String) charSequence).lastIndexOf(str, i2);
    }

    public static /* synthetic */ int P(CharSequence charSequence, char c2, int i2, boolean z2, int i3, Object obj) {
        if ((i3 & 2) != 0) {
            i2 = F(charSequence);
        }
        if ((i3 & 4) != 0) {
            z2 = false;
        }
        return N(charSequence, c2, i2, z2);
    }

    public static /* synthetic */ int Q(CharSequence charSequence, String str, int i2, boolean z2, int i3, Object obj) {
        if ((i3 & 2) != 0) {
            i2 = F(charSequence);
        }
        if ((i3 & 4) != 0) {
            z2 = false;
        }
        return O(charSequence, str, i2, z2);
    }

    public static final int R(CharSequence charSequence, char[] cArr, int i2, boolean z2) {
        k.d(charSequence, "<this>");
        k.d(cArr, "chars");
        if (z2 || cArr.length != 1 || !(charSequence instanceof String)) {
            for (int c2 = f.c(i2, F(charSequence)); -1 < c2; c2--) {
                char charAt = charSequence.charAt(c2);
                int length = cArr.length;
                boolean z3 = false;
                int i3 = 0;
                while (true) {
                    if (i3 >= length) {
                        break;
                    } else if (c.d(cArr[i3], charAt, z2)) {
                        z3 = true;
                        break;
                    } else {
                        i3++;
                    }
                }
                if (z3) {
                    return c2;
                }
            }
            return -1;
        }
        return ((String) charSequence).lastIndexOf(h.r(cArr), i2);
    }

    public static final d<String> S(CharSequence charSequence) {
        k.d(charSequence, "<this>");
        return i0(charSequence, new String[]{"\r\n", "\n", "\r"}, false, 0, 6, (Object) null);
    }

    public static final List<String> T(CharSequence charSequence) {
        k.d(charSequence, "<this>");
        return j.i(S(charSequence));
    }

    private static final d<z0.c> U(CharSequence charSequence, char[] cArr, int i2, boolean z2, int i3) {
        d0(i3);
        return new e(charSequence, i2, i3, new a(cArr, z2));
    }

    private static final d<z0.c> V(CharSequence charSequence, String[] strArr, int i2, boolean z2, int i3) {
        d0(i3);
        return new e(charSequence, i2, i3, new b(g.b(strArr), z2));
    }

    static /* synthetic */ d W(CharSequence charSequence, char[] cArr, int i2, boolean z2, int i3, int i4, Object obj) {
        if ((i4 & 2) != 0) {
            i2 = 0;
        }
        if ((i4 & 4) != 0) {
            z2 = false;
        }
        if ((i4 & 8) != 0) {
            i3 = 0;
        }
        return U(charSequence, cArr, i2, z2, i3);
    }

    static /* synthetic */ d X(CharSequence charSequence, String[] strArr, int i2, boolean z2, int i3, int i4, Object obj) {
        if ((i4 & 2) != 0) {
            i2 = 0;
        }
        if ((i4 & 4) != 0) {
            z2 = false;
        }
        if ((i4 & 8) != 0) {
            i3 = 0;
        }
        return V(charSequence, strArr, i2, z2, i3);
    }

    public static final boolean Y(CharSequence charSequence, int i2, CharSequence charSequence2, int i3, int i4, boolean z2) {
        k.d(charSequence, "<this>");
        k.d(charSequence2, "other");
        if (i3 < 0 || i2 < 0 || i2 > charSequence.length() - i4 || i3 > charSequence2.length() - i4) {
            return false;
        }
        for (int i5 = 0; i5 < i4; i5++) {
            if (!c.d(charSequence.charAt(i2 + i5), charSequence2.charAt(i3 + i5), z2)) {
                return false;
            }
        }
        return true;
    }

    public static String Z(String str, CharSequence charSequence) {
        k.d(str, "<this>");
        k.d(charSequence, "prefix");
        if (!k0(str, charSequence, false, 2, (Object) null)) {
            return str;
        }
        String substring = str.substring(charSequence.length());
        k.c(substring, "this as java.lang.String).substring(startIndex)");
        return substring;
    }

    public static String a0(String str, CharSequence charSequence) {
        k.d(str, "<this>");
        k.d(charSequence, "suffix");
        if (!C(str, charSequence, false, 2, (Object) null)) {
            return str;
        }
        String substring = str.substring(0, str.length() - charSequence.length());
        k.c(substring, "this as java.lang.String…ing(startIndex, endIndex)");
        return substring;
    }

    public static CharSequence b0(CharSequence charSequence, CharSequence charSequence2) {
        k.d(charSequence, "<this>");
        k.d(charSequence2, "delimiter");
        return c0(charSequence, charSequence2, charSequence2);
    }

    public static final CharSequence c0(CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3) {
        k.d(charSequence, "<this>");
        k.d(charSequence2, "prefix");
        k.d(charSequence3, "suffix");
        return (charSequence.length() < charSequence2.length() + charSequence3.length() || !k0(charSequence, charSequence2, false, 2, (Object) null) || !C(charSequence, charSequence3, false, 2, (Object) null)) ? charSequence.subSequence(0, charSequence.length()) : charSequence.subSequence(charSequence2.length(), charSequence.length() - charSequence3.length());
    }

    public static final void d0(int i2) {
        if (!(i2 >= 0)) {
            throw new IllegalArgumentException(("Limit must be non-negative, but was " + i2).toString());
        }
    }

    public static final List<String> e0(CharSequence charSequence, char[] cArr, boolean z2, int i2) {
        k.d(charSequence, "<this>");
        k.d(cArr, "delimiters");
        if (cArr.length == 1) {
            return f0(charSequence, String.valueOf(cArr[0]), z2, i2);
        }
        Iterable<z0.c> b2 = j.b(W(charSequence, cArr, 0, z2, i2, 2, (Object) null));
        ArrayList arrayList = new ArrayList(m.o(b2, 10));
        for (z0.c l02 : b2) {
            arrayList.add(l0(charSequence, l02));
        }
        return arrayList;
    }

    private static final List<String> f0(CharSequence charSequence, String str, boolean z2, int i2) {
        d0(i2);
        int i3 = 0;
        int H = H(charSequence, str, 0, z2);
        if (H == -1 || i2 == 1) {
            return k.b(charSequence.toString());
        }
        boolean z3 = i2 > 0;
        int i4 = 10;
        if (z3) {
            i4 = f.c(i2, 10);
        }
        ArrayList arrayList = new ArrayList(i4);
        do {
            arrayList.add(charSequence.subSequence(i3, H).toString());
            i3 = str.length() + H;
            if ((z3 && arrayList.size() == i2 - 1) || (H = H(charSequence, str, i3, z2)) == -1) {
                arrayList.add(charSequence.subSequence(i3, charSequence.length()).toString());
            }
            arrayList.add(charSequence.subSequence(i3, H).toString());
            i3 = str.length() + H;
            break;
        } while ((H = H(charSequence, str, i3, z2)) == -1);
        arrayList.add(charSequence.subSequence(i3, charSequence.length()).toString());
        return arrayList;
    }

    public static /* synthetic */ List g0(CharSequence charSequence, char[] cArr, boolean z2, int i2, int i3, Object obj) {
        if ((i3 & 2) != 0) {
            z2 = false;
        }
        if ((i3 & 4) != 0) {
            i2 = 0;
        }
        return e0(charSequence, cArr, z2, i2);
    }

    public static final d<String> h0(CharSequence charSequence, String[] strArr, boolean z2, int i2) {
        k.d(charSequence, "<this>");
        k.d(strArr, "delimiters");
        return j.g(X(charSequence, strArr, 0, z2, i2, 2, (Object) null), new c(charSequence));
    }

    public static /* synthetic */ d i0(CharSequence charSequence, String[] strArr, boolean z2, int i2, int i3, Object obj) {
        if ((i3 & 2) != 0) {
            z2 = false;
        }
        if ((i3 & 4) != 0) {
            i2 = 0;
        }
        return h0(charSequence, strArr, z2, i2);
    }

    public static final boolean j0(CharSequence charSequence, CharSequence charSequence2, boolean z2) {
        k.d(charSequence, "<this>");
        k.d(charSequence2, "prefix");
        if (!z2 && (charSequence instanceof String) && (charSequence2 instanceof String)) {
            return p.v((String) charSequence, (String) charSequence2, false, 2, (Object) null);
        }
        return Y(charSequence, 0, charSequence2, 0, charSequence2.length(), z2);
    }

    public static /* synthetic */ boolean k0(CharSequence charSequence, CharSequence charSequence2, boolean z2, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            z2 = false;
        }
        return j0(charSequence, charSequence2, z2);
    }

    public static final String l0(CharSequence charSequence, z0.c cVar) {
        k.d(charSequence, "<this>");
        k.d(cVar, "range");
        return charSequence.subSequence(cVar.g().intValue(), cVar.f().intValue() + 1).toString();
    }

    public static final String m0(String str, char c2, String str2) {
        k.d(str, "<this>");
        k.d(str2, "missingDelimiterValue");
        int P = P(str, c2, 0, false, 6, (Object) null);
        if (P == -1) {
            return str2;
        }
        String substring = str.substring(P + 1, str.length());
        k.c(substring, "this as java.lang.String…ing(startIndex, endIndex)");
        return substring;
    }

    public static /* synthetic */ String n0(String str, char c2, String str2, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            str2 = str;
        }
        return m0(str, c2, str2);
    }

    public static CharSequence o0(CharSequence charSequence) {
        k.d(charSequence, "<this>");
        int length = charSequence.length() - 1;
        int i2 = 0;
        boolean z2 = false;
        while (i2 <= length) {
            boolean c2 = b.c(charSequence.charAt(!z2 ? i2 : length));
            if (!z2) {
                if (!c2) {
                    z2 = true;
                } else {
                    i2++;
                }
            } else if (!c2) {
                break;
            } else {
                length--;
            }
        }
        return charSequence.subSequence(i2, length + 1);
    }

    public static final boolean x(CharSequence charSequence, char c2, boolean z2) {
        k.d(charSequence, "<this>");
        return K(charSequence, c2, 0, z2, 2, (Object) null) >= 0;
    }

    public static final boolean y(CharSequence charSequence, CharSequence charSequence2, boolean z2) {
        k.d(charSequence, "<this>");
        k.d(charSequence2, "other");
        if (charSequence2 instanceof String) {
            if (L(charSequence, (String) charSequence2, 0, z2, 2, (Object) null) >= 0) {
                return true;
            }
        } else {
            if (J(charSequence, charSequence2, 0, charSequence.length(), z2, false, 16, (Object) null) >= 0) {
                return true;
            }
        }
        return false;
    }

    public static /* synthetic */ boolean z(CharSequence charSequence, char c2, boolean z2, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            z2 = false;
        }
        return x(charSequence, c2, z2);
    }
}
