package c1;

import w0.k;

class o extends n {
    public static Integer f(String str) {
        k.d(str, "<this>");
        return g(str, 10);
    }

    public static final Integer g(String str, int i2) {
        boolean z2;
        int i3;
        k.d(str, "<this>");
        int unused = b.a(i2);
        int length = str.length();
        if (length == 0) {
            return null;
        }
        int i4 = 0;
        char charAt = str.charAt(0);
        int i5 = -2147483647;
        int i6 = 1;
        if (k.e(charAt, 48) >= 0) {
            z2 = false;
            i6 = 0;
        } else if (length == 1) {
            return null;
        } else {
            if (charAt == '-') {
                i5 = Integer.MIN_VALUE;
                z2 = true;
            } else if (charAt != '+') {
                return null;
            } else {
                z2 = false;
            }
        }
        int i7 = -59652323;
        while (i6 < length) {
            int b2 = b.b(str.charAt(i6), i2);
            if (b2 < 0) {
                return null;
            }
            if ((i4 < i7 && (i7 != -59652323 || i4 < (i7 = i5 / i2))) || (i3 = i4 * i2) < i5 + b2) {
                return null;
            }
            i4 = i3 - b2;
            i6++;
        }
        return z2 ? Integer.valueOf(i4) : Integer.valueOf(-i4);
    }
}
