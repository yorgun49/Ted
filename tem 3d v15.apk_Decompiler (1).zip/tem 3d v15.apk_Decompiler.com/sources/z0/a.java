package z0;

import p0.b0;
import r0.c;
import w0.g;

public class a implements Iterable<Integer>, x0.a {

    /* renamed from: e  reason: collision with root package name */
    public static final C0069a f4439e = new C0069a((g) null);

    /* renamed from: b  reason: collision with root package name */
    private final int f4440b;

    /* renamed from: c  reason: collision with root package name */
    private final int f4441c;

    /* renamed from: d  reason: collision with root package name */
    private final int f4442d;

    /* renamed from: z0.a$a  reason: collision with other inner class name */
    public static final class C0069a {
        private C0069a() {
        }

        public /* synthetic */ C0069a(g gVar) {
            this();
        }

        public final a a(int i2, int i3, int i4) {
            return new a(i2, i3, i4);
        }
    }

    public a(int i2, int i3, int i4) {
        if (i4 == 0) {
            throw new IllegalArgumentException("Step must be non-zero.");
        } else if (i4 != Integer.MIN_VALUE) {
            this.f4440b = i2;
            this.f4441c = c.b(i2, i3, i4);
            this.f4442d = i4;
        } else {
            throw new IllegalArgumentException("Step must be greater than Int.MIN_VALUE to avoid overflow on negation.");
        }
    }

    public final int a() {
        return this.f4440b;
    }

    public final int b() {
        return this.f4441c;
    }

    public final int c() {
        return this.f4442d;
    }

    /* renamed from: d */
    public b0 iterator() {
        return new b(this.f4440b, this.f4441c, this.f4442d);
    }

    public boolean equals(Object obj) {
        if (obj instanceof a) {
            if (!isEmpty() || !((a) obj).isEmpty()) {
                a aVar = (a) obj;
                if (!(this.f4440b == aVar.f4440b && this.f4441c == aVar.f4441c && this.f4442d == aVar.f4442d)) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    public int hashCode() {
        if (isEmpty()) {
            return -1;
        }
        return (((this.f4440b * 31) + this.f4441c) * 31) + this.f4442d;
    }

    public boolean isEmpty() {
        if (this.f4442d > 0) {
            if (this.f4440b > this.f4441c) {
                return true;
            }
        } else if (this.f4440b < this.f4441c) {
            return true;
        }
        return false;
    }

    public String toString() {
        int i2;
        StringBuilder sb;
        if (this.f4442d > 0) {
            sb = new StringBuilder();
            sb.append(this.f4440b);
            sb.append("..");
            sb.append(this.f4441c);
            sb.append(" step ");
            i2 = this.f4442d;
        } else {
            sb = new StringBuilder();
            sb.append(this.f4440b);
            sb.append(" downTo ");
            sb.append(this.f4441c);
            sb.append(" step ");
            i2 = -this.f4442d;
        }
        sb.append(i2);
        return sb.toString();
    }
}
