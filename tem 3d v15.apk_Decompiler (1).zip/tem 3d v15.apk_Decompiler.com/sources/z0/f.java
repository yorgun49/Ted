package z0;

import w0.k;
import z0.a;

class f extends e {
    public static int b(int i2, int i3) {
        return i2 < i3 ? i3 : i2;
    }

    public static int c(int i2, int i3) {
        return i2 > i3 ? i3 : i2;
    }

    public static int d(int i2, int i3, int i4) {
        if (i3 <= i4) {
            return i2 < i3 ? i3 : i2 > i4 ? i4 : i2;
        }
        throw new IllegalArgumentException("Cannot coerce value to an empty range: maximum " + i4 + " is less than minimum " + i3 + '.');
    }

    public static a e(int i2, int i3) {
        return a.f4439e.a(i2, i3, -1);
    }

    public static a f(a aVar, int i2) {
        k.d(aVar, "<this>");
        e.a(i2 > 0, Integer.valueOf(i2));
        a.C0069a aVar2 = a.f4439e;
        int a2 = aVar.a();
        int b2 = aVar.b();
        if (aVar.c() <= 0) {
            i2 = -i2;
        }
        return aVar2.a(a2, b2, i2);
    }

    public static c g(int i2, int i3) {
        return i3 <= Integer.MIN_VALUE ? c.f4447f.a() : new c(i2, i3 - 1);
    }
}
