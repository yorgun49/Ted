package z0;

import w0.k;

class e {
    public static final void a(boolean z2, Number number) {
        k.d(number, "step");
        if (!z2) {
            throw new IllegalArgumentException("Step must be positive, was: " + number + '.');
        }
    }
}
