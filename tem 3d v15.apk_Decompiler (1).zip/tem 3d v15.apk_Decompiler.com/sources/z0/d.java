package z0;

public final class d extends f {
}
