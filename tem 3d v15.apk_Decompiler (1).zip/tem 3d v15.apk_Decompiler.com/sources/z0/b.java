package z0;

import java.util.NoSuchElementException;
import p0.b0;

public final class b extends b0 {

    /* renamed from: b  reason: collision with root package name */
    private final int f4443b;

    /* renamed from: c  reason: collision with root package name */
    private final int f4444c;

    /* renamed from: d  reason: collision with root package name */
    private boolean f4445d;

    /* renamed from: e  reason: collision with root package name */
    private int f4446e;

    public b(int i2, int i3, int i4) {
        this.f4443b = i4;
        this.f4444c = i3;
        boolean z2 = true;
        if (i4 <= 0 ? i2 < i3 : i2 > i3) {
            z2 = false;
        }
        this.f4445d = z2;
        this.f4446e = !z2 ? i3 : i2;
    }

    public int a() {
        int i2 = this.f4446e;
        if (i2 != this.f4444c) {
            this.f4446e = this.f4443b + i2;
        } else if (this.f4445d) {
            this.f4445d = false;
        } else {
            throw new NoSuchElementException();
        }
        return i2;
    }

    public boolean hasNext() {
        return this.f4445d;
    }
}
