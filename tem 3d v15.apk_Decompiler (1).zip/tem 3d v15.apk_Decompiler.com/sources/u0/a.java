package u0;

import a1.b;
import w0.d;
import w0.k;

public final class a {
    public static final <T> Class<T> a(b<T> bVar) {
        k.d(bVar, "<this>");
        Class<?> a2 = ((d) bVar).a();
        if (!a2.isPrimitive()) {
            return a2;
        }
        String name = a2.getName();
        switch (name.hashCode()) {
            case -1325958191:
                return !name.equals("double") ? a2 : Double.class;
            case 104431:
                return !name.equals("int") ? a2 : Integer.class;
            case 3039496:
                return !name.equals("byte") ? a2 : Byte.class;
            case 3052374:
                return !name.equals("char") ? a2 : Character.class;
            case 3327612:
                return !name.equals("long") ? a2 : Long.class;
            case 3625364:
                return !name.equals("void") ? a2 : Void.class;
            case 64711720:
                return !name.equals("boolean") ? a2 : Boolean.class;
            case 97526364:
                return !name.equals("float") ? a2 : Float.class;
            case 109413500:
                return !name.equals("short") ? a2 : Short.class;
            default:
                return a2;
        }
    }
}
